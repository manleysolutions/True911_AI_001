<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;
use DB;

class CountriesTableSeeder extends Seeder {
	
	public function run() 
	{
		DB::table('countries')->delete();

		$countries = array(
			array('code' => 'CA', 'name' => 'Canada'),
			array('code' => 'GB', 'name' => 'United Kingdom'), 
			array('code' => 'US', 'name' => 'United States')
		);

		DB::table('countries')->insert($countries);
	}
}

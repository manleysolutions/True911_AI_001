<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('call_logs', function (Blueprint $table) {
            $table->string('flow_name')->after('nick_name')->nullable();
            $table->string('flow_sid')->after('flow_name')->nullable();
            $table->string('unique_id')->after('id')->nullable();
            $table->string('facility_name')->after('nick_name')->nullable();
            $table->string('facility_address')->after('facility_name')->nullable();
            $table->string('facility_city')->after('facility_address')->nullable();
            $table->string('facility_state')->after('facility_city')->nullable();
            $table->string('facility_zip')->after('facility_state')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('call_logs', function (Blueprint $table) {
            //
        });
    }
};

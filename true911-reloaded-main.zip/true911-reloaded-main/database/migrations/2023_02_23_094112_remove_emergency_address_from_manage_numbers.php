<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('manage_numbers', function (Blueprint $table) {
            $table->dropColumn('emergency_address');
            $table->dropColumn('another_address');
            $table->dropColumn('city');
            $table->dropColumn('postal_code');
            $table->dropColumn('region');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('manage_numbers', function (Blueprint $table) {
            //
        });
    }
};

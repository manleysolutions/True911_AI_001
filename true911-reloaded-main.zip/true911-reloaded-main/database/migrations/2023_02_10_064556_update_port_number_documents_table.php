<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\PortNumberDocument;
use App\Models\PortNumber;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::table('port_number_documents', function(Blueprint $table){
            $table->dropColumn('letter_authorization');
            $table->dropColumn('billing_statement');
            $table->text('display_name');
            $table->text('md5_checksum');
            $table->enum('document_type', ['Authorization', 'Billing'])->default('Authorization');
            $table->integer('size');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('port_number_documents', function(Blueprint $table){
            $table->string('letter_authorization');
            $table->string('billing_statement');
            $table->dropColumn('display_name');
            $table->dropColumn('md5_checksum');
            $table->dropColumn('document_type', ['Authorization', 'Billing']);
            $table->dropColumn('size');
            $table->dropSoftDeletes();
        });
    }
};

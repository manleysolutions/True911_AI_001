<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\PortNumberDocument;
use App\Models\PortNumber;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      PortNumberDocument::query()->delete();
      PortNumber::query()->delete();
      Schema::table('port_numbers', function (Blueprint $table) {
         $table->Integer('status')->change()->comment('0-Pending ,1-Ported,2-Reject,3-Requested');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};

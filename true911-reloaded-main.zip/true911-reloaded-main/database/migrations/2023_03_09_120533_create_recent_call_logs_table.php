<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('recent_call_logs', function (Blueprint $table) {
            $table->id();
            $table->string('unique_id')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('nick_name')->nullable();
            $table->string('facility_name')->nullable();
            $table->string('facility_address')->nullable();
            $table->string('facility_city')->nullable();
            $table->string('facility_state')->nullable();
            $table->string('facility_zip')->nullable();
            $table->string('flow_name')->nullable();
            $table->string('flow_sid')->nullable();
            $table->date('incoming_date')->nullable();
            $table->string('call_recording')->nullable();
            $table->string('duration')->nullable();
            $table->string('price')->nullable();
            $table->string('dial_call_sid')->nullable();
            $table->string('dial_call_status')->nullable();
            $table->string('device_sn')->nullable();
            $table->timestamps();  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recent_call_logs');
    }
};

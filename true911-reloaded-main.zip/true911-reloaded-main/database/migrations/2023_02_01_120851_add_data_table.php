<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('devices', function (Blueprint $table) {
            $table->string('nick_name')->nullable();
            $table->string('billing_address')->nullable();
            $table->string('billing_city')->nullable();
            $table->string('billing_state')->nullable();
            $table->string('billing_zip')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('account_name')->nullable();
            $table->string('facility_name')->nullable();
            $table->string('facility_address')->nullable();
            $table->string('facility_city')->nullable();
            $table->string('facility_state')->nullable();
            $table->string('facility_zip')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('devices', function (Blueprint $table) {
            $table->string('nick_name')->nullable();
            $table->string('billing_address')->nullable();
            $table->string('billing_city')->nullable();
            $table->string('billing_state')->nullable();
            $table->string('billing_zip')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('account_name')->nullable();
            $table->string('facility_name')->nullable();
            $table->string('facility_address')->nullable();
            $table->string('facility_city')->nullable();
            $table->string('facility_state')->nullable();
            $table->string('facility_zip')->nullable();
        });
    }
};

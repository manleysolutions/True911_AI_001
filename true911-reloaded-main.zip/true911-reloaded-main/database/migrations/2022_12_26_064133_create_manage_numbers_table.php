<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('manage_numbers', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id')->nullable();
            $table->string('manage_number')->nullable();
            $table->string('nick_name')->nullable();
            $table->string('phone_number_sid')->nullable();
            $table->string('country')->nullable();
            $table->longText('emergency_address')->nullable();
            $table->integer('status')->default('1');
            $table->date('purchase_date')->nullable();
            $table->longText('linked_devices')->nullable();
            $table->string('city')->nullable();
            $table->string('postal_code')->nullable();
            $table->string('region')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('manage_numbers');
    }
};

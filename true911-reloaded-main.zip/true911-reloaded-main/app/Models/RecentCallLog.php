<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecentCallLog extends Model
{
    use HasFactory;
    protected $fillable = [
        'dial_call_sid',
        'dial_call_status',
        'duration',
        'call_recording',
        'phone_number',
        'device_sn',
        'nick_name',
        'flow_name',
        'flow_sid',
        'unique_id',
        'facility_name',
        'facility_address',
        'facility_city',
        'facility_state',
        'facility_zip',
        'price',
        'created_at',
        'updated_at'
    ];
}

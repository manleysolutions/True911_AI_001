<?php

namespace App\Models;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
    use HasFactory;
    protected $fillable = [
        'unique_id',
        'row_id',
        'device_sn',
        'device_imei',
        'tmobile_sim',
        'tmobile_msisd',
        'number_id',
        'flow_sid',
        'sheet_modified_date',
        'nick_name', 
        'billing_address', 
        'billing_city', 
        'billing_state', 
        'billing_zip', 
        'email', 
        'phone',
        'account_name', 
        'facility_name', 
        'facility_address', 
        'facility_city', 
        'facility_state', 
        'facility_zip',
        'flow_name'
    ];
    protected $table = "devices";

    public function manageNumber()
    {

        return $this->hasOne(ManageNumber::class);
    }

    public function scopeSearch($query, array $filter)
    {
        $query->when($filter['search'] ?? false, function ($query, $search) {

            return $query
                ->where('device_sn', 'like', '%' . $search . '%')
                ->orwhere('unique_id', 'like', '%' . $search . '%')
                ->orwhere('nick_name', 'like', '%' . $search . '%')
                ->orwhere('facility_name', 'like', '%' . $search . '%')
                ->orwhere('facility_city', 'like', '%' . $search . '%')
                ->orwhere('facility_state', 'like', '%' . $search . '%')
                ->orwhere('facility_zip', 'like', '%' . $search . '%')
                ->orwhere('facility_address', 'like', '%' . $search . '%');
        });
    }

    public function scopeSort($query, Request $request)
    { 
        try {

            if ($request->query('unique_id')) {
                $sort['unique_id'] = $request->query('unique_id');
            } elseif ($request->query('device_sn') ) {
                $sort['device_sn'] = $request->query('device_sn');
            } elseif ($request->query('device_imei')) {
                $sort['device_imei'] = $request->query('device_imei');
            } elseif ($request->query('customer_detail')) {
                $sort['nick_name'] = $request->query('customer_detail');
            } elseif ($request->query('tmobile_msisdn')) {
                $sort['tmobile_msisdn'] = $request->query('tmobile_msisdn');
            }  elseif ($request->query('tmobile_sim')) {
                $sort['tmobile_sim'] = $request->query('tmobile_sim');
            } elseif ($request->query('facility_address')) {
                $sort['facility_address'] = $request->query('facility_address');
            }

            if ($request->query('linked_number') == 'link' && empty($sort)) {
                
                return $query->whereNotNull('number_id')->orderBy('updated_at', 'desc');
            } 
            if ($request->query('linked_number') == 'link' && !empty($sort)) {

                return $query->whereNotNull('number_id')->orderBy(key($sort), $sort[key($sort)]);
            }  
            if ($request->query('linked_number') == 'unlink' && empty($sort)) {
                
                return $query->whereNull('number_id')->orderBy('updated_at', 'desc');
            } 
            if ($request->query('linked_number') == 'unlink' && !empty($sort)) {
                
                return $query->whereNull('number_id')->orderBy(key($sort), $sort[key($sort)]);   
            } 
            if ($request->query('linked_number') == 'all' && empty($sort)) {

                return $query->orderBy('updated_at', 'desc');
            } 
            if ($request->query('linked_number') == 'all' && !empty($sort)) {
                
                return $query->orderBy(key($sort), $sort[key($sort)]);   
            } 
            if (!empty($sort)) {

                return $query->whereNull('number_id')->orderBy(key($sort), $sort[key($sort)]);
                
            } elseif ($request->query('search') && empty($sort) && $request->query('linked_number')) {
                
                return $query->whereNull('number_id')->orderBy('updated_at', 'desc');
                
            } elseif ($request->query('search') && !empty($sort)) {
                
                return $query->orderBy(key($sort), $sort[key($sort)]);
                
            } elseif ($request->query() && !$request->query('page') && !$request->query('perPage') && !empty($sort)) {
                
                return $query->orderBy(key($sort), $sort[key($sort)]);

            } else {
                
                return $query->orderBy('updated_at', 'desc');  
            }
        } catch (Exception $e) {

            return $query->whereNull('number_id')->orderBy('updated_at', 'desc');
        }
    }
}

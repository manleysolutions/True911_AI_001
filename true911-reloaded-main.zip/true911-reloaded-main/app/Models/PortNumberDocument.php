<?php

namespace App\Models;

use App\Models\Comment;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PortNumberDocument extends Model
{
    use HasFactory, SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'port_number_documents';

    

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'published_at' => 'date',
    ];
}

<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class PortNumber extends Model
{

    /**
     * @var string
     */
    protected $table = 'port_numbers';

    protected $fillable = [
        'first_name', 
        'last_name',
        'address', 
        'address_2', 
        'city', 
        'state', 
        'postal_code', 
        'number', 
        'account_number', 
        'option', 
        'pin', 
        'status', 
        'comment',
        'request_date',
        'cancel_comment'
    ];

    const PENDING = 0;
    const SUCCESSFULLY = 1;
    const REJECTED =2;
    const REQUESTED =3;
    const CANCELLED =4;

    public function getStatusAttribute() 
    {
       if ($this->attributes['status'] == self::SUCCESSFULLY) {
            return 'SUCCESSFULLY';
        }

        if ($this->attributes['status'] == self::PENDING) {
            return 'PENDING';
        }
         if ($this->attributes['status'] == self::REJECTED) {
            return 'REJECTED';
        }

        if ($this->attributes['status'] == self::CANCELLED) {
            return 'CANCELLED';
        }

        return 'REQUESTED';
    }

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'published_at' => 'date',
    ];

    public function scopeSearch($query, array $filter) {

        $query->when($filter['search'] ?? false, function($query, $search) {

            return $query
                ->where('address', 'like', '%'. $search . '%')
                    ->orwhere('number', 'like', '%'. $search . '%')
                    ->orwhere('request_date', 'like', '%'. $search . '%');
        });
    }
    public function scopeDataFilter($query, $request) {
        if ($request->status == 'pending') {

            return $query->where('status', 0);
        }  elseif ($request->status == 'successful') {

            return $query->where('status', 1);
        } elseif ($request->status == 'rejected') {

            return $query->where('status', 2);
        } elseif ($request->status == 'requested') {

            return $query->where('status', 3);
        }elseif ($request->status == 'cancelled') {

            return $query->where('status', 4);
        } else {

            return $query;
        }
    }
    public function scopeSort($query, Request $request)
    { 
        try {

            if ($request->query('number')) {
                $sort['number'] = $request->query('number');
            } elseif ($request->query('address') ) {
                $sort['address'] = $request->query('address');
            } elseif ($request->query('request_date') ) {
                $sort['request_date'] = $request->query('request_date');
            }
            if (!empty($sort)) {

                return $query->orderBy(key($sort), $sort[key($sort)]);
                
            } elseif ($request->query('search') && !empty($sort) && $request->query('status')) {

                return $query->orderBy(key($sort), $sort[key($sort)]);
                
            } elseif ($request->query() && !$request->query('page') && !$request->query('perPage') && !empty($sort)) {
                
                return $query->orderBy(key($sort), $sort[key($sort)]);

            } else {
                
                return $query->orderBy('updated_at', 'desc');  
            }
        } catch (Exception $e) {

            return $query->orderBy('updated_at', 'desc');
        }
    }
    public function document() {
        
        return $this->hasMany(PortNumberDocument::class);
    }
}
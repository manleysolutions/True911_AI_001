<?php

namespace App\Models;

use App\Models\Country;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use Twilio\Rest\Client;

class ManageNumber extends Model
{
    use SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'manage_numbers';

    protected $fillable = [
        'user_id',
        'manage_number',
        'nick_name',
        'phone_number_sid',
        'country',
        'purchase_date',
        'device_id',
        'status'
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'published_at' => 'date',
    ];
    //relationship with device
    public function device()
    {

        return $this->belongsTo(Device::class);
    }

    public function call_logs()
    {
        return $this->hasMany(CallLog::class);
    }

    public function scopeFormatNumber($query, $phoneNumber, $countryCode)
    {
        if ($countryCode == "GB") {
            preg_match('/^\+\d\d(\d{4})(\d{6})$/', $phoneNumber,  $matches);

            $formatPhoneNumber = '+44 ' . $matches[1] . ' ' . $matches[2];
        } else {
            preg_match('/^\+\d(\d{3})(\d{3})(\d{4})$/', $phoneNumber,  $matches);

            $formatPhoneNumber = '+1 ' . $matches[1] . ' ' . $matches[2] . ' ' . $matches[3];
        }

        return $formatPhoneNumber;
    }

    public function scopeCountries()
    {
        $countries = Country::get();
        $countryList = [];
        foreach ($countries as $country) {
            $countryList[$country->code] = $country->name;
        }

        return $countryList;
    }

    public function scopeRemoveSpace($query, $number)
    {

        return $query->whereRaw("REPLACE(`manage_number`, ' ', '') = ? ", $number)->first();;
    }

    public function scopeSearch($query, array $filter)
    {
        $query->when($filter['search'] ?? false, function ($query, $search) {

            return $query
                ->where('nick_name', 'like', '%' . $search . '%')
                ->orwhere('manage_number', 'like', '%' . $search . '%')
                ->orwhere('country', 'like', '%' . $search . '%');
        });
    }

    public function scopeSort($query, Request $request)
    {
        try {
            if ($request->query('manage_number')) {
                $sort['manage_number'] = $request->query('manage_number');
            } elseif ($request->query('nick_name')) {
                $sort['nick_name'] = $request->query('nick_name');
            } elseif ($request->query('country')) {
                $sort['country'] = $request->query('country');
            } elseif ($request->query('emergency_address')) {
                $sort['emergency_address'] = $request->query('emergency_address');
            } elseif ($request->query('purchase_date')) {
                $sort['purchase_date'] = $request->query('purchase_date');
            } elseif ($request->query('released_date')) {
                $sort['deleted_at'] = $request->query('released_date');
            }

            if ($request->query('linked_number') == 'link' && empty($sort)) {

                return $query->whereNotNull('device_id')->orderBy('updated_at', 'desc');
            }
            if ($request->query('linked_number') == 'link' && !empty($sort)) {

                return $query->whereNotNull('device_id')->orderBy(key($sort), $sort[key($sort)]);
            }
            if ($request->query('linked_number') == 'unlink' && empty($sort)) {

                return $query->whereNull('device_id')->orderBy('updated_at', 'desc');
            }
            if ($request->query('linked_number') == 'unlink' && !empty($sort)) {

                return $query->whereNull('device_id')->orderBy(key($sort), $sort[key($sort)]);
            }
            if (!empty($sort)) {

                return $query->whereNull('device_id')->orderBy(key($sort), $sort[key($sort)]);
            } elseif ($request->query('search') && empty($sort) && $request->query('linked_number')) {

                return $query->whereNull('device_id')->orderBy('updated_at', 'desc');
            } elseif ($request->query('search') && !empty($sort)) {

                return $query->orderBy(key($sort), $sort[key($sort)]);
            } elseif ($request->query() && !$request->query('page') && !$request->query('perPage') && !empty($sort)) {

                return $query->orderBy(key($sort), $sort[key($sort)]);
            } else {

                return $query->orderBy('updated_at', 'desc');
            }
        } catch (Exception $e) {

            return $query->whereNull('device_id')->orderBy('updated_at', 'desc');
        }
    }

    public function scopeContainVal($query, $data)
    {

        $criteria = $data['criteria'];
        $matchTo = $data['matchTo'];
        $country = $data['country'];
        $containtVal = "";

        $criteriaCount = strlen($criteria);
        $position = 10 - $criteriaCount;
        $valueStar = [];
        for ($index = 0; $index < $position; $index++) {
            $valueStar[] = "*";
        }

        $character = implode("", $valueStar);

        if ($matchTo == 1 && !empty($criteria)) {
            $containtVal = $criteria . "" . $character;
        } else if ($matchTo == 2 && !empty($criteria)) {
            $containtVal = $criteria;
        } else if ($matchTo == 3 && !empty($criteria)) {
            $containtVal = $character . "" . $criteria;
        }

        if (($country == 'CA' || $country == 'US') && !empty($criteria) && $matchTo != 2) {
            $containtVal = '+1' . $containtVal;
        } else if (!empty($criteria)  && $matchTo != 2) {
            $containtVal = '+44' . $containtVal;
        }

        return $containtVal;
    }

    public function scopeNumberType($query, $data, $containtVal)
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $twilio = new Client($sid, $token);

        $numberType = $data['numberType'];
        $country = $data['country'];

        if (
            isset($data['capabilities']) && in_array("voice", $data['capabilities']) &&
            in_array("sms", $data['capabilities'])
        ) {

            return $twilio
                ->availablePhoneNumbers($country)
                ->$numberType->read(
                    [
                        "contains" => $containtVal,
                        "voiceEnabled" => true,
                        "smsEnabled" => true
                    ],
                    20
                );
        }
        if ((isset($data['capabilities']) && in_array("voice", $data['capabilities']))) {

            return $twilio
                ->availablePhoneNumbers($country)
                ->$numberType->read(
                    [
                        "contains" => $containtVal,
                        "voiceEnabled" => true,
                    ],
                    20
                );
        }
        if ((isset($data['capabilities']) && in_array("sms", $data['capabilities']))) {

            return $twilio
                ->availablePhoneNumbers($country)
                ->$numberType->read(
                    [
                        "contains" => $containtVal,
                        "smsEnabled" => true
                    ],
                    20
                );
        } else {

            return $twilio
                ->availablePhoneNumbers($country)
                ->$numberType->read(["contains" => $containtVal], 20);
        }
    }

    public function scopeEmergencyAddressStatus($query, $status)
    {
        if (
            $status == "pending-registration" ||
            $status == "pending-unregistration" ||
            $status == "unregistered"
        ) {
            return true;
        } else {
            return false;
        }
    }
}

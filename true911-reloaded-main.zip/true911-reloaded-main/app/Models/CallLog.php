<?php

namespace App\Models;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class CallLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'dial_call_sid',
        'dial_call_status',
        'duration',
        'call_recording',
        'phone_number',
        'device_sn',
        'nick_name',
        'flow_name',
        'flow_sid',
        'unique_id',
        'facility_name',
        'facility_address',
        'facility_city',
        'facility_state',
        'facility_zip',
        'price',
    ];

    public function manageNumber()
    {
        return $this->belongsTo(ManageNumber::class);
    }

    public function scopeSearch($query, array $filter)
    {

        $query->when($filter['search'] ?? false, function ($query, $search) {

            return $query->where('phone_number', 'like', '%' . str_replace(' ', '', $search) . '%')
                ->orwhere('device_sn', 'like', '%' . $search . '%')
                ->orwhere('unique_id', 'like', '%' . $search . '%')
                ->orwhere('facility_name', 'like', '%' . $search . '%')
                ->orwhere('facility_address', 'like', '%' . $search . '%')
                ->orwhere('facility_city', 'like', '%' . $search . '%')
                ->orwhere('facility_state', 'like', '%' . $search . '%')
                ->orwhere('facility_zip', 'like', '%' . $search . '%');
        });
    }

    public function scopeFormatNumber($query, $number)
    {
        if (strpos(str_replace(' ', '', $number), "+") !== false) {
            $to = str_replace(' ', '', $number);
        } else {
            $to = '+' . str_replace(' ', '', $number);
        }

        if (substr($number, 0, 1) == 1) {
            preg_match('/^\+\d(\d{3})(\d{3})(\d{4})$/', $to,  $matches);
            $to  = '+1 ' . $matches[1] . ' ' . $matches[2] . ' ' . $matches[3];
        } else if (substr($number, 0, 1) == 4) {
            preg_match('/^\+\d\d(\d{4})(\d{6})$/', $to,  $matches);
            $to = '+44 ' . $matches[1] . ' ' . $matches[2];
        } else {
            $to = $to;
        }

        return $to;
    }

    public function scopeDataFilter($query, Request $request)
    {
        try {

            if ($request->data_filter) {
                if ($request->query('data_filter') == 'today' || $request->data_filter == 'today') {

                    return $query->whereDate('created_at', Carbon::today())
                        ->orderBy('created_at', 'desc');
                } elseif ($request->query('data_filter') == 'yesterday' || $request->data_filter == 'yesterday') {

                    return $query->whereDate('created_at', Carbon::yesterday())
                        ->orderBy('created_at', 'desc');
                } else if ($request->query('data_filter') == 'last_7_days' || $request->data_filter == 'last_7_days') {

                    return $query->where('created_at', '>=', Carbon::today()->subDays(7))
                        ->orderBy('created_at', 'desc');
                } elseif ($request->query('data_filter') == 'last_30_days' || $request->data_filter == 'last_30_days') {

                    return $query->where('created_at', '>=', Carbon::today()->subDays(30))
                        ->orderBy('created_at', 'desc');
                } elseif ($request->query('data_filter') == 'last_month' || $request->data_filter == 'last_month') {

                    return $query->whereMonth('created_at', Carbon::now()->subMonth()->format("m"))
                        ->orderBy('created_at', 'desc');
                } elseif ($request->query('data_filter') == 'last_year' || $request->data_filter == 'last_year') {

                    return $query->whereYear('created_at', Carbon::now()->subYear()->format("Y"))
                        ->orderBy('created_at', 'desc');
                } elseif ($request->data_filter == 'custom_date') {

                    $from = date($request->from) . " 00:00:00";
                    $to = date($request->to) . " 23:59:59";

                    return $query->whereBetween('created_at', [$from, $to])
                        ->orderBy('created_at', 'desc');
                } else {

                    return $query->orderBy('created_at', 'desc');
                }
            } else if (isset($request->number) && $request->number != 'all') {

                return $query->where('phone_number', $request->number)
                    ->orderBy('created_at', 'desc');
            } else {

                return $query->orderBy('created_at', 'desc');
            }
        } catch (Exception $e) {

            return $query->orderBy('created_at', 'desc');
        }
    }

    public function scopeSort($query, Request $request)
    {
        try {
            if ($request->query('unique_id')) {
                $sort['unique_id'] = $request->query('unique_id');
            } elseif ($request->query('phone_number')) {
                $sort['phone_number'] = $request->query('phone_number');
            } elseif ($request->query('facility_name')) {
                $sort['facility_name'] = $request->query('facility_name');
            } elseif ($request->query('facility_address')) {
                $sort['facility_address'] = $request->query('facility_address');
            } elseif ($request->query('incoming_date')) {
                $sort['updated_at'] = $request->query('incoming_date');
            } elseif ($request->query('flow_name')) {
                $sort['flow_name'] = $request->query('flow_name');
            } else {

                return $query->orderBy('updated_at', 'desc');
            }

            return $query->orderBy(key($sort), $sort[key($sort)]);
        } catch (Exception $e) {

            return $query->whereNull('number_id')->orderBy('updated_at', 'desc');
        }
    }
}

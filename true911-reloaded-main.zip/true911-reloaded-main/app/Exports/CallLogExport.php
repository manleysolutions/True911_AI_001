<?php

namespace App\Exports;

use App\Models\CallLog;
use Exception;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class CallLogExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    protected $request;
    public function __construct($request)
    {
        $this->request = $request;
    }

    public function headings(): array
    {
        return [
            'S.No.',
            'Unique Id',
            'Phone Number',
            'Facility',
            'Incoming Date',
            'Call Recording',
            'Call Duration',
            'Call Price'
        ];
    }

    public function collection()
    {
        try {
             
            $filters = CallLog::whereIn('unique_id', $this->request->devices)
                ->whereIn('phone_number', str_replace(' ', '',$this->request->number))->sort($this->request)
                ->dataFilter($this->request)
                ->orderBy('updated_at', 'desc')
                ->get();
                
            $result = [];
            foreach ($filters as $key => $value) {
                $result[] = array(
                    'S.No.' => $key + 1,
                    'Unique Id' => $value->unique_id ?? 'N/A',
                    'Phone Number' => CallLog::FormatNumber(substr($value->phone_number, 1)) .''. "\n" .$value->nick_name ?? 'N/A',
                    'Facility' => $value->facility_name . '' . "\n" .$value->facility_address . ',' . $value->facility_city . ',' . $value->facility_state . ' ' . $value->facility_zip ?? 'N/A',
                    'Incoming Date' =>  date("d M, Y", strtotime($value->created_at)) ?? 'N/A',
                    'Call Recording' => $value->call_recording ?? 'N/A',
                    'Call Duration' => $value->duration ?? 'N/A',
                    'Call Price' =>  !empty($value->price) ? number_format($value->price,2) : '0.00' 

                );
            };
        
            return collect($result);
        } catch (Exception $e) {
            
            Log::info('When we export the call log details:' .$e);

            return back()->with('error', $e->getMessage());
        }
    }
}

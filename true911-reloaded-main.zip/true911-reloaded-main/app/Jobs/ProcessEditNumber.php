<?php

namespace App\Jobs;

use App\Models\ManageNumber;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;


class ProcessEditNumber implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $twilio, $numbers, $data;

    public function __construct($numbers, $data)
    {
        $this->data = $data;
        $this->numbers = $numbers;
        $this->data = $data;
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        $this->twilio = new Client($sid, $token);
         
    }

    public function handle()
    {
        $data = $this->data;
        $numbers = $this->numbers;
        try {
         //   Associate new Emergency Address
            $addressSid = $data;

            $this->twilio->incomingPhoneNumbers($numbers->phone_number_sid)
                ->update([
                    "emergencyAddressSid" => $addressSid,
                ]);
                 
        } catch (Exception $e) {
          
            $this->failed($e);
        }
    }
    public function failed($exception) {

        $exception->getMessage();
    }
}

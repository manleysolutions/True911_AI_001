<?php

namespace App\Jobs;

use App\Models\Device;
use App\Models\ManageNumber;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;

class ProcessReleaseNumber implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $data, $twilio;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        $this->twilio = new Client($sid, $token);

    } 

    public function handle()
    {
        try {
            $this->twilio->incomingPhoneNumbers($this->data->phone_number_sid)
                ->delete();
            
        } catch (Exception $e) {
            $this->failed($e);
        }
    }
    public function failed($exception) {

        $exception->getMessage();
    }
}

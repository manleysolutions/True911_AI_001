<?php

namespace App\Jobs;

use App\Models\Device;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Exception;
use Illuminate\Support\Facades\Http;

class DeviceListing implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
    }
    public $timeout = 0;
    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            //Smartsheet Link URL
            $json = Http::withToken(config('services.smartsheet.SMARTSHEET_TOKEN'))
                ->accept('application/json')
                ->get(config('services.smartsheet.SMARTSHEET_URL'));

            $obj = json_decode($json);
            $columns_data = [];
            $device_sn = [];
            $device_imei = [];
            $tmobile_sim = [];
            $tmobile_msisdn = [];
            $result = [];
            $row_modifiedAt = [];

            //Seperate the column
            foreach ($obj->columns as $key => $value) {
                // fire a event.
                $value->title == "UniqueID" ? $columns_data['unique_id'] = $value->id : '';
                $value->title == "Device SN#" ? $columns_data['device_sn'] = $value->id : '';
                $value->title == "Device IMEI" ? $columns_data['device_imei'] = $value->id : '';
                $value->title == "TMOBILE SIM" ? $columns_data['tmobile_sim'] = $value->id : $columns_data['verizon_sim'] = $value->id;
                $value->title == "TMOBILE MSISDN" ? $columns_data['tmobile_msisdn'] = $value->id : '';
                $value->title == "Nickname" ? $columns_data['nick_name'] = $value->id : '';
                $value->title == "Billing Address" ? $columns_data['billing_address'] = $value->id : '';
                $value->title == "City" ? $columns_data['city'] = $value->id : '';
                $value->title == "State" ? $columns_data['state'] = $value->id : '';
                $value->title == "Zip" ? $columns_data['zip'] = $value->id : '';
                $value->title == "Emergency Contact 1 Email" ? $columns_data['email'] = $value->id : '';
                $value->title == "Emergency Contact 1 Ph#" ? $columns_data['phone'] = $value->id : '';
                $value->title == "Account Type" ? $columns_data['account_name'] = $value->id : '';
                $value->title == "FacilityName" ? $columns_data['facility_name'] = $value->id : '';
                $value->title == "FacilityAddress" ? $columns_data['facility_address'] = $value->id : '';
                $value->title == "FacilityCity" ? $columns_data['facility_city'] = $value->id : '';
                $value->title == "FacilityState" ? $columns_data['facility_state'] = $value->id : '';
                $value->title == "FacilityZipCode" ? $columns_data['facility_zip'] = $value->id : '';
            }

            foreach ($obj->rows as $key_row => $row) {

                $modified_at =  explode("T", $row->modifiedAt);
                $row_modifiedAt[$row->id] = $modified_at[0];

                foreach ($row->cells as $key_cell => $row_value) {
                    // fire a event.
                   
                    $row_value->columnId == $columns_data['device_sn'] ? $device_sn[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['device_imei'] ? $device_imei[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['tmobile_sim'] ? $tmobile_sim[$row->id] = $row_value->displayValue ?? '' : $verizon_sim[$row->id] = $row_value->value ?? '';
                    $row_value->columnId == $columns_data['tmobile_msisdn'] ? $tmobile_msisdn[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['nick_name'] ? $nick_name[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['billing_address'] ? $billing_address[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['city'] ? $city[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['state'] ? $state[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['zip'] ? $zip[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['email'] ? $email[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['phone'] ? $phone[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['account_name'] ? $account_name[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['facility_name'] ? $facility_name[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['facility_address'] ? $facility_address[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['facility_city'] ? $facility_city[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['facility_state'] ? $facility_state[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['facility_zip'] ? $facility_zip[$row->id] = $row_value->displayValue ?? '' : '';
                    $row_value->columnId == $columns_data['unique_id'] ? $unique_id[$row->id] = $row_value->displayValue ?? Null : Null;
                }
            }

            foreach ($device_sn as $idx => $val) {
                $result[$idx] = [
                    $val,
                    $device_imei[$idx],
                    $tmobile_sim[$idx],
                    $tmobile_msisdn[$idx],
                    $row_modifiedAt[$idx],
                    $nick_name[$idx],
                    $billing_address[$idx],
                    $city[$idx],
                    $state[$idx],
                    $zip[$idx],
                    $email[$idx],
                    $phone[$idx],
                    $account_name[$idx],
                    $facility_name[$idx],
                    $facility_address[$idx],
                    $facility_city[$idx],
                    $facility_state[$idx],
                    $facility_zip[$idx],
                    $unique_id[$idx],
                    $idx
                ];
            }

            $collectResult = collect($result)->chunk(2000);
            // store devices in  database
            $collectResult->each(function ($query) {
                foreach ($query as $key => $value) {

                    if (isset($value[2]) && !empty($value[2]) && $value[2] != 'N/A') {
                        $device = Device::updateOrCreate(['row_id' => $value[19]]);
                        $device->unique_id = $value[18];
                        $device->device_sn = $value[0] ?? '';
                        $device->device_imei = $value[1] ?? '';
                        $device->tmobile_sim = $value[2] ?? '';
                        $device->tmobile_msisdn = $value[3] ?? '';
                        $device->nick_name = $value[5] ?? '';
                        $device->billing_address = $value[6] ?? '';
                        $device->billing_city = $value[7] ?? '';
                        $device->billing_state = $value[8] ?? '';
                        $device->billing_zip = $value[9] ?? '';
                        $device->email = $value[10] ?? '';
                        $device->phone = $value[11] ?? '';
                        $device->account_name = $value[12] ?? '';
                        $device->facility_name = $value[13] ?? '';
                        $device->facility_address = $value[14] ?? '';
                        $device->facility_city = $value[15] ?? '';
                        $device->facility_state = $value[16] ?? '';
                        $device->facility_zip = $value[17] ?? '';
                        $device->row_id = $value[19] ?? '';
                        $device->save();
                    }
                }
            });
        } catch (Exception $e) {
            dd($e);
            $this->failed($e);
        }
    }
    public function failed($exception)
    {

        $exception->getMessage();
    }
}

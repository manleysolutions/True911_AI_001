<?php

namespace App\Jobs;

use App\Models\ManageNumber;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;

class FetchStatus implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public $twilio;
    public function __construct()
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        $this->twilio = new Client($sid, $token);
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try{
            $context = $this->twilio->getAccount();
            $activeNumbers = $context->incomingPhoneNumbers;
            $activeNumberArray = $activeNumbers->read();
            foreach ($activeNumberArray as $key => $value) {
                $status = $value->emergencyAddressStatus;
                $data[] = ManageNumber::withTrashed()->removeSpace($value->phoneNumber)
                    ->update([
                        'status' => $status
                    ]);      
            }
        } catch (Exception $e) {
            $this->failed($e);
        }
    }
    public function failed($exception) {

        $exception->getMessage();
    }
}

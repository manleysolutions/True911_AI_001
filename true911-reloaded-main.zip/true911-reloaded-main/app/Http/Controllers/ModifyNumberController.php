<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Device;
use App\Models\ManageNumber;
use Illuminate\Http\Request;

class ModifyNumberController extends Controller
{
    public function update($id, Request $request)
    {
        $device_data = Device::where('id', decrypt($id))->first();
        $numbers =  ManageNumber::whereNull('device_id')
            ->sort($request)
            ->orwhere('device_id', decrypt($id))
            ->search(request(['search']))
            ->paginate(10);

        return view('pages.devices.attach-number', compact('numbers', 'id', 'device_data'));
    }
}

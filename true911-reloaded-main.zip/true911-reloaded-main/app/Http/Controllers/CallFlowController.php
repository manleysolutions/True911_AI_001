<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Device;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Twilio\Rest\Client;

class CallFlowController extends Controller
{
    public $twilio;
    public $sid;

    public function __construct()
    {
        $this->sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($this->sid, $token);
    }

    public function index($id)
    {
        try {
            $flows = $this->twilio->studio->v1->flows->read(20);

            $device = Device::where('id', decrypt($id))->first();
            if (empty($device->number_id)) {

                return back()->with('warning', 'First Attach Number then attach call flow');
            }

            return view('pages.devices.call-flow-listing', compact('flows', 'id', 'device'));
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "flow_sid" => "required",
        ]);
        if ($validator->fails()) {

            return back()->with('error', 'Please choose any one call flow');
        }
        $validated = $validator->validated();

        try {
            $id = decrypt($request->id);
            $device = Device::with('manageNumber')->find($id);

            if ($validated['flow_sid'] == 'none') {
                $this->twilio->incomingPhoneNumbers($device->manageNumber->phone_number_sid)
                    ->update([
                        "voiceUrl" => ""
                    ]);
                $device->update([
                    'flow_sid' => NULL,
                    'flow_name' => NULL
                ]);

                return to_route('devices.index', ['linked_number' => 'link'])
                    ->with('success', 'Call flow unlinked successfully');
            }
            $flow = $this->twilio->studio->v1->flows($validated['flow_sid'])
                ->fetch();

            $this->twilio->incomingPhoneNumbers($device->manageNumber->phone_number_sid)
                ->update([
                    "voiceUrl" => "https://webhooks.twilio.com/v1/Accounts/" . $this->sid . "/Flows/" . $validated['flow_sid']
                ]);
            Device::FindOrFail($id)
                ->update([
                    'flow_sid' => $validated['flow_sid'],
                    'flow_name' => $flow->friendlyName
                ]);

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with('success', 'Call flow linked successfully');
        } catch (Exception $e) {

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with('error', 'Invalid request');
        }
    }
}
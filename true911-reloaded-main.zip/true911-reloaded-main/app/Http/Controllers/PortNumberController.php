<?php

namespace App\Http\Controllers;

use App\Models\PortNumber;
use App\Models\PortNumberDocument;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Validator;

class PortNumberController extends Controller
{

    public function index(Request $request)
    {
        try {
            if ($request->perPage == "All") {
                $perPage = 0;
            } else {
                $perPage = isset($request->perPage) ? $request->perPage : '10';
            }

            $portLists = PortNumber::search(request(['search']))
                ->dataFilter($request)
                ->sort($request)
                ->orderBy('updated_at', 'desc')
                ->paginate($perPage);

            return view('pages.port-numbers.index', compact('portLists'));
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
    public function create()
    {

        return view('pages.port-numbers.create');
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "first_name" => "required|string|min:3|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "last_name" => "required|string|min:3|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "address" => "required|max:255",
                "address_2" => "nullable|max:255",
                "city" => "required|max:40",
                "state" => "required|max:40",
                "postal_code" => 'required|max:40',
                "number" => "required|digits:10|regex:/^[1-9]{1}[0-9]{9}$/|unique:port_numbers",
                "account_number" => "required",
                "option" => "required",
                "pin" => "required|digits:4",
                'letter_authorization' => "required|mimes:pdf|max:4096",
                'billing_statement' => "required|mimes:pdf|max:4096",
            ]);
            if ($validator->fails()) {

                return back()->withErrors($validator)->withInput();
            }

            $validated = $validator->validated();
            $validated['status'] = PortNumber::PENDING;

            $port = PortNumber::create($validated);

            if ($request->file('letter_authorization')) {
                $file = $request->file('letter_authorization');
                $md_l = md5_file($file->getpathname()) . '.' . $file->extension();
                $md_ls = $file->getSize();

                $filename = $file->getClientOriginalName();
                $location = 'files';
                $file->storeAs($location, $md_l);
                //   Storage::disk('local')->put('images/1/smalls'.'/'.$fileName, $img, 'public');

                $document = new PortNumberDocument();
                $document->md5_checksum = $md_l;
                $document->port_number_id = $port->id;
                $document->display_name = $filename;
                $document->size = $md_ls;
                $document->document_type = "Authorization";
                $document->save();
            }

            if ($request->file('billing_statement')) {
                $file = $request->file('billing_statement');
                $md_b = md5_file($file->getpathname()) . '.' . $file->extension();
                $md_bs = $file->getSize();
                $filename_billing = $file->getClientOriginalName();
                $location = 'files';
                $file->storeAs($location, $md_b);
                $document = new PortNumberDocument();
                $document->md5_checksum = $md_b;
                $document->port_number_id = $port->id;
                $document->display_name = $filename_billing;
                $document->size =  $md_bs;
                $document->document_type = "Billing";
                $document->save();
            }

            return to_route('ported-number-listing')
                ->with("success", 'Port Request Sent Successfully.');
        } catch (Exception $e) {

            return back()->with($e->getMessage());
        }
    }

    public function edit($id)
    {
        try{

            $portNumber = PortNumber::with('document')->find($id);
            
            if ($portNumber['status'] == 'PENDING') {
                $types = ['Pending', 'Port Requested', 'Port Cancelled'];
            } elseif ($portNumber['status'] == 'REJECTED') {
                $types = ['Port Rejected'];
            } elseif ($portNumber['status'] == 'REQUESTED') {
                $types = ['Port Requested', 'Port Successful', 'Port Rejected'];
            } elseif ($portNumber['status'] == 'CANCELLED') {
                $types = ['Port Cancelled'];
            } else {
                $types = ['Port Successful'];
            }
            
            return view('pages.port-numbers.view', compact('portNumber', 'types'));
        } catch (Exception $e) {

            return back()->with($e->getMessage());
        }
    }

    public function update(PortNumber $port_number, Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "first_name" => "required|string|min:3|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "last_name" => "required|string|min:3|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "address" => "required|max:255",
                "address_2" => "nullable|max:255",
                "city" => "required|max:40",
                "state" => "required|max:40",
                "postal_code" => 'required|max:40',
                "number" => "required|digits:10|regex:/^[1-9]{1}[0-9]{9}$/|unique:port_numbers,number," . $port_number->id,
                "account_number" => "required",
                "pin" => "required|digits:4",
                "letter_authorization" => "nullable|mimes:pdf|max:4096",
                "billing_statement" => "nullable|mimes:pdf|max:4096",
                "comment" => "nullable|max:150",
                "cancel_comment" => "nullable|max:150",
                "request_date" => "nullable",
                "status" => "required"
                // 'image' => [ 'nullable','image','mimes:jpg,png,jpeg' ],
            ]);
            if ($validator->fails()) {

                return back()->withErrors($validator)->withInput();
            }
            $validated = $validator->validated();
            
            if ($validated['status'] == "Pending") {
                $validated['status'] = PortNumber::PENDING;
            } elseif ($validated['status'] == "Port Successful") {
                $validated['request_date'] = $port_number['request_date'];
                $validated['status'] = PortNumber::SUCCESSFULLY;
            } elseif ($validated['status'] == "Port Rejected") {
                $validated['request_date'] = $port_number['request_date'];
                $validated['status'] = PortNumber::REJECTED;
            } elseif ($validated['status'] == "Port Cancelled") {
                $validated['status'] = PortNumber::CANCELLED;
            } else {
                $validated['status'] = PortNumber::REQUESTED;
                if (empty($validated['request_date'])) {
                    $validated['request_date'] = $port_number['request_date'];
                }
            }
            $port_number->update($validated);

            if ($request->file('letter_authorization')) {
                PortNumberDocument::where([
                    'port_number_id' => $port_number['id'],
                    'document_type' => 'Authorization'
                ])->delete();
                $file = $request->file('letter_authorization');

                $md_l = md5_file($file->getpathname()) . '.' . $file->extension();
                $md_ls = $file->getSize();
                $filename = $file->getClientOriginalName();
                $location = 'files';
                $file->storeAs($location, $md_l);
                //   Storage::disk('local')->put('images/1/smalls'.'/'.$fileName, $img, 'public');
                $document = new PortNumberDocument();
                $document->md5_checksum = $md_l;
                $document->port_number_id = $port_number['id'];
                $document->display_name = $filename;
                $document->size = $md_ls;
                $document->document_type = "Authorization";
                $document->save();
            }

            if ($request->file('billing_statement')) {
                PortNumberDocument::where([
                    'port_number_id' => $port_number['id'],
                    'document_type' => 'Billing'
                ])->delete();
                $file = $request->file('billing_statement');
                $md_b = md5_file($file->getpathname()) . '.' . $file->extension();
                $md_bs = $file->getSize();
                $filename_billing = $file->getClientOriginalName();
                $location = 'files';
                $file->storeAs($location, $md_b);
                $document = new PortNumberDocument();
                $document->md5_checksum = $md_b;
                $document->port_number_id = $port_number['id'];
                $document->display_name = $filename_billing;
                $document->size =  $md_bs;
                $document->document_type = "Billing";
                $document->save();
            }

            return to_route('ported-number-listing')
                ->with("success", 'Port Request Update Successfully.');
        } catch (Exception $e) {

            return back()->with($e->getMessage());
        }
    }

    public function download($file)
    {
        try {

            $path = PortNumberDocument::where('id', $file)->first();
            
            return response()
                ->download(storage_path('app/public/files/' . $path['md5_checksum']), $path['display_name']);
        } catch (Exception $e) {

            return back()->with($e->getMessage());
        }
    }
}

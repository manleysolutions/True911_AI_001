<?php

namespace App\Http\Controllers;

use App\Models\Device;
use App\Models\ManageNumber;
use App\Models\RecentCallLog;
use Exception;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request) {
        try {
            
            $devices = Device::where('tmobile_sim', '!=', '')
                ->where('tmobile_sim', 'REGEXP', '^[0-9]+$')
                ->where('device_sn', '!=', '')
                ->count();
            
            $linked_devices = Device::whereNotNull('number_id')
                ->count();
            
            $numbers = ManageNumber::count();

            $recent_call_logs = RecentCallLog::orderBy('updated_at', 'desc')
                ->take(5)
                ->get();    
            
            return view ('pages.dashboard', compact (
                'devices', 
                'linked_devices', 
                'numbers', 
                'recent_call_logs'
            ));     
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
}
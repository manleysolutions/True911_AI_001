<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessReleaseNumber;
use App\Models\CallLog;
use App\Models\Country;
use App\Models\Device;
use App\Models\ManageNumber;
use Illuminate\Http\Request;
use Twilio\Rest\Client;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ManageNumberController extends Controller
{
    public $twilio;

    public function __construct()
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($sid, $token);
    }

    public function index(Request $request)
    {
        try {

            if ($request->perPage == "All") {
                $perPage = '';
            } else {
                $perPage = isset($request->perPage) ? $request->perPage : '10';
            }
            if ($request->linked_number == 'released') {
                $items = ManageNumber::search(request(['search']))
                    ->sort($request)
                    ->orderBy('updated_at', 'desc')
                    ->onlyTrashed('deleted_at')
                    ->paginate($perPage);
            } else {
                $items = ManageNumber::search(request(['search']))
                    ->sort($request)
                    ->with('device')
                    ->orderBy('updated_at', 'desc')
                    ->whereNull('deleted_at')
                    ->paginate($perPage);
            }
            foreach ($items as $key => $item) {
                if ($item->device) {
                    if (is_numeric($item->device->device_sn)) {
                        $items[$key]->device->device_sn = number_format($item->device->device_sn, 0, '', '');
                    }
                }
            }

            return view('pages.manage-numbers.index', compact('items'));
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }

    public function create()
    {
        return view('pages.manage-numbers.create', [
            'countriesList' => Country::get(),
            'avilableData' => [],
        ]);
    }

    public function search(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "country" => "required",
            "criteria" => "nullable|integer|gt:0",
            "matchTo" => "nullable|integer",
            "capabilities" => "nullable",
            "numberType" => "nullable|in:local,mobile,tollFree",
        ]);

        if ($validator->fails()) {

            return back()->withErrors($validator)->withInput();
        }

        $validated = $validator->validated();
        $country = $validated['country'];
        $capabilities = $request->capabilities;
        $criteria = $validated['criteria'];
        $matchTo = $validated['matchTo'];
        $numberType = $validated['numberType'];

        // Add registration data to modal
        try {

            $containtVal = ManageNumber::ContainVal($validated);

            $pricing = $this->twilio->pricing->v1->phoneNumbers
                ->countries($country)
                ->fetch();

            if ($numberType) {
                $available_number = ManageNumber::NumberType($validated, $containtVal);

                $pricing = $pricing->priceUnit . " " . $pricing->phoneNumberPrices[0]["base_price"];
            }

            if (count($available_number) == 0) {
                //Toastr message 
                return to_route('manage-numbers.create')
                    ->with('error', 'Data doesn`t exist');
            }
            $avilableData = [];
            foreach ($available_number as $value) {
                $avilableData[] = [
                    "phoneNumber" =>  ManageNumber::FormatNumber($value->phoneNumber, $country),
                    "type" => $numberType,
                    "voice" => $value->capabilities["voice"],
                    "sms" => $value->capabilities["SMS"],
                    "addressRequirements" => $value->addressRequirements,
                    "selectedCountry" => $country,
                    "pricing" => $pricing,
                ];
            }
            $countriesList = Country::get();

            return view('pages.manage-numbers.create', [
                "avilableData" => $avilableData,
                "countriesList" => $countriesList,
                "selectedCountry" => $country,
                "criteria" =>  $criteria,
                "matchTo" => $matchTo,
                "numberType" => $numberType,
                "capabilities" => $capabilities
            ]);
        } catch (Exception $e) {

            if ($e->getcode() == 20404) {

                return to_route('manage-numbers.create')
                    ->with('error', 'No data found');
            } else {

                return to_route('manage-numbers.create')
                    ->with('error', $e->getMessage());
            }
        }
    }
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "friendlyName" => "required|min:2|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
            "phoneNumber" => "required",
            "country" => "required"
        ]);

        if ($validator->fails()) {

            return to_route('manage-numbers.create')
                ->with('error', 'Please enter valid inputs');
        }

        $validated = $validator->validated();
        $fullName = $validated['friendlyName'];
        $countryCode = $validated['country'];
        $phoneNumber = $validated['phoneNumber'];
        $userId = Auth::id();

        try {

            $url = url("/");
            $pParams = [
                "friendlyName" => $fullName,
                "phoneNumber" => $phoneNumber,
                "voiceMethod" => "GET",
                "voiceUrl" =>
                $url . "/config/call-webhook-handler/" . Auth::id(),
                "smsMethod" => "GET",
                "smsUrl" => $url . "/call-system/SmsNotify/" . Auth::id(),
            ];

            $incomingPhoneNumber = $this->twilio->incomingPhoneNumbers->create(
                $pParams
            );

            $attribute = [
                "user_id" => $userId,
                "manage_number" => $phoneNumber,
                "phone_number_sid" =>  $incomingPhoneNumber->sid,
                "nick_name" => $fullName,
                "purchase_date" => now(),
                "country" => $countryCode,
            ];

            ManageNumber::create($attribute);

            return to_route('manage-numbers', ['linked_number' => 'unlink'])
                ->with('success', 'Number purchased successfully !');
        } catch (Exception $e) {

            return to_route('manage-numbers.create')
                ->with('error', $e->getMessage());
        }
    }
    public function edit($id)
    {
        try {
            $data = ManageNumber::with('device')
                ->where('id', decrypt($id))
                ->first();

            return view('pages.manage-numbers.edit', compact('data'));
        } catch (Exception $e) {

            return back()->with('error', 'Record not found');
        }
    }
    public function update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            "id" => "required",
            "nickName" => "required|string|min:3|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
            "phoneNumberSid" => "required",
        ]);

        if ($validator->fails()) {

            return back()->withErrors($validator)->withInput();
        }

        $validated = $validator->validated();
        $fullName = $validated['nickName'];
        if ($validator->fails()) {

            return back()->withErrors($validator)->withInput();
        }
        try {

            $incomingPhoneNumber = $this->twilio->incomingPhoneNumbers($validated['phoneNumberSid'])
                ->update([
                    "friendlyName" => $fullName,
                ]);
            ManageNumber::where('id', decrypt($validated['id']))->update(['nick_name' => $fullName]);

            return to_route('manage-numbers', ['linked_number' => 'link'])->with("success", 'Name updated Succesfully');
        } catch (Exception $e) {

            return back()->with("error", $e->getMessage());
        }
    }
    public function destroy(Request $request)
    {
        $id = decrypt($request->id);
        $data = ManageNumber::where('id', $id)->first();
        // /** Initialize the Twilio client so it can be used */
        try {
            $fetchRecord = $this->twilio->incomingPhoneNumbers($data->phone_number_sid)
                ->fetch();
            if ($fetchRecord->emergencyAddressStatus == "registered") {
                $this->twilio->incomingPhoneNumbers($data->phone_number_sid)
                    ->update([
                        "emergencyAddressSid" => NULL
                    ]);
            }
            $device = Device::find($data->device_id);
            if ($device) {
                $device->update([
                    'number_id' => NULL
                ]);
                if ($device->flow_sid) {
                    $device->update([
                        'flow_sid' => NULL,
                        'flow_name' => NULL
                    ]);
                }
                $data->update([
                    'device_id' => NULL,
                    'status' => 'pending-unregistration'
                ]);
            }
            ProcessReleaseNumber::dispatch($data)
                ->delay(now()->addMinutes(5));

            $data->delete();

            return back()->with("success", 'Phone Number deleted succesfully');
        } catch (Exception $e) {

            if ($e->getCode() == 21631) {

                return back()->with("error", 'Unable to delete record: Please remove the emergency address on this number before performing this action.');
            } else if ($e->getCode() == 20404) {
                ManageNumber::where('id', $data->id)->delete();

                return back()->with("success", 'Phone Number deleted succesfully.');
            }

            return back()->with("success", $e->getMessage());
        }
    }

    public function view_call_logs($id, Request $request)
    {
        try {
            $number = ManageNumber::withTrashed()->find(decrypt($id));
            $phone_number = CallLog::formatNumber($number->manage_number);
            $call_logs = CallLog::where('phone_number', $phone_number)
                ->search(request(['search']))
                ->sort($request)
                ->dataFilter($request)
                ->paginate('10');
            $uniqueId = CallLog::where('phone_number', $phone_number)
                ->select('unique_id')
                ->groupBy('unique_id')
                ->get();
            foreach ($uniqueId as $key => $value) {
                $uniqueId[$key]['unique_id'] = $value->unique_id;
                $data = CallLog::where('unique_id', $value->unique_id)->first();
                $uniqueId[$key]['facility_name'] = $data->facility_name;
            }

            return view('pages.manage-numbers.call-logs', compact('number', 'phone_number', 'call_logs', 'id', 'uniqueId'));
        } catch (Exception $e) {

            return back()->with('error', 'Record not found');
        }
    }
}

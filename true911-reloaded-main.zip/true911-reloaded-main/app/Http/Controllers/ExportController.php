<?php

namespace App\Http\Controllers;

use App\Exports\CallLogExport;
use App\Models\CallLog;
use App\Models\ManageNumber;
use Exception;
use Twilio\Rest\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class ExportController extends Controller
{
    public $twilio;

    public function __construct()
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($sid, $token);
    }
    public function get_number(Request $request)
    {
        try {
            $devices = $request->devices;
            $phoneNumber = [];
            if ($devices) {
                $phoneNumber = CallLog::whereIn('unique_id', $devices)
                    ->select('phone_number')
                    ->groupBy('phone_number')
                    ->get();
                foreach ($phoneNumber as $key => $value) {
                    $number = CallLog::formatNumber(substr($value->phone_number, 1));
                    $nickName = ManageNumber::withTrashed()
                        ->where('manage_number', $number)
                        ->first();
                    $phoneNumber[$key]['nick_name'] =  $nickName ? $nickName->nick_name :  '';
                }
            }

            return  response()->json($phoneNumber);
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
    public function export(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "devices" => "required",
                "number" => "required",
                "data_filter" => "required",
            ]);
            
            if ($validator->fails()) {

                return back()->withErrors($validator)->withInput();
            }

            return Excel::download(new CallLogExport($request), 'calllog.csv');
        } catch (Exception $e) {
 
            return back()->with('error', $e->getMessage());
        }
    }
}
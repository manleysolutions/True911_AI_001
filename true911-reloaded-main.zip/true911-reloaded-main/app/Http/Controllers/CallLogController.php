<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\CallLog;
use App\Models\ManageNumber;
use Exception;
use Illuminate\Http\Request;

class CallLogController extends Controller
{
    public function index(Request $request)
    {
        try {
            $numbers = CallLog::select('phone_number')
                ->groupBy('phone_number')
                ->get();
            $uniqueId = CallLog::select('unique_id')
                ->groupBy('unique_id')
                ->get();
             
             
            foreach ($numbers as $key => $value) {
                $number = CallLog::formatNumber(substr($value->phone_number, 1));
                $nickName = ManageNumber::withTrashed()
                    ->where('manage_number', $number)
                    ->first();
                $data = CallLog::where('phone_number', $value->phone_number)
                    ->first();
                $numbers[$key]['id'] = $data->id;
                $numbers[$key]['phone_number'] = CallLog::formatNumber(substr($value->phone_number, 1));
                $numbers[$key]['nick_name'] = $nickName ? $nickName->nick_name :  '';
            }
            foreach($uniqueId as $key => $value){
                $uniqueId[$key]['unique_id'] = $value->unique_id;
                $data = CallLog::where('unique_id',$value->unique_id)->first();
                $uniqueId[$key]['facility_name'] = $data->facility_name;
            }
            if ($request->data_filter && $request->number) {
                if ($request->number == 'all' && $request->data_filter == 'all') {
                    $call_logs = CallLog::sort($request)
                        ->orderBy('updated_at', 'desc')
                        ->paginate(10);
                } else if ($request->data_filter != 'all' && $request->number == 'all') {
                    $call_logs = CallLog::sort($request)
                        ->dataFilter($request)
                        ->orderBy('updated_at', 'desc')
                        ->paginate(10);
                } else {
                    $call = CallLog::where('id', $request->number)->first();
                    $call_logs = CallLog::where('phone_number', $call->phone_number)
                        ->sort($request)
                        ->dataFilter($request)
                        ->orderBy('updated_at', 'desc')
                        ->paginate(10);
                }
            } else {
                $call = CallLog::where('id', $request->number)->first();
                if ($call) {
                    $call_logs = CallLog::where('phone_number', $call->phone_number)
                        ->sort($request)
                        ->orderBy('updated_at', 'desc')
                        ->paginate(10);
                } else {
                    $call_logs = CallLog::sort($request)
                        ->dataFilter($request)
                        ->orderBy('updated_at', 'desc')
                        ->paginate(10);
                }
            }
            if (count($call_logs) > 0) {
                foreach ($call_logs as $key => $val) {
                    $call_logs[$key]['phone_number'] = CallLog::formatNumber(substr($val->phone_number, 1));
                }
            }

            return view('pages.call-logs.index', compact('numbers', 'call_logs','uniqueId'));
        } catch (Exception $e) {

            return to_route('call-logs.index')
                ->with('error', 'Invalid request');
        }
    }
}
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Jobs\ProcessEditNumber;
use App\Models\Device;
use App\Models\ManageNumber;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Twilio\Rest\Client;

class DeviceLinkController extends Controller
{
    public $twilio;
    public $sid;

    public function __construct()
    {
        $this->sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($this->sid, $token);
    }

    public function index(Request $request,$id) {

        $number_data = '';
        $devices =  Device::whereNull('number_id')
            ->sort($request)
            ->where('device_sn','!=','')
            ->where('tmobile_sim', 'REGEXP', '^[0-9]+$')
            ->search(request(['search']))
            ->orderBy('updated_at', 'desc')
            ->paginate(10);
       
        return view('pages.manage-numbers.link-device', compact('devices', 'id', 'number_data'));
    }
    public function store(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            "device_id" => "required",
        ]);
        if ($validator->fails()) {
            
            return back()->with('error', 'Please choose any one device');
        }

        $validated = $validator->validated();

        try {
            $id = decrypt($id);
            $number =  ManageNumber::FindOrFail($id);
            
            if ($number->device_id) {
                return $this->update_device($validated, $id);
            }
            $device = Device::FindOrFail($validated['device_id']);
             
            if ($device->facility_address == 'N/A' || 
                $device->facility_address == 'PENDING' ||
                $device->facility_address == 'UNKNOWN' ||
                $device->facility_address == 'Unknown'
            ) {

                return back()->with('error', 'First add address then link device');
            }

            $address = $this->twilio->addresses->create(
                $device->facility_name, // customerName
                $device->facility_address, // street
                $device->facility_city, // street
                $device->facility_state, // street
                $device->facility_zip, // street
                'US', // isoCountry
                [
                    "friendlyName" =>  $device->facility_name,
                    "emergencyEnabled" => true,
                ]
            );
            $addressSid = $address->sid;
            

            $fetchRecord = $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->fetch();
                
            $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->update([
                    "emergencyAddressSid" => $addressSid,
                ]);
            $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->update([
                    "emergencyStatus" => "Active"
                ]);

            $status = $fetchRecord->emergencyAddressStatus;
            
        // Emergency address updated functionality //
            $number->update([
                'device_id' => $device->id,
                'status' => $status
            ]);
            $device->update([
                'number_id' => $number->id
            ]);

            return to_route('manage-numbers', ['linked_number' => 'link'])
                ->with('success', 'Device linked successfully');
        } catch (Exception $e) {
           
            return to_route('manage-numbers', ['linked_number' => 'link'])
                ->with('error', $e->getMessage());
        }
    }
    public function update_device($validated, $id) {
        try {
            $number =  ManageNumber::FindOrFail($id);
            $device = Device::FindOrFail($number->device_id);
            if ($validated['device_id'] != 'none') {

                $new_device_data = Device::FindOrFail($validated['device_id']);
                
                if ($new_device_data->facility_address == 'N/A' || 
                    $new_device_data->facility_address == 'PENDING' ||
                    $new_device_data->facility_address == 'UNKNOWN' ||
                    $new_device_data->facility_address == 'Unknown'
                ) {

                    return back()->with('error', 'First add facility address then link device');
                }

                $address = $this->twilio->addresses->create(
                    $new_device_data->nick_name, // customerName
                    $new_device_data->facility_address, // street
                    $new_device_data->facility_city, // street
                    $new_device_data->facility_state, // street
                    $new_device_data->facility_zip, // street
                    'US', // isoCountry
                    [
                        "friendlyName" =>  $new_device_data->nick_name,
                        "emergencyEnabled" => true,
                        ]
                    );
                    $addressSid = $address->sid;
                }
            $fetchRecord = $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->fetch();  
             //flow sid remove
             if ($device->flow_sid) {
                $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                    ->update([
                        "voiceUrl" => ""
                    ]);
                $device->update([
                    'flow_sid' => NULL,
                    'flow_name' => NULL
                ]);
            }
            if ($fetchRecord->emergencyAddressStatus == "registered") {
                $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                    ->update([
                        "emergencyAddressSid" => NULL,
                    ]);
            }
            $status = $fetchRecord->emergencyAddressStatus;
            $number->update([
                'device_id' => NULL,
                'status' => $status
            ]);
            $device->update([
                'number_id' => NULL
            ]);
            if ($validated['device_id'] == 'none') {

                return to_route('manage-numbers', ['linked_number' => 'link'])
                        ->with('success', 'Device unlinked successfully');;
            }
            $number->update([
                'device_id' => $new_device_data->id,
                'status' => 'pending-registration'
            ]);
            $new_device_data->update([
                'number_id' => $number->id
            ]);
            ProcessEditNumber::dispatch($number, $addressSid)
                    ->delay(now()->addMinutes(3));

        return to_route('manage-numbers', ['linked_number' => 'link'])
            ->with("success", 'Device Linked successfully');
         
        } catch (Exception $e) {
            
            return to_route('manage-numbers', ['linked_number' => 'link'])
                ->with('error', $e->getMessage());
        }
    }
}
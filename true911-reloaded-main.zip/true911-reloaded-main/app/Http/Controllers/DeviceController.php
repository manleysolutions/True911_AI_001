<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessEditNumber;
use App\Models\CallLog;
use App\Models\Device;
use App\Models\ManageNumber;
use Exception;
use Twilio\Rest\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;

class DeviceController extends Controller
{
    public $twilio;

    public function __construct()
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($sid, $token);
    }
    public function index(Request $request)
    {
        try {
            if ($request->perPage == "All") {
                $perPage = 0;
            } else {
                $perPage = isset($request->perPage) ? $request->perPage : '10';
            }

            $devices = Device::with('manageNumber')->where('tmobile_sim', '!=', '')
                ->where('tmobile_sim', 'REGEXP', '^[0-9]+$')
                ->where('device_sn', '!=', '')
                ->search(request(['search']))
                ->sort($request)->orderBy('updated_at', 'desc')
                ->paginate($perPage);

            return view('pages.devices.index', compact('devices'));
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
    public function view($id)
    {
        try {
            $device = Device::where('id', decrypt($id))
                ->with('manageNumber')
                ->first();

            return view('pages.devices.view', compact('device'));
        } catch (Exception $e) {

            return back()->with('error', 'Record not found');
        }
    }
    public function view_call_logs($id, Request $request)
    {
        try {
            $device = Device::with('manageNumber')
                ->where('id', decrypt($id))
                ->first();

            $number = '';
            if (!empty($device->manageNumber)) {
                $number = CallLog::formatNumber($device->manageNumber->manage_number);
                $call_logs = CallLog::where('phone_number', $number)
                    ->where('device_sn', $device->device_sn)
                    ->search(request(['search']))
                    ->sort($request)
                    ->dataFilter($request)
                    ->paginate('10');
            } else {
                $call_logs = CallLog::where('phone_number', $number)
                    ->where('device_sn', $device->device_sn)
                    ->search(request(['search']))
                    ->sort($request)
                    ->dataFilter($request)
                    ->paginate('10');
            }
            foreach ($call_logs as $key => $value) {
                $manage_number = ManageNumber::removeSpace($value->phone_number);
                if ($manage_number) {
                    $call_logs[$key]['device'] = $device;
                    $call_logs[$key]['number'] = $manage_number;
                }
            }

            $numbers = CallLog::where('unique_id',$device->unique_id)
                ->select('phone_number')
                ->groupBy('phone_number')
                ->get();
            foreach ($numbers as $key => $value) {
                $number = CallLog::formatNumber(substr($value->phone_number, 1));
                $nickName = ManageNumber::withTrashed()
                    ->where('manage_number', $number)
                    ->first();
                $data = CallLog::where('phone_number', $value->phone_number)
                    ->first();
                $numbers[$key]['id'] = $data->id;
                $numbers[$key]['phone_number'] = CallLog::formatNumber(substr($value->phone_number, 1));
                $numbers[$key]['nick_name'] = $nickName ? $nickName->nick_name :  '';
                $numbers[$key]['unique_id'] = $data->unique_id ?? '';
                $numbers[$key]['facility_name'] = $data->facility_name ?? '';
            }

            return view('pages.devices.call-logs', compact('device', 'call_logs', 'id','numbers'));
        } catch (Exception $e) {

            return back()->with('error', 'Record not found');
        }
    }
    public function facility_address_update(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "address" => "required|min:1|max:255",
                "city" => "required|min:2|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "stateProvision" => "required|min:2|max:40|regex:/^[a-zA-Z\pL\s\-]+$/u",
                "postalCode" => "required|min:1|max:40",
                "deviceId" => "required",
                'nick_name' => 'nullable',
            ]);
            if ($validator->fails()) {

                return back()
                    ->with('error', 'Please enter valid inputs');
            }
            $validated = $validator->validated();

            $device = Device::findOrFail($validated['deviceId']);
            if ($device->number_id) {

                return $this->update_address($validated, $device);
            }

            $fullName = 'user';
            $street = $validated['address'];
            $city = $validated['city'];
            $region = $validated['stateProvision'];
            $postalCode = $validated['postalCode'];
            $countryCode = 'US';
            $address = $this->twilio->addresses->create(
                $fullName, // customerName
                $street, // street
                $city, // city
                $region, // region
                $postalCode, // postalCode
                $countryCode, // isoCountry
                [
                    "friendlyName" => $fullName,
                    "emergencyEnabled" => true,
                ]
            );

            $addressSid = $address->sid;
            $this->smartSheetUpdate($validated, $device);

            $device->update([
                'facility_address' => $validated['address'],
                'facility_city' => $validated['city'],
                'facility_state' => $validated['stateProvision'],
                'facility_zip' => $validated['postalCode']
            ]);

            return back()->with('success', 'Address updated succesfully');
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
    public function update_address($validated, $device)
    {
        try {
            $numbers = ManageNumber::FindOrFail($device->number_id);

            $fullName = $numbers->nick_name;
            $street = $validated['address'];
            $city = $validated['city'];
            $region = $validated['stateProvision'];
            $postalCode = $validated['postalCode'];
            $countryCode = 'US';
            $address = $this->twilio->addresses->create(
                $fullName, // customerName
                $street, // street
                $city, // city
                $region, // region
                $postalCode, // postalCode
                $countryCode, // isoCountry
                [
                    "friendlyName" => $fullName,
                    "emergencyEnabled" => true,
                ]
            );

            $addressSid = $address->sid;
            $this->smartSheetUpdate($validated, $device);

            $fetchRecord = $this->twilio->incomingPhoneNumbers($numbers->phone_number_sid)
                ->fetch();

            if ($fetchRecord->emergencyAddressStatus == "registered") {
                $this->twilio->incomingPhoneNumbers($numbers->phone_number_sid)
                    ->update([
                        "emergencyAddressSid" => NULL,
                    ]);
            }
            $numbers->update(['status' => 'pending-registration']);

            ProcessEditNumber::dispatch($numbers, $addressSid)
                ->delay(now()->addMinutes(3));

            $device->update([
                'facility_address' => $validated['address'],
                'facility_city' => $validated['city'],
                'facility_state' => $validated['stateProvision'],
                'facility_zip' => $validated['postalCode']
            ]);

            return back()->with("success", 'Address updated successfully');
        } catch (Exception $e) {

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with('error', $e->getMessage());
        }
    }
    public function smartSheetUpdate($validated, $device)
    {
        try {
            $ssRowID = $device->row_id;
            $json = Http::withToken(config('services.smartsheet.SMARTSHEET_TOKEN'))
                ->accept('application/json')
                ->get(config('services.smartsheet.SMARTSHEET_URL') . '/rows/' . $ssRowID . '?include=discussions,attachments,columns,columnType');
            $obj = json_decode($json);
            $columnArray = [];
            foreach ($obj->columns as $key => $value) {
                $value->title == "FacilityAddress" ? $columnArray['facility_address'] = $value->id : '';
                $value->title == "FacilityCity" ? $columnArray['facility_city'] = $value->id : '';
                $value->title == "FacilityState" ? $columnArray['facility_state'] = $value->id : '';
                $value->title == "FacilityZipCode" ? $columnArray['facility_zip'] = $value->id : '';
            }

            $values['facility_address'] = $validated['address'] ?? '';
            $values['facility_city'] = $validated['city'] ?? '';
            $values['facility_state'] = $validated['stateProvision'] ?? '';
            $values['facility_zip'] = $validated['postalCode'] ?? '';

            $SSAPIToken = config('services.smartsheet.SMARTSHEET_TOKEN');
            $sheetsURL = config('services.smartsheet.SMARTSHEET_URL') . '/rows';
            $data_json = '[{"id": "' . $ssRowID . '", "cells": [{"columnId": ' . $columnArray['facility_address'] . ',"value": "' . $values['facility_address'] . '","displayValue": "' . $values['facility_address'] . '"},{"columnId": ' . $columnArray['facility_city'] . ',"value": "' . $values['facility_city'] . '","displayValue": "' . $values['facility_city'] . '"},{"columnId": ' . $columnArray['facility_state'] . ',"value": "' . $values['facility_state'] . '","displayValue": "' . $values['facility_state'] . '"},{"columnId": ' . $columnArray['facility_zip'] . ',"value": "' . $values['facility_zip'] . '","displayValue": "' . $values['facility_zip'] . '"}]}]';
            $headers = array(
                "Authorization: Bearer " . $SSAPIToken,
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_json)
            );
            /*
            *   connect to SS and update Sheet
            */
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $sheetsURL);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_VERBOSE, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
            $data = curl_exec($ch);
            $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);   //get status code
            $curl_errno = curl_errno($ch);
            $curl_error = curl_error($ch);
            $information = curl_getinfo($ch);
            curl_close($ch);

            return true;
        } catch (Exception $e) {

            return back()->with('error', $e->getMessage());
        }
    }
}
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Device;
use App\Models\ManageNumber;
use Illuminate\Http\Request;

class ModifyDeviceController extends Controller
{
    public function update($id, Request $request)
    {
        $number_data = ManageNumber::where('id', decrypt($id))->first();
        $devices =  Device::whereNull('number_id')
            ->where('device_sn', '!=', '')
            ->where('tmobile_sim', 'REGEXP', '^[0-9]+$')
            ->sort($request)
            ->orwhere('number_id', decrypt($id))
            ->search(request(['search']))
            ->orderBy('updated_at', 'desc')
            ->paginate(10);

        foreach ($devices as $key => $device) {
            if (is_numeric($device->device_sn)) {
                $devices[$key]['device_sn'] = number_format($device->device_sn, 0, '', '');
            }
            if (is_numeric($device->device_imei)) {
                $devices[$key]['device_imei'] = number_format($device->device_imei, 0, '', '');
            }
        }

        return view('pages.manage-numbers.link-device', compact('devices', 'id', 'number_data'));
    }
}

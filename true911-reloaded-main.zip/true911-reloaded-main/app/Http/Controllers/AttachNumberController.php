<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Jobs\ProcessEditNumber;
use App\Models\Device;
use App\Models\ManageNumber;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Twilio\Rest\Client;

class AttachNumberController extends Controller
{
    public $twilio;
    public $sid;

    public function __construct()
    {
        $this->sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($this->sid, $token);
    }

    public function index($id, Request $request)
    {

        $device_data = '';
        $device = Device::where('id', decrypt($id))->first();
        $numbers =  ManageNumber::whereNull('device_id')
            ->whereNull('deleted_at')
            ->search(request(['search']))
            ->sort($request)
            ->paginate(10);

        if (empty($device->facility_address) ||
            $device->facility_address == 'N/A' ||  
            $device->facility_address == 'PENDING' ||  
            $device->facility_address == 'NEED INFO') {
                
            return back()
                ->with('warning', 'First add address then you will enable to attach number');
        }

        return view('pages.devices.attach-number', compact('numbers', 'id', 'device_data'));
    }
    public function store(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            "number_id" => "required",
        ]);
        if ($validator->fails()) {

            return back()->with('error', 'Please choose any one number');
        }

        $validated = $validator->validated();

        try {
            $id = decrypt($id);
            $device = Device::FindOrFail($id);

            if ($device->number_id) {

                return $this->update_number($validated, $id);
            }

            // Emergency address added functionality//
            $address = $this->twilio->addresses->create(
                $device->facility_name, // customerName
                $device->facility_address, // street
                $device->facility_city, // street
                $device->facility_state, // street
                $device->facility_zip, // street
                'US', // isoCountry
                [
                    "friendlyName" =>  $device->facility_name,
                    "emergencyEnabled" => true,
                ]
            );
            $addressSid = $address->sid;
            $number = ManageNumber::where('id', $validated['number_id'])->first();

            $fetchRecord = $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->fetch();

            $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->update([
                    "emergencyAddressSid" => $addressSid,
                ]);
            $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->update([
                    "emergencyStatus" => "Active"
                ]);
            $status = $fetchRecord->emergencyAddressStatus;

            // Emergency address updated functionality //
            $number->update([
                'device_id' => $id,
                'status' => $status
            ]);
            $device->update([
                'number_id' => $validated['number_id']
            ]);

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with('success', 'Number linked successfully');
        } catch (Exception $e) {

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with('error', $e->getMessage());
        }
    }
    public function update_number($validated, $id)
    {
        try {
            $device = Device::FindOrFail($id);
           if ($validated['number_id'] != 'none') {
                $address = $this->twilio->addresses->create(
                    $device->facility_name, // customerName
                    $device->facility_address, // street
                    $device->facility_city, // street
                    $device->facility_state, // street
                    $device->facility_zip, // street
                    'US', // isoCountry
                    [
                        "friendlyName" =>  $device->facility_name,
                        "emergencyEnabled" => true,
                    ]
                );
                $addressSid = $address->sid;
           }
            $number = ManageNumber::FindOrFail($device->number_id);
            $fetchRecord = $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                ->fetch();
            //flow sid remove
            if ($device->flow_sid) {
                $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                    ->update([
                        "voiceUrl" => ""
                    ]);
                $device->update([
                    'flow_sid' => NULL,
                    'flow_name' => NULL
                ]);
            }
            if ($fetchRecord->emergencyAddressStatus == "registered") {
                $this->twilio->incomingPhoneNumbers($number->phone_number_sid)
                    ->update([
                        "emergencyAddressSid" => NULL,
                    ]);
            }
            $status = $fetchRecord->emergencyAddressStatus;
            $number->update([
                'device_id' => NULL,
                'status' => $status
            ]);
            $device->update([
                'number_id' => NULL
            ]);

            if ($validated['number_id'] == 'none') {

                return to_route('devices.index', ['linked_number' => 'link'])
                    ->with('success', 'Number unlinked successfully');
            }
            $new_number_data = ManageNumber::FindOrFail($validated['number_id']);
            $new_number_data->update([
                'device_id' => $id,
                'status' => 'pending-registration'
            ]);
            $device->update([
                'number_id' => $validated['number_id']
            ]);

            ProcessEditNumber::dispatch($new_number_data, $addressSid)
                    ->delay(now()->addMinutes(3));

            return to_route('devices.index', ['linked_number' => 'link'])
                ->with("success", 'Address Updated Successfully');
        } catch (Exception $e) {
            
            return back()->with('error', $e->getMessage());
        }
    }
}
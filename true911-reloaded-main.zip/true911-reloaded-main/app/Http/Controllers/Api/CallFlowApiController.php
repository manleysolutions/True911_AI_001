<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CallLog;
use App\Models\Device;
use App\Models\ManageNumber;
use App\Models\RecentCallLog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Twilio\Rest\Client;

class CallFlowApiController extends Controller
{
    public $twilio;
    public $sid;

    public function __construct()
    {
        $sid = config('services.twilio.TWILIO_ACCOUNT_SID');
        $token = config('services.twilio.TWILIO_AUTH_TOKEN');
        // /** Initialize the Twilio client so it can be used */
        $this->twilio = new Client($sid, $token);
    }

    public function verify(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "From" => "required",
                "To" => "required",
            ]);
            if ($validator->fails()) {

                return response()->json([
                    'message' => $validator->errors()->all(),
                    'statusCode' => '400'
                ], 400);
            }

            $validated = $validator->validated();
            $from = $validated['From']; //Device Sim
            $to = CallLog::formatNumber($validated['To']);//Twilio Number 
            $numberId = ManageNumber::removeSpace($to);
            if ($numberId) {
                $verify = Device::where('number_id', $numberId->id)
                            ->count();
            } 
            if ($numberId && $verify > 0) {

                return response()->json([
                    'message' => 'Your request verified',
                    'statusCode' => '200'
                ], 200);
            } else {

                return response()->json([
                    'message' => 'Unauthorized request',
                    'statusCode' => '401'
                ], 401); 
            }
        } catch (Exception $e) {

            return response()->json([
                'message' => $e->getMessage(),
                'statusCode' => '500'
            ], 500);
        }
    }
    public function calls(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                "DialCallSid" => "nullable",
                "DialCallStatus" => "nullable",
                "DialCallDuration" => "nullable",
                "RecordingUrl" => "nullable",
                "To" => "required",
            ]);

            if ($validator->fails()) {

                return response()->json([
                    'message' => $validator->errors()->all(),
                    'statusCode' => '400'
                ], 400);
            }
        
            $validated = $validator->validated();
            $number = ManageNumber::removeSpace($validated['To']);

            if ($number) {
                $device = Device::where('number_id', $number->id)->first();
            }

            $data = [
                'dial_call_sid' => $validated['DialCallSid'],
                'dial_call_status' => $validated['DialCallStatus'],
                'duration' => $validated['DialCallDuration'],
                'call_recording' => $validated['RecordingUrl'],
                'phone_number' => $validated['To'],
                'device_sn' => $device->device_sn ?? '',
                'unique_id' => $device->unique_id ?? '',
                'facility_name' => $device->facility_name ?? '',
                'facility_address' => $device->facility_address ?? '',
                'facility_city' => $device->facility_city ?? '',
                'facility_state' => $device->facility_state ?? '',
                'facility_zip' => $device->facility_zip ?? '',
                'nick_name' => $number->nick_name ?? '',
                'flow_name' => $device->flow_name ?? '',
                'flow_sid' =>  $device->flow_sid ?? '',
            ];

            $storeData = CallLog::create($data);

            $call = $this->twilio->calls($storeData['dial_call_sid'])
                ->fetch();

            $price = $call->price;
            $storeData->update([
                'price' => $price
            ]);
            $recent_call_logs = RecentCallLog::orderBy('updated_at', 'desc')
                ->take(5)
                ->get();

            if (!empty($recent_call_logs) && count($recent_call_logs) == 5) {
                $recent_call_logs = RecentCallLog::orderBy('id')
                    ->limit(1)
                    ->delete();
            }

            RecentCallLog::create($data);

            return response()->json([
                'message' => 'Data added successfully',
                'statusCode' => '200'
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'message' => $e->getMessage(),
                'statusCode' => '500'
            ], 500);
        }
    }
}
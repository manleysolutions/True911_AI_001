<!DOCTYPE html>
<html class="h-full" lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') | {{ __('True911') }}</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/toastr.min.css') }}">
    @stack('css')
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
</head>

<body x-data="{ sidebar: false, rightSidebar: false, isOpen:
        false,loading:false, modal: false, getPhoneNumber:
        '',getId:'',getFacilityAddress:'',getFacilityCity:'',getFacilityState:'',getFacilityZip:'',selectedCountry:
        '', 'pricing': '', 'voice': '', 'sms': '' , 'showModal': false }">
    <div class="min-h-screen flex bg-gray-100 text-gray-700">
        <!-- Header -->
        @include('elements.partials.sidebar')
        <!-- Header -->
        <main class="flex-1 overflow-auto lg:ml-64 transition ease-in-out
                translate-x-0 h-screen flex flex-col relative" x-bind:class="{ 'overflow-auto': !rightSidebar }" id="main">
            @include('elements.partials.header')
            <!-- <div class="pageLoading" id="pageLoading"></div> -->
            @yield('content')
        </main>
    </div>
    @stack('modals')
    <script src="{{ asset('js/multiselect-dropdown.js') }}"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="{{asset('js/toastr.min.js')}}"></script>
    <script src="{{asset('js/custom.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"> </script>
    <!-- Select2 CSS -->
    <link href="{{asset('css/select2.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <!-- Select2 JS -->
    <script src="{{ asset('js/select2.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script>
        function linkedForm(data) {
            document.getElementById('linked_number').value = data;
            document.getElementById('linkedForm').submit();
        }

        $(".selectNew").select2();

        @if(Session::has('message'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("{{ session('message') }}");
        @endif

        @if(Session::has('success'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("{{ session('success') }}");
        @endif

        @if(Session::has('error'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.error("{{ session('error') }}");
        @endif

        @if(Session::has('info'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.info("{{ session('info') }}");
        @endif

        @if(Session::has('warning'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.warning("{{ session('warning') }}");
        @endif
    </script>
    <script>
        $(document).ready(function() {
            $('#pageLoader').hide();
            $("#form").validate({
                rules: {
                    friendlyName: {
                        required: true,
                        maxlength: 40
                    },
                    address: {
                        required: true,
                        maxlength: 40
                    },
                    city: {
                        required: true,
                        maxlength: 30
                    },
                    stateProvision: {
                        required: true,
                        maxlength: 20
                    },
                    postalCode: {
                        required: true,
                        maxlength: 30
                    }
                },
                messages: {
                    friendlyName: {
                        required: "Please fill your name"
                    },
                    address: {
                        required: "Please fill your address"
                    },
                    city: {
                        required: "Please fill your city"
                    },
                    stateProvision: {
                        required: "Please fill your state/provision/region"
                    },
                    postalCode: {
                        required: "Please fill your postal code"
                    }
                },
                submitHandler: function() {
                    $(".pageLoader").show();
                    $('#form').submit();
                }
            });
        });
    </script>
    <!-- modals -->
    @stack('scripts')
</body>

</html>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">
        
        <!-- Scripts -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
<script type="text/javascript" src="{{ asset('js/app.js') }}"></script>

    </head>
    <body class="filament-body bg-gray-100 text-gray-900">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0  filament-login-page   justify-center  bg-gray-100 text-gray-900 py-12 ">
            <div>
                <a href="/">
                <!-- <div class="px-4 sm:px-6 lg:px-8 text-center mt-3 font-bold text-2xl mb-4 mt-6  pb-6">
          
            True911
        </div> -->
                </a>
            </div>

            <div class="w-full sm:max-w-md mt-6 px-8 py-4 bg-white  overflow-hidden sm:rounded-lg p-8 space-y-4 bg-white/50 backdrop-blur-xl border border-gray-200 shadow-2xl rounded-2xl relative">
                {{ $slot }}
            </div>
        </div>
    </body>
</html>
<style>
    .filament-login-page {
    background-image: radial-gradient(circle at top,#fef3c7,#fff 50%);
    background-repeat: no-repeat;
    position: relative;
}
</style>
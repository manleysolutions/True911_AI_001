<header id="header"
    class="border-b bg-white border-gray-200 py-4 px-4 sm:px-8 shadow flex justify-between items-center relative">
    <div class="flex items-center gap-2 justify-between sm:justify-start w-full sm:w-auto">
        <!-- Logo -->
        <a href="#" class="sm:hidden font-bold text-2xl">
            True911

        </a>
        <a href="javascript:void(0);" class="lg:hidden" @click="sidebar = !sidebar">
            <svg class="w-5 h-5" class="w-64 h-64" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="48" height="48" fill="white" fill-opacity="0.01"></rect>
                <path d="M7.94977 11.9498H39.9498" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round"></path>
                <path d="M7.94977 23.9498H39.9498" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round"></path>
                <path d="M7.94977 35.9498H39.9498" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round"></path>
            </svg>
        </a>
    </div>
    <nav class="hidden sm:block relative" @click.away="open = false" x-data="{ open: false }">
        <div class="flex items-center cursor-pointer" x-on:click="open = ! open">
            <button class="block flex items-center" aria-label="User menu">
                <div
                    class="w-9 h-9 ml-auto rounded-full bg-black bg-cover text-white bg-center font-semibold leading-9">
                    <?php $str = Auth::user()->name; 
                        echo substr($str, 0, 1);
                    ?></div>
            </button>
            <div style="display:none" x-show="open"
                class="z-10 absolute w-52 bg-white top-14 right-0 border border-gray-100 rounded shadow-lg">
                <ul class="py-1 text-sm text-gray-700" aria-labelledby="avatarButton">
                    <li>
                        <x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link>
                    </li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')" onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
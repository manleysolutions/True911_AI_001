<aside class="fixed z-10 h-screen shadow transition ease-in-out -translate-x-full lg:translate-x-0"
    :class="{ '-translate-x-full': !sidebar }" @keydown.window.escape="sidebar = false">
    <div class="fixed inset-0 z-10 bg-black/30 lg:hidden" @click="sidebar = false" :class="{ 'hidden': !sidebar }">
    </div>
    <nav x-data="{ open: false }" class="bg-white h-full flex flex-col w-64 relative z-20" @click.outside="open = false">
        <div class="px-4 sm:px-6 lg:px-8 text-center mt-3 font-bold text-2xl mb-4 mt-6 border-b pb-6">
            <!-- Logo -->
            <a href="{{ url('/') }}"> True911</a>
        </div>
        <!-- Primary Navigation Menu -->
        <div class="px-4 flex-1 overflow-auto">
            <div class="flex flex-col">
                <a class="inline-flex items-center mb-2 group hover:bg-orange-500 hover:text-white active:text-white px-3 py-3 rounded-lg text-sm {{ request()->is('dashboard') ? 'bg-orange-500 text-white' : 'text-gray-600' }} font-300 leading-5 focus:outline-none  transition duration-150 ease-in-out"
                    href="{{ URL::to('/dashboard') }}">
                    <svg class="mr-2 w-5 h-5  group-hover:text-current group-active:text-current"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" stroke-width="2"
                        stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6">
                        </path>
                    </svg>
                    {{ __('Dashboard') }}
                </a>
                <a class="inline-flex items-center mb-2 group hover:bg-orange-500 hover:text-white active:text-white px-3 py-3 rounded-lg text-sm {{ request()->is('devices*') || request()->is('call-flow*') || request()->is('attach-number*') || request()->is('view-device*') || request()->is('modify-number*') ? 'bg-orange-500 text-white' : 'text-gray-600' }} font-300 leading-5 focus:outline-none  transition duration-150 ease-in-out"
                    href="{{route('devices.index',['linked_number' => 'link']) }}">
                    <svg class="mr-2 w-5 h-5  group-hover:text-current group-active:text-current" fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path
                            d="M2 2h16v6h4v14H12v-6H2V2zm14 6V4H4v10h8V8h4zm-6-2H6v2h4V6zm10 14V10h-6v10h6zm-4-4h2v2h-2v-2zM6 10h4v2H6v-2z"
                            fill="currentColor"></path>
                    </svg>
                    {{ __('Devices') }}
                </a>
                <a class="inline-flex items-center mb-2 group hover:bg-orange-500 hover:text-white active:text-white px-3 py-3 rounded-lg text-sm {{ request()->is('call-logs*') || request()->is('call-logs*') ? 'bg-orange-500 text-white' : 'text-gray-600' }} font-300 leading-5 focus:outline-none  transition duration-150 ease-in-out"
                    href="{{ route('call-logs.index',['data_filter' => 'last_7_days']) }}">
                    <svg class="mr-2 w-5 h-5  group-hover:text-current group-active:text-current" viewBox="0 0 24 24"
                        fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M3.833 4h4.49L9.77 7.618l-2.325 1.55A1 1 0 0 0 7 10c.003.094 0 .001 0 .001v.021a2.129 2.129 0 0 0 .006.134c.006.082.016.193.035.33.039.27.114.642.26 1.08.294.88.87 2.019 1.992 3.141 1.122 1.122 2.261 1.698 3.14 1.992.439.146.81.22 1.082.26a4.424 4.424 0 0 0 .463.04l.013.001h.008s.112-.006.001 0a1 1 0 0 0 .894-.553l.67-1.34 4.436.74v4.32c-2.111.305-7.813.606-12.293-3.874C3.227 11.813 3.527 6.11 3.833 4zm5.24 6.486l1.807-1.204a2 2 0 0 0 .747-2.407L10.18 3.257A2 2 0 0 0 8.323 2H3.781c-.909 0-1.764.631-1.913 1.617-.34 2.242-.801 8.864 4.425 14.09 5.226 5.226 11.848 4.764 14.09 4.425.986-.15 1.617-1.004 1.617-1.913v-4.372a2 2 0 0 0-1.671-1.973l-4.436-.739a2 2 0 0 0-2.118 1.078l-.346.693a4.71 4.71 0 0 1-.363-.105c-.62-.206-1.481-.63-2.359-1.508-.878-.878-1.302-1.739-1.508-2.36a4.583 4.583 0 0 1-.125-.447z"
                            fill="currentColor"></path>
                    </svg>
                    {{ __('Call Logs') }}
                </a>

                <a class="inline-flex items-center mb-2 group hover:bg-orange-500 hover:text-white active:text-white px-3 py-3 rounded-lg text-sm {{ request()->is('manage-numbers*') || request()->is('link-device*')  || request()->is('modify-device*')? 'bg-orange-500 text-white' : 'text-gray-600' }} font-300 leading-5 focus:outline-none  transition duration-150 ease-in-out"
                    href="{{ route('manage-numbers', ['linked_number' => 'link']) }}">
                    <svg class="mr-2 w-5 h-5  group-hover:text-current group-active:text-current"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                        <path
                            d="M19 1H9c-1.1 0-2 .9-2 2v3h2V4h10v16H9v-2H7v3c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zM7.01 13.47l-2.55-2.55-1.27 1.27L7 16l7.19-7.19-1.27-1.27-5.91 5.93z">
                        </path>
                    </svg>
                    {{ __('Manage Numbers') }}
                </a>

                <a class="inline-flex items-center mb-2 group hover:bg-orange-500 hover:text-white active:text-white px-3 py-3 rounded-lg text-sm {{ request()->is('ported-number*') ? 'bg-orange-500 text-white' : 'text-gray-600' }} font-300 leading-5 focus:outline-none  transition duration-150 ease-in-out"
                    href="{{ route('ported-number-listing') }}">
                    <svg class="mr-2 w-5 h-5  group-hover:text-current group-active:text-current"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <g>
                            <path fill="none" d="M0 0h24v24H0z"></path>
                            <path
                                d="M6 4v16h12V7.828L14.172 4H6zM5 2h10l4.707 4.707a1 1 0 0 1 .293.707V21a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1zm8 8v8h-2v-6H8v-2h5zm-5 3h2v2H8v-2zm6 0h2v2h-2v-2zm0-3h2v2h-2v-2zm-6 6h2v2H8v-2zm6 0h2v2h-2v-2z">
                            </path>
                        </g>
                    </svg>
                    {{ __('Ported Numbers') }}
                </a>
            </div>
        </div>
        <form method="POST" class="mt-auto px-4 border-t py-2" action="{{ route('logout') }}">
            @csrf
            <x-dropdown-link :href="route('logout')"
                onclick="event.preventDefault();
                                this.closest('form').submit();">
                {{ __('Log Out') }}
            </x-dropdown-link>
        </form>

    </nav>
</aside>

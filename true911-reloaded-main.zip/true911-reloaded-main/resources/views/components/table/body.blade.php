<tbody class="divide-y divide-gray-200">
    {{ $slot ?? '' }}
</tbody>
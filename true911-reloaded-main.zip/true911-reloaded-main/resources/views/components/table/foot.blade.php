<tfoot>
    {{ $slot ?? '' }}
</tfoot>
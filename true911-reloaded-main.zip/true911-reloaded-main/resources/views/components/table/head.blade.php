<thead class="bg-white">
    {{ $slot ?? '' }}
</thead>
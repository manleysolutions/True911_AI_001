@props(['name'])

<th {{ $attributes([
    'class' => 'px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left'
    ]) }}>
    {{ $slot ?? '' }}
</th>
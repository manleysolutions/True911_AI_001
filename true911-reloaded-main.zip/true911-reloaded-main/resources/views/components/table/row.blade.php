<tr {{ $attributes(['class' => 'bg-white']) }}>
    {{ $slot ?? '' }}
</tr>
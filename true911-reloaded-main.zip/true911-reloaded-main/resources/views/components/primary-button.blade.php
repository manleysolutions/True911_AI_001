<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-block  py-2 bg-orange-500 text-white font-medium text-base
                leading-snug  rounded-lg shadow-md hover:bg-orange-500 hover:shadow-lg
                focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0
                active:bg-orange-500 active:shadow-lg transition duration-150
                ease-in-out w-full ripple-surface-light']) }}>
    {{ $slot }}
</button>

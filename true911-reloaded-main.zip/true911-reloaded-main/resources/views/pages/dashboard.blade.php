@extends('layouts.main')
@section('title', 'Dashboard')
@section('content')
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <section class="flex flex-col sm:flex-row gap-3 justify-between items-center pt-4">
        <div>
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight mb-4">
                Dashboard
            </h2>
        </div>
    </section>
    <div class=" gap-10">
        <div class=" w-full">
            <div class="sm:flex gap-3 mb-2">
                <div class="bg-lime-500 text-white mb-1 mb-xl-1 p-4 w-full rounded">
                    <div class="p-3 text-center">
                        <span class="display-5 font-semibold text-5xl">{{ $devices}}</span>
                        <p class="text-xl mt-2">Total number of devices</p>
                        <i class="demo-psi-shopping-bag text-white text-opacity-50 fs-5"></i>
                    </div>
                </div>
                <div class="bg-violet-600 text-white mb-1 mb-xl-1 p-4 w-full rounded">
                    <div class="p-3 text-center">
                        <span class="display-5 font-semibold text-5xl">{{ $linked_devices }}</span>
                        <p class="text-xl mt-2">Total number of linked devices</p>
                        <i class="demo-psi-shopping-bag text-white text-opacity-50 fs-5"></i>
                    </div>
                </div>
                <div class="bg-orange-500 text-white mb-1 mb-xl-1 p-4 w-full rounded">
                    <div class="p-3 text-center">
                        <span class="display-5 font-semibold text-5xl">{{ $numbers }}</span>
                        <p class="text-xl mt-2">Total numbers</p>
                        <i class="demo-psi-shopping-bag text-white text-opacity-50 fs-5"></i>
                    </div>
                </div>
                <div class="bg-sky-500 text-white mb-1 mb-xl-1 p-4 w-full rounded">
                    <div class="p-3 text-center">
                        <span class="display-5 font-semibold text-5xl">{{ $linked_devices }}</span>
                        <p class="text-xl mt-2">Total linked numbers</p>
                        <i class="demo-psi-shopping-bag text-white text-opacity-50 fs-5"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-full mt-16">
            <div class="font-semibold text-xl mb-2">Recent Call Logs</div>
            <div class="py-2">
                <div class="bg-white rounded-lg">
                    <div class="relative overflow-x-auto sm:rounded-lg">
                        <table class="w-full text-sm">
                            <thead>
                                <tr>
                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-center">
                                        S.No
                                    </th>
                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-left">
                                        <div class="flex items-center">

                                            Unique ID


                                        </div>
                                    </th>
                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-left">
                                        <div class="flex items-center">

                                            Number


                                        </div>
                                    </th>
                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-left">
                                        <div class="flex items-center">

                                            Facility


                                        </div>
                                    </th>
                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-left">
                                        <div class="flex items-center">

                                            Incoming Date


                                        </div>
                                    </th>

                                    <th class="px-6 py-4 font-medium
                                  tracking-wider text-sm truncate
                                  text-left">
                                        <div class="flex items-center">

                                            Call Duration

                                        </div>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                            @if($recent_call_logs->count() > 0)
                            @foreach ($recent_call_logs as $key => $value)
                                <tr class="border-t border-b border-gray-100
                               odd:bg-violet-50/25">
                                    <td class="text-sm px-6 py-3 text-center">
                                        {{$key+1}}
                                    </td>
                                    <td class="text-sm px-6 py-3 text-left">
                                        <div>{{ $value->unique_id ? $value->unique_id : 'N/A' }}</div>
                                    </td>
                                    <td class="text-sm px-6 py-3 text-left" style="width:200px">
                                        <div>{{ $value->phone_number ?? '' }}</div>
                                        <div><span class="font-semibold">{{ $value->nick_name ??
                                            '' }}</span>
                                        </div>
                                    </td>
                                    <td class="text-sm px-6 py-3 text-left">
                                    <div><strong>{{ $value->facility_name ? $value->facility_name :
                                        'N/A' }}</strong></div>
                                        <div>{{$value->facility_address ? $value->facility_address
                                            : 'N/A'}},
                                            {{$value->facility_city ? $value->facility_city :
                                            'N/A'}},
                                            {{$value->facility_state ? $value->facility_state :
                                            'N/A'}}
                                            {{$value->facility_zip ? $value->facility_zip :
                                            'N/A'}}
                                        </div>
                                    </td>

                                    <td class="text-sm px-6 py-3 text-left">
                                        <div>{{ date("d M, Y" ,strtotime($value->created_at)) }}</div>
                                    </td>
                                    <td class="text-sm px-6 py-3 text-left">
                                        <div>
                                            @if(date('H:i', $value->duration) == '00:00')
                                            {{ date('s', $value->duration) ?? '' }} sec
                                            @else
                                            {{ date('H:i:s', $value->duration) ?? '' }}
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                                @else
                                <tr class="border-t border-b border-gray-100
                                    odd:bg-violet-50/25">
                                    <td colspan="10">
                                        <div class="flex items-center justify-center w-full
                                        p-4">
                                        <div
                                            class="filament-tables-empty-state flex flex-1
                                            flex-col items-center justify-center p-6 mx-auto
                                            space-y-6 text-center bg-white">
                                            <div
                                                class="flex items-center justify-center w-16
                                                h-16 text-primary-500 rounded-full
                                                bg-orange-50">
                                                <svg wire:loading.remove.delay="1"
                                                    wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                                    class="w-6 h-6 text-orange-500"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="none" viewBox="0 0 24 24"
                                                    stroke-width="2" stroke="currentColor"
                                                    aria-hidden="true">
                                                    <path stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M6 18L18 6M6 6l12 12"></path>
                                                </svg>
                                            </div>
                                            <div class="max-w-md space-y-1">
                                                <h2
                                                    class="filament-tables-empty-state-heading
                                                    text-xl font-bold tracking-tight">
                                                    No records found
                                                </h2>
                                                <p
                                                    class="filament-tables-empty-state-description
                                                    whitespace-normal text-sm font-medium
                                                    text-gray-500">
                                                </p>
                                            </div>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                                @endif
                            </tbody>
                        </table>
                        
                    </div>
                </div>
                @if($recent_call_logs->count() > 0)
                <div class="text-center mt-6">
                    <form action="{{route('call-logs.index')}}" method="get">  
                        <button type="submit" class="
                        px-6 py-2 bg-orange-500 text-white font-medium text-base
                        leading-snug rounded-sm shadow-md hover:bg-orange-500
                        hover:shadow-lg
                        focus:bg-orange-500 focus:shadow-lg focus:outline-none
                        focus:ring-0
                        active:bg-orange-500 active:shadow-lg transition duration-150
                        ease-in-out ripple-surface-light"
                        > View All</button>
                    </form>
                </div>
                @endif
            </div>
        </div>
    </div>
</article>
@endsection
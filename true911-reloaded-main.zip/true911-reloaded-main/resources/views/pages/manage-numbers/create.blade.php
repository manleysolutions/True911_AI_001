@extends('layouts.main')
@section('title', 'Manage Numbers')
@section('content')
<div class="pageLoader" id="pageLoader"></div>
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
   <nav class="rounded-md w-full">
      <ol class="list-reset flex gap-1">
         <a href="{{ route('manage-numbers',['linked_number' => 'link']) }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24">
               <path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path>
            </svg></a>
         <li><a href="{{ route('manage-numbers',['linked_number' => 'link']) }}" class="text-black font-semibold hover:text-black">Manage Number</a></li>
         <li><span class="text-gray-500 mx-2">/</span></li>
         <li class="text-gray-500">Order new True911 service</li>
      </ol>
   </nav>
   <section class="flex flex-col sm:flex-row gap-3 justify-between items-center pt-4 mt-6">
      <div>
         <h2 class="font-semibold text-xl text-gray-800  leading-tight">
            Order new True911 service
         </h2>
         <div class="text-gray-500">Search by area code, perfix or characters you want in your phone number.</div>
      </div>
   </section>
   <form method="post" class="loaderForm" action="{{ route('manage-numbers.search') }}">
      @csrf
      <div class="bg-white rounded-lg p-6 w-full mt-6">
         <div class="grid gap-6 mb-4 md:grid-cols-3 w-full">
            <div class="w-full mt-4">
               <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                  Country <span class="text-red-700">*</span>
               </label>
               <select id="country" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="country" required>
                  <option value="" disabled>Select an option</option>
                  <option value="US" selected>United States</option>
               </select>
            </div>
            <div class="w-full mt-9">
               <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                  Capabilities
               </label>
               <div class="flex">
                  <div class="flex items-center mr-4">
                     <input id="role_2" type="checkbox" value="voice" name="capabilities[]" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300" @if(isset($capabilities) && in_array('voice',$capabilities)) checked @endif>
                     <label for="role_2" class="mr-2 ml-2 text-sm font-medium text-gray-900">
                        Voice
                     </label>
                     <input id="role_3" type="checkbox" value="sms" name="capabilities[]" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300" @if(isset($capabilities) && in_array('sms',$capabilities)) checked @endif>
                     <label for="role_3" class="mr-2 ml-2 text-sm font-medium text-gray-900">
                        SMS
                     </label>
                  </div>
               </div>
            </div>
         </div>
         <div class="grid gap-6 mb-4 md:grid-cols-4 w-full">
            <div class="w-full mt-4">
               <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                  Search criteria
               </label>
               </label>
               <input type="number" placeholder="Search by digits of phrases" id="criteria" name="criteria" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded
                  focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" min="0" pattern="\d*" maxlength="10" value="{{ $criteria ?? ''}}">
               <h2> {{ $errors->first('criteria') }}</h2>
            </div>
            <div class="w-full mt-4">
               <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                  Match to
               </label>
               <select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="matchTo">
                  <option value="1" @if(isset($matchTo) && $matchTo==1) selected @endif>First part of number</option>
                  <option value="2" @if(isset($matchTo) && $matchTo==2) selected @endif>Anywhere in number</option>
                  <option value="3" @if(isset($matchTo) && $matchTo==3) selected @endif>Last part of number</option>
               </select>
               <span class="text-red"> {{ $errors->first('matchTo') }}</span>
            </div>
            <div class="w-full mt-4">
               <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                  Number Type
               </label>
               <select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="numberType">
                  <option value="local" @if(isset($numberType) && $numberType=="local" ) selected @endif>Local</option>
                  <option value="mobile" @if(isset($numberType) && $numberType=="mobile" ) selected @endif> Mobile</option>
                  <option value="tollFree" @if(isset($numberType) && $numberType=="tollFree" ) selected @endif>Toll free</option>
               </select>
               <span class="text-red"> {{ $errors->first('numberType') }}</span>
            </div>
         </div>
         <div class="md:flex gap-4">
            <button type="submit" class="inline-block px-4 mt-6 mb-4 py-2 bg-orange-500 text-white font-medium text-base leading-snug  rounded-lg shadow-md hover:bg-orange-500 hover:shadow-lg focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-orange-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light" name="action">
               Search
            </button>
            <a href="{{ route('manage-numbers.create') }}" type="reset" id="resetSearchForm" class="inline-block shadow rounded-lg px-4 mt-6 mb-4 py-2  text-black font-medium text-base leading-snug ">
               Reset
            </a>
         </div>
      </div>
   </form>
   @if(count($avilableData) > 0)
   <div class="py-8">
      <div class="bg-white rounded-lg">
         <div class="relative overflow-x-auto sm:rounded-lg">
            <table class="w-full text-sm">
               <thead>
                  <tr>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-center">
                        Phone Numbers
                     </th>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left">
                        Type
                     </th>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left">
                        Capabilities
                     </th>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left">
                        Country
                     </th>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left">
                        Address Requirement
                     </th>
                     <th class="px-6 py-4 text-gray-500 font-medium tracking-wider uppercase text-xs truncate text-left">
                        Action
                     </th>
                  </tr>
               </thead>
               <tbody>
                  @foreach($avilableData as $key => $value)
                  <tr class="border-t border-b border-gray-100 odd:bg-violet-50/25">
                     <td class="text-sm px-6 py-3 text-center">
                        <div class="font-semibold">{{ $value['phoneNumber'] ?? ''}}</div>
                        <div> </div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        {{$value['type'] ?? ''}}
                     </td>
                     <td class="text-sm px-6 py-3 text-left flex gap-4">
                        <svg class="w-6 h-6 {{ $value['voice'] ? '' : 'text-gray-300' }}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                           <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z">
                           </path>
                        </svg>
                        <svg class="w-6 h-6 {{ $value['sms'] ? '' : 'text-gray-300' }}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                           <g>
                              <path fill="none" d="M0 0h24v24H0z"></path>
                              <path d="M6.455 19L2 22.5V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H6.455zM8 10v2h8v-2H8z">
                              </path>
                           </g>
                        </svg>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        {{$value['selectedCountry'] ?? ''}}
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div>{{$value['addressRequirements'] ?? ''}}</div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <button type="button" @click="modal = true, getPhoneNumber=`{{ $value['phoneNumber'] }}`,pricing=`{{ $value['pricing'] }}`,selectedCountry=`{{ $value['selectedCountry'] }}`,voice=`{{ $value['voice']}}`,sms= `{{ $value['sms'] }}`" /" class="inline-flex w-full justify-center rounded-md border border-gray-300 bg-black hover:bg-black/80 px-4 py-1 text-base font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:w-auto sm:text-sm">Buy</button>
                     </td>
                  </tr>
                  @endforeach
                  @else
                  <div class="p-2 space-y-2 bg-white rounded-lg shadow mt-4">
                     <div class="space-y-2 ">
                        <div class="px-4 py-2 space-y-4">
                           <div class="filament-tables-empty-state flex flex-1 flex-col items-center justify-center p-6 mx-auto space-y-6 text-center bg-white border rounded-2xl">
                              <div class="flex items-center justify-center w-16 h-16 text-primary-500 rounded-full bg-orange-50">
                                 <svg wire:loading.remove.delay="1" wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage" class="w-6 h-6 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                                 </svg>
                              </div>
                              <div class="max-w-md space-y-1">
                                 <h2 class="filament-tables-empty-state-heading text-xl font-bold tracking-tight">
                                    No result found
                                 </h2>
                                 <p class="filament-tables-empty-state-description whitespace-normal text-sm font-medium text-gray-500">
                                    We couldn't find any numbers that matched your search
                                    criteria.
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </tbody>
            </table>
         </div>
      </div>
   </div>
   @endif
   <template x-teleport="body">
      <div class="relative z-10" x-show="modal" aria-labelledby="modal-title" role="dialog" aria-modal="true">
         <div class="pageLoader" id="pageLoaderss"></div>
         <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
         <div class="fixed inset-0 z-10 overflow-y-auto">
            <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
               <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full max-w-3xl">
                  <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                     <div class="sm:items-start">
                        <div class="sm:mt-0 text-left">
                           <div class="flex justify-between gap-2 pb-4 border-b-2 border-gray-500">
                              <h3 class="text-xl font-medium leading-6 text-gray-900" id="modal-title">Review Phone Number</h3>
                              <a href="javascript:void(0);" class="text-xl" @click="modal = false;">&times;</a>
                           </div>
                           <div class="pt-6 divide-y devide-gray-200">
                              <div class="flex justify-between font-semibold py-3">
                                 <div x-text="getPhoneNumber"></div>
                                 <div x-text="pricing"><span class="font-normal">monthly fee</span></div>
                              </div>
                              <div>
                                 <h3 class="py-4 font-semibold">Capabilities</h3>
                                 <div class="flex flex-col sm:flex-row gap-2 justify-between py-3">
                                    <div class="flex flex-1 gap-2" :class="{'text-gray-300' : !voice}">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 flex-none">
                                          <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                                       </svg>
                                       <div>
                                          <div class="font-semibold">Voice</div>
                                          <p class="font-normal text-sm text-current">Receive incoming calls and make outgoing calls.</p>
                                       </div>
                                    </div>
                                    <div class="flex flex-1 gap-2" :class="{'text-gray-300' : !sms}">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 flex-none">
                                          <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
                                       </svg>
                                       <div>
                                          <div class="font-semibold">SMS</div>
                                          <p class="font-normal text-sm text-current">Send and receive text message</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div>
                                 <form action="{{route('manage-numbers.purchase')}}" method="POST" id="form" class="w-full pt-4 flex flex-col gap-4 loaderForm">
                                    @csrf
                                    <div>
                                       <label for="name" class="">Nick Name
                                          <span class="text-red-700">*</span>
                                       </label>
                                       <input type="text" wire:model="friendlyName" name="friendlyName" id="name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded
                                          focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" pattern="^([a-zA-Z]+\s)*[a-zA-Z]+$" maxlength="40" required />
                                       <span class="text-red"> {{ $errors->first('friendlyName') }}</span>
                                    </div>
                                    <input type="hidden" name="phoneNumber" x-model="getPhoneNumber" />
                                    <input type="hidden" name="country" x-model="selectedCountry" />
                                    <div class="py-3 sm:flex sm:flex-row-reverse">
                                       <button class="inline-flex w-full justify-center rounded border border-transparent bg-orange-500 px-4 py-2 text-base font-medium shadow-sm hover:bg-orange-500 text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm" type="submit" id="submitForm">
                                          Buy
                                       </button>
                                       <button type="button" @click="modal = false;" class="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                          Cancel
                                       </button>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </template>
</article>
@endsection
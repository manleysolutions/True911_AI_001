@extends('layouts.main')
@section('title', 'Manage Numbers')
@section('content')
@php
if (Request('linked_number')) {
$linked_number = Request('linked_number');
} else {
$linked_number = '';
}
@endphp
<div class="pageLoader" id="pageLoader"></div>
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">
        <ol class="list-reset flex gap-1">
            <a href="{{ route('manage-numbers',['linked_number' => $linked_number]) }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24">
                    <path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path>
                </svg></a>
            <li><a href="{{ route('manage-numbers',['linked_number' => $linked_number]) }}" class="text-black font-semibold hover:text-black">Manage Number</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">Edit</li>
        </ol>
    </nav>
    <section class="flex flex-col sm:flex-row gap-3 justify-between items-center pt-4">
        <div>
            <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
                Edit Number
            </h2>
        </div>
    </section>
    <div class="p-2 space-y-2 bg-white rounded shadow mt-6">
        <div class="px-4 py-2">
            <div class="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                <h2 class="text-lg font-bold tracking-tight filament-card-heading">
                    Edit Informantion
                </h2>
            </div>
        </div>
        <div aria-hidden="true" class="filament-hr border-t"></div>
        <div class="space-y-2">
            <div class="px-4 py-2 space-y-4">
                <div> Device SN: <strong>{{$data['device']->device_sn ?? 'N/A'}}</strong></div>
                <div> Manage Number: <strong>{{$data['manage_number'] ?? ''}} - {{$data['nick_name'] ?? ''}}</strong></div>
                <div> Call Flow Name: <strong>{{$data['device']->flow_name ?? 'N/A'}} </strong></div>
                <div> Facility Address: <strong>{{$data['device'] ? $data['device']['facility_address']: 'N/A'}},{{$data['device'] ? $data['device']['facility_city']: 'N/A' }},{{$data['device'] ? $data['device']['facility_state'] : 'N/A'}} {{$data['device'] ? $data['device']['facility_zip'] :'N/A'}}</strong></div>
            </div>
        </div>
    </div>
    <form action="{{route('edit.phone_number')}}" class="loaderForm py-4" id="updateNumber" method="POST" class="w-full pt-4 flex flex-col gap-4 p-6 space-y-2 bg-white rounded shadow mt-4">
        @csrf
        <div class="grid gap-6 md:grid-cols-3 w-full">
            <div>
                <label for="nickName" class="block mb-2 text-sm font-semibold text-gray-900">Nick Name
                    <span class="text-red-700">*</span>
                </label>
                <input type="text" name="nickName" id="nickName" class=" border border-gray-300 text-gray-900 text-sm rounded
                        focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{ $data['nick_name']}}" pattern="^([a-zA-Z]+\s)*[a-zA-Z]+$" required />
                <span class="text-red-700"> {{ $errors->first('nickName') }}</span>
            </div>
        </div>
        <input type="hidden" name="phoneNumberSid" value="{{ $data['phone_number_sid']}}" />
        <input type="hidden" name="id" value="{{ encrypt($data['id'])}}" />
        <div class="py-3 flex gap-3 justify">
            <button class="inline-block px-7 mt-6 mb-4 py-3 bg-orange-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-orange-500 hover:shadow-lg focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light" type="submit" x-on:click="loading=true; document.getElementById('updateNumber').submit();" x-html="loading ? `<i class='uil uil-loding uil-sign-in-alt'></i> Please Wait ...` : 'Update'" class="disabled:opacity-50" x-bind:disabled="loading">
                Update
            </button>
            <a href="{{ route('manage-numbers', [
                'linked_number' => $linked_number
            ]) }}"> <button type="button" class="inline-block px-7 mt-6 mb-4 py-3 bg-gray-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-gray-500 hover:shadow-lg focus:bg-gray-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light">
                    Cancel
                </button></a>
        </div>
    </form>
</article>
@endsection
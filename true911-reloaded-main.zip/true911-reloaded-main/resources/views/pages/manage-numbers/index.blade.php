@extends('layouts.main')
@section('title','Manage Numbers')
@section('content')
<div x-data="{ modal: false,getPhoneNumber: '',getNumberId: ''}">
   <article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
      <section class="flex flex-col sm:flex-row gap-3 justify-between
         items-center
         pt-4">
         <div>
            <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
               Manage Numbers
            </h2>
            <div class="text-gray-500">Display all the numbers bought by
               the user
            </div>
         </div>
         <div class="flex">
            <a href="{{ route('manage-numbers.create', [
               'linked_number' => request()->query('linked_number') ?? ''
               ]) }}" class="inline-block
               px-6 py-2 bg-orange-500 text-white font-medium text-base
               leading-snug rounded-lg shadow-md hover:bg-orange-500
               hover:shadow-lg
               focus:bg-orange-500 focus:shadow-lg focus:outline-none
               focus:ring-0
               active:bg-orange-500 active:shadow-lg transition duration-150
               ease-in-out w-full ripple-surface-light">
               Buy New Number
            </a>
         </div>
      </section>
      <section class="flex flex-col sm:flex-row gap-4 items-center
         justify-between pt-5 ">
         <div class="items-center flex gap-4">
            <label class="font-medium text-base text-black">Numbers</label>
            <form method="get" id="linkedForm">
               <div class="flex items-center justify-center">
                  <div class="inline-flex shadow-lg hover:shadow-lg
                     focus:shadow-lg rounded-lg" role="group">
                     <input type="hidden" name="linked_number"
                        id="linked_number" value="link">
                     <button type="button" class=" inline-block border-r px-7
                        py-2 bg-white rounded-l font-medium text-sm
                        leading-tight hover:bg-orange-500
                        @if(Request('linked_number') == 'link') bg-orange-500
                        text-white @else text-black @endif hover:text-white
                        focus:bg-orange-500 focus:outline-none focus:ring-0
                        active:bg-oramge-500 transition duration-150
                        ease-in-out" onclick="linkedForm('link')">Linked</button>
                     <button type="button" class=" rounded-r inline-block border-r px-7
                        py-2 bg-white font-medium text-sm
                        @if(Request('linked_number') == 'unlink') bg-orange-500
                        text-white @else text-black @endif leading-tight
                        hover:text-white hover:bg-orange-500 focus:bg-orange-500
                        focus:outline-none focus:ring-0 active:bg-orange-500
                        transition duration-150 ease-in-out"
                        onclick="linkedForm('unlink')">Unlinked</button>
                        <button type="button" class=" rounded-r inline-block px-7
                        py-2 bg-white font-medium text-sm
                        @if(Request('linked_number') == 'released') bg-orange-500
                        text-white @else text-black @endif leading-tight
                        hover:text-white hover:bg-orange-500 focus:bg-orange-500
                        focus:outline-none focus:ring-0 active:bg-orange-500
                        transition duration-150 ease-in-out"
                        onclick="linkedForm('released')">Released</button>
                  </div>
               </div>
            </form>
         </div>
         <div class="flex gap-2">
            <label class="relative block w-80 ">
               <span class="sr-only">Search</span>
               <span class="absolute inset-y-7 left-0 flex items-center pl-2
                  text-gray-300">
                  <svg class="h-5 w-5 mb-4" xmlns="http://www.w3.org/2000/svg"
                     width="24" height="24" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round">
                     <circle cx="11" cy="11" r="8"></circle>
                     <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg> </span>
               <form action="{{ route('manage-numbers')}}?{{request()->getQueryString()
                  }}" method="get" id="form_id">
                  <input class="placeholder:text-gray-400 block bg-white
                     w-full border
                     border-gray-300 rounded-lg py-2 pl-9 pr-3 shadow-sm
                     focus:outline-none
                     focus:border-blue-500 focus:ring-blue-500 focus:ring-1
                     sm:text-sm" placeholder="Numbers, Nickname, Country"
                     type="text" name="search" value="{{
                     Request::get('search') }}">
                  <a href="{{route('manage-numbers', ['search'=> '',
                     'linked_number' => Request::get('linked_number')]);}}"
                     class="absolute top-0 right-0 flex
                     items-center p-2 text-gray-300">
                     <svg class="h-5 w-5 mb-4"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                        fill="currentColor">
                        <g>
                           <path fill="none" d="M0 0h24v24H0z"></path>
                           <path
                              d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95
                              4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414
                              4.95-4.95-4.95-4.95L7.05 5.636z">
                           </path>
                        </g>
                     </svg> </a>
                  <input type="hidden" name="linked_number" value="{{
                     Request::get('linked_number')}}">
               </form>
            </label>
         </div>
      </section>
      <div class="py-2">
         <div class="bg-white rounded-lg">
            <div class="relative overflow-x-auto sm:rounded-lg">
               <table class="w-full text-sm">
                  <thead>
                     <tr>
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-center">
                           S.No
                        </th>
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           <div class="flex items-center">
                              <a class="flex items-center" href="{{
                                 route('manage-numbers', ['manage_number'=>
                                 request()->query('manage_number') == 'desc' ?
                                 'asc' : 'desc',
                                 'search' => Request::get('search'),
                                 'linked_number' => request()->query('linked_number'),
                                 'perPage' => request()->query('perPage')])
                                 }}">
                                 Number
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    class="ml-1 w-3 h-3" aria-hidden="true"
                                    fill="#282727" viewBox="0
                                    0 320 512">
                                    <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                       19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                       0-14.09 2.701-19.45 8.107L8.119
                                       176.9C-9.229 194.2 3.055 224 27.66
                                       224zM292.3 288H27.66c-24.6 0-36.89
                                       29.77-19.54 47.12l132.5 136.8C145.9 477.3
                                       152.1 480 160 480c7.053 0 14.12-2.703
                                       19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                       288 292.3 288z">
                                    </path>
                                 </svg>
                              </a>
                           </div>
                        </th>
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           <div class="flex items-center">
                              <a class="flex items-center" href="{{
                                 route('manage-numbers', ['nick_name'=>
                                 request()->query('nick_name') == 'desc' ? 'asc'
                                 : 'desc',
                                 'search' => Request::get('search'),
                                 'linked_number' => request()->query('linked_number'),
                                 'perPage' => request()->query('perPage')])
                                 }}">
                                 Nickname
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    class="ml-1 w-3 h-3" aria-hidden="true"
                                    fill="#282727" viewBox="0
                                    0 320 512">
                                    <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                       19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                       0-14.09 2.701-19.45 8.107L8.119
                                       176.9C-9.229 194.2 3.055 224 27.66
                                       224zM292.3 288H27.66c-24.6 0-36.89
                                       29.77-19.54 47.12l132.5 136.8C145.9 477.3
                                       152.1 480 160 480c7.053 0 14.12-2.703
                                       19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                       288 292.3 288z">
                                    </path>
                                 </svg>
                              </a>
                           </div>
                        </th>
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           <div class="flex items-center">
                              <a class="flex items-center" href="{{
                                 route('manage-numbers', ['country'=>
                                 request()->query('country') == 'desc' ? 'asc'
                                 : 'desc',
                                 'search' => Request::get('search'),
                                 'linked_number' => request()->query('linked_number'),
                                 'perPage' => request()->query('perPage')])
                                 }}">
                                 Country
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    class="ml-1 w-3 h-3" aria-hidden="true"
                                    fill="#282727" viewBox="0
                                    0 320 512">
                                    <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                       19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                       0-14.09 2.701-19.45 8.107L8.119
                                       176.9C-9.229 194.2 3.055 224 27.66
                                       224zM292.3 288H27.66c-24.6 0-36.89
                                       29.77-19.54 47.12l132.5 136.8C145.9 477.3
                                       152.1 480 160 480c7.053 0 14.12-2.703
                                       19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                       288 292.3 288z">
                                    </path>
                                 </svg>
                              </a>
                           </div>
                        </th>
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           <div class="flex items-center">
                              <a class="flex items-center" href="{{
                                 route('manage-numbers', ['purchase_date'=>
                                 request()->query('purchase_date') == 'desc' ?
                                 'asc'
                                 : 'desc',
                                 'search' => Request::get('search'),
                                 'linked_number' => request()->query('linked_number'),
                                 'perPage' => request()->query('perPage')])
                                 }}">
                                 Purchase Date
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    class="ml-1 w-3 h-3" aria-hidden="true"
                                    fill="#282727" viewBox="0
                                    0 320 512">
                                    <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                       19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                       0-14.09 2.701-19.45 8.107L8.119
                                       176.9C-9.229 194.2 3.055 224 27.66
                                       224zM292.3 288H27.66c-24.6 0-36.89
                                       29.77-19.54 47.12l132.5 136.8C145.9 477.3
                                       152.1 480 160 480c7.053 0 14.12-2.703
                                       19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                       288 292.3 288z">
                                    </path>
                                 </svg>
                              </a>
                           </div>
                        </th>
                     @if (request()->query('linked_number') == 'released')
                     <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           <div class="flex items-center">
                              <a class="flex items-center" href="{{
                                 route('manage-numbers', ['released_date'=>
                                 request()->query('released_date') == 'desc' ?
                                 'asc'
                                 : 'desc',
                                 'search' => Request::get('search'),
                                 'linked_number' => request()->query('linked_number'),
                                 'perPage' => request()->query('perPage')])
                                 }}">
                                 Released Date
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    class="ml-1 w-3 h-3" aria-hidden="true"
                                    fill="#282727" viewBox="0
                                    0 320 512">
                                    <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                       19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                       0-14.09 2.701-19.45 8.107L8.119
                                       176.9C-9.229 194.2 3.055 224 27.66
                                       224zM292.3 288H27.66c-24.6 0-36.89
                                       29.77-19.54 47.12l132.5 136.8C145.9 477.3
                                       152.1 480 160 480c7.053 0 14.12-2.703
                                       19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                       288 292.3 288z">
                                    </path>
                                 </svg>
                              </a>
                           </div>
                        </th>
                     @else
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           Linked Device
                        </th>
                     @endif
                        <th class="px-6 py-4 font-medium
                           tracking-wider text-sm truncate
                           text-left">
                           Actions
                        </th>
                     </tr>
                  </thead>
                  <tbody>
                     @if (count($items) > 0)
                     @foreach($items as $key => $item)
                     <tr class="border-t border-b border-gray-100
                        odd:bg-violet-50/25">
                        <td class="text-sm px-6 py-3 text-center">
                           {{$key + $items->firstItem()}}
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div>{{ $item->manage_number }}</div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div>{{ $item->nick_name }}</div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div>{{ $item->country }}</div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div>{{ date("d M, Y" ,strtotime($item->purchase_date))}}</div>
                        </td>
                     @if (request()->query('linked_number') == 'released')
                     <td class="text-sm px-6 py-3 text-left">
                           <div>{{ date("d M, Y" ,strtotime($item->deleted_at))}}</div>
                     </td>
                     @else
                        <td class="text-sm px-6 py-3 text-left"
                           @if(Request('linked_number')=='link')
                           style="width:260px" @endif>
                           @if ($item->device)
                           <div class="flex gap-2">
                              <div> {{ !empty($item->device->device_sn) ?
                                 $item->device->device_sn : 'N/A'}} </div>
                              <a @if($item->status != 'registered' && $item->status != 'unregistered' && $item->status != 'registration-failure')  href="#" class="text-grey-300" title="Your request is under progress" @endif  class="font-semibold
                                 text-orange-500
                                 text-sm font-medium"
                                 href="{{route('update-device', encrypt($item->id))}}">
                                 <svg class="w-4 h-4"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="currentColor" viewBox="0 0 24 24"><path
                                       fill-rule="evenodd" d="M17.263 2.177a1.75
                                       1.75 0 012.474 0l2.586 2.586a1.75 1.75 0
                                       010 2.474L19.53 10.03l-.012.013L8.69
                                       20.378a1.75 1.75 0 01-.699.409l-5.523
                                       1.68a.75.75 0 01-.935-.935l1.673-5.5a1.75
                                       1.75 0 01.466-.756L14.476
                                       4.963l2.787-2.786zm-2.275 4.371l-10.28
                                       9.813a.25.25 0 00-.067.108l-1.264 4.154
                                       4.177-1.271a.25.25 0
                                       00.1-.059l10.273-9.806-2.94-2.939zM19
                                       8.44l2.263-2.262a.25.25 0
                                       000-.354l-2.586-2.586a.25.25 0 00-.354
                                       0L16.061 5.5 19 8.44z"></path></svg>
                              </a>
                           </div>
                           <div class="font-semibold" title="{{$item->device->nick_name
                              ? $item->device->nick_name : 'N/A'}}">{{$item->device->nick_name
                              ? $item->device->nick_name : 'N/A'}}</div>

                           @else
                           <a @if(($item) && ($item->status != 'registered' && $item->status != 'unregistered' && $item->status != 'registration-failure'))  href="#" class="text-grey-300" title="Editable after 5 minute" @endif
                           href="{{ route('link-device.index',
                              encrypt($item->id)) }}"
                              class="font-semibold text-orange-500 text-sm
                              font-medium">Link device</a>
                           @endif
                        </td>
                     @endif
                     @if (request()->query('linked_number') == 'released')
                        <td class="text-sm px-6 py-3 text-left">
                              <div><a class="font-semibold
                                    text-orange-500
                                    text-sm font-medium"
                                 href="{{route('manage-numbers.call-logs',[
                                 encrypt($item->id),
                                 'linked_number' => request()->query('linked_number') ?? ''
                              ])}}">Call Logs</a></div>
                        </td>
                     @else
                        <td class="text-sm px-6 py-3 text-left">
                           <div class="w-[175px]
                           flex items-center flex-row gap-4">
                           <a class="font-semibold
                                 text-orange-500
                                 text-sm font-medium" href="{{
                              route('manage-numbers.edit', [
                                 encrypt($item->id),
                                 'linked_number' => request()->query('linked_number') ?? ''
                              ])
                              }}">
                              Edit
                           </a>
                           <a class="font-semibold
                                 text-orange-500
                                 text-sm font-medium"
                              href="{{route('manage-numbers.call-logs',[
                                 encrypt($item->id),
                                 'linked_number' => request()->query('linked_number') ?? ''
                              ])}}">Call Logs</a>
                           <a href="#" @click="modal= !modal,getPhoneNumber=`{{
                              $item['manage_number'] }}`,getNumberId=`{{
                              encrypt($item['id']) }}`" /" class="font-semibold
                              text-orange-500 text-sm
                              font-medium">Release</a>
                           </div>
                        </td>
                     @endif
                     </tr>
                     @endforeach
                     @else
                     <tr class="border-t border-b border-gray-100
                        odd:bg-violet-50/25">
                        <td colspan="10">
                           <div class="flex items-center justify-center w-full
                              p-4">
                              <div class="filament-tables-empty-state flex
                                 flex-1
                                 flex-col items-center justify-center p-6
                                 mx-auto space-y-6 text-center bg-white">
                                 <div class="flex items-center justify-center
                                    w-16
                                    h-16 text-primary-500 rounded-full
                                    bg-orange-50">
                                    <svg wire:loading.remove.delay="1"
                                       wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                       class="w-6 h-6 text-orange-500"
                                       xmlns="http://www.w3.org/2000/svg"
                                       fill="none"
                                       viewBox="0 0 24 24" stroke-width="2"
                                       stroke="currentColor" aria-hidden="true">
                                       <path stroke-linecap="round"
                                          stroke-linejoin="round" d="M6 18L18
                                          6M6 6l12 12">
                                       </path>
                                    </svg>
                                 </div>
                                 <div class="max-w-md space-y-1">
                                    <h2
                                       class="filament-tables-empty-state-heading
                                       text-xl font-bold tracking-tight">
                                       No records found
                                    </h2>
                                    <p
                                       class="filament-tables-empty-state-description
                                       whitespace-normal text-sm font-medium
                                       text-gray-500">
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </td>
                     </tr>
                     @endif
                  </tbody>
               </table>
               <div class="flex items-center gap-2 p-2">
                  <form method="get">
                     <select
                        class="bg-gray-50 w-20 border border-gray-300
                        text-gray-900 text-sm rounded focus:ring-blue-500
                        focus:border-blue-500 block w-full p-2"
                        name="perPage" onchange="this.form.submit()">
                        <option value="10" @if(Request('perPage')==10) selected
                           @endif>10</option>
                        <option value="25" @if(Request('perPage')==25) selected
                           @endif>25</option>
                        <option value="50" @if(Request('perPage')==50) selected
                           @endif>50</option>
                        <option value="{{ $items->total() }}"
                           @if(Request('perPage')== $items->total())
                           selected @endif>All</option>
                     </select>
                     <input type="hidden" name="search" value="{{
                        Request::get('search')}}">
                     <input type="hidden" name="manage_number" value="{{
                        Request::get('manage_number')}}">
                     <input type="hidden" name="nick_name" value="{{
                        Request::get('nick_name')}}">
                     <input type="hidden" name="country" value="{{
                        Request::get('country')}}">
                     <input type="hidden" name="emergency_address" value="{{
                        Request::get('emergency_address')}}">
                     <input type="hidden" name="purchase_date" value="{{
                        Request::get('purchase_date')}}">
                     <input type="hidden" name="linked_number" value="{{
                        Request::get('linked_number')}}">
                  </form>
                  <label for="title" class="block text-sm font-semibold
                     text-gray-900">
                     Per Page
                  </label>
               </div>
               {{ $items->appends(['search' => Request::get('search') ?? '',
               'manage_number' => request()->query('manage_number') ?? '',
               'nick_name' => request()->query('nick_name') ?? '',
               'country' => request()->query('country') ?? '',
               'emergency_address' => request()->query('emergency_address') ??
               '',
               'purchase_date' => request()->query('purchase_date') ?? '',
               'perPage' => request()->query('perPage') ?? '',
               'linked_number' => request()->query('linked_number') ?? '',
               'released_date' => request()->query('released_date') ?? ''
               ])->links();
               }}
            </div>
         </div>
      </article>
      <template x-teleport="body">
         <div class="relative z-10" x-show="modal" aria-labelledby="modal-title"
            role="dialog" aria-modal="true">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75
               transition-opacity"></div>
            <div class="fixed inset-0 z-10 overflow-y-auto">
               <div class="flex min-h-full items-end justify-center p-4
                  text-center sm:items-center sm:p-0">
                  <div
                     class="relative transform overflow-hidden rounded-lg
                     bg-white text-left shadow-xl transition-all sm:my-8
                     sm:w-full max-w-xl">
                     <form method="post" id="releaseForm" action="{{
                        route('manage-numbers.release') }}">
                        @csrf
                        <div class="bg-white rounded px-6 py-6">
                           <h1 class="font-bold text-xl mb-3">Release Number</h1>
                           <div class="modal-body mt-2">
                              <p class="text-base">Are you sure you want to
                                 release <span class="font-semibold"
                                    x-text="getPhoneNumber"> </span> ?</p>
                                 @if((count($items) > 0) && $item['device_id'] != '') <p class="text-sm">(Releasing the number will unlink the device)</p>@endif
                              <input type="hidden" name="id"
                                 x-model="getNumberId">
                              <div class="mt-4 flex justify-end gap-4">
                                 <button class="bg-gray-500 text-white px-4 py-2
                                    mt-4 text-sm
                                    rounded" @click="modal=false" type="button">
                                    Cancel
                                 </button>
                                 <button class="bg-orange-500 text-white px-4
                                    py-2
                                    mt-4
                                    text-sm rounded" type="submit"
                                    x-on:click="loading=true;
                                    document.getElementById('releaseForm').submit();"
                                    x-html="loading ? `<i class='uil uil-loding
                                    uil-sign-in-alt'></i> Please Wait ...` :
                                 'Yes, release this number'"
                                 class="disabled:opacity-50"
                                 x-bind:disabled="loading">
                                 Yes, release this number
                              </button>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </template>
   </div>
   @endsection
@extends('layouts.main')
@section('title', 'View Call Logs')
@section('content')
@php
    if (Request('linked_number')) {
        $linked_number = Request('linked_number');
    } else {
        $linked_number = '';
    }
@endphp
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">
        <ol class="list-reset flex gap-1">
         <a href="{{ route('manage-numbers',['linked_number' => $linked_number]) }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24"><path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path></svg></a>
            <li><a href="{{ route('manage-numbers',['linked_number' => $linked_number]) }}" class="text-black font-semibold hover:text-black">Manage Number</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">View Call Logs</li>
        </ol>
    </nav>
    <p class="text-gray-500 pt-4">View all call records associated with a particular device</p>
    <div class="p-2 space-y-2 bg-white rounded shadow mt-6">
        <div class="space-y-2">
            <div class="px-4 py-2 space-y-4">
                <div> Number : {{$number->manage_number ?? 'N/A'}}<strong> - {{ $number->nick_name ?? 'N/A' }}</strong></div>
            </div>
        </div>
    </div>
   <section class="flex flex-col sm:flex-row gap-4 justify-end pt-8 mb-1">
      <div class="flex gap-2">
      <button class="inline-block
               px-6 py-2 bg-orange-500 text-white font-medium text-base
               leading-snug rounded-lg shadow-md hover:bg-orange-500
               hover:shadow-lg
               focus:bg-orange-500 focus:shadow-lg focus:outline-none
               focus:ring-0
               active:bg-orange-500 active:shadow-lg transition duration-150
               ease-in-out ripple-surface-light" @click="showModal= true" class="btn">Export</button>
         <label class="relative block w-80 ">
            <span class="absolute inset-y-7 left-0 flex items-center pl-2
            text-gray-300">
            <svg class="h-5 w-5 mb-4" xmlns="http://www.w3.org/2000/svg"
            width="24" height="24" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2"
            stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
         </svg> </span>
         <form action="{{ route('manage-numbers.call-logs', $id)}}?{{request()->getQueryString()
         }}" method="get" id="form_id">
         <input class="placeholder:text-gray-400 block bg-white
         w-full border
         border-gray-300 rounded-lg py-2 pl-9 pr-3 shadow-sm
         focus:outline-none
         focus:border-blue-500 focus:ring-blue-500 focus:ring-1
         sm:text-sm" placeholder="Search by Unique ID, Facility"
         type="text" name="search" value="{{
            Request::get('search')}}">
                  <a href="{{route('manage-numbers.call-logs', ['search' => '', $id]);}}" class="absolute top-0 right-0 flex
                     items-center p-2 text-gray-300">
                     <svg class="h-5 w-5 mb-4"
                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                     fill="currentColor">
                     <g>
                        <path fill="none" d="M0 0h24v24H0z"></path>
                        <path
                        d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95
                        4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414
                        4.95-4.95-4.95-4.95L7.05 5.636z">
                     </path>
                  </g>
               </svg> </a>
               <input type="hidden" name="data_filter" value="{{ Request::get('data_filter')}}">
               <input type="hidden" name="linked_number" value="{{ Request::get('linked_number')}}">

            </form>
         </label>
      </div>
      <div class="gap-3 flex items-center">
         <div class="font-semibold">Date Filter</div>
         <div class="relative" x-data="{ dropdown: false }">
            
            <form method="get">
               <select
               class="p-2 px-3 pr-5 text-sm border border-gray-300
               cursor-pointer bg-white truncate shadow-sm rounded-lg
               w-[200px] w-full selectNew"
               name="data_filter" onchange="this.form.submit()">
               <option value="all" @if(Request('data_filter')== 'all') || Request('number') == 'all')
                  selected @endif>All</option>
                  <option value="today" @if(Request('data_filter')=='today') || Request('number'))  selected
                  @endif>Today</option>
                  <option value="yesterday" @if(Request('data_filter')=='yesterday') || Request('number'))  selected
                  @endif>Yesterday</option>
                  <option value="last_7_days" @if(Request('data_filter')=='last_7_days') || Request('number'))  selected
                  @endif>Last 7 Days</option>
                  <option value="last_30_days" @if(Request('data_filter')=='last_30_days') || Request('number')) selected
                  @endif>Last 30 Days</option>
                  <!-- <option value="last_month" @if(Request('data_filter')=='last_month') || Request('number')) selected
                  @endif>Last Month</option> -->
                  <option value="last_year" @if(Request('data_filter')=='last_year') || Request('number')) selected
                  @endif>Last Year</option>
            </select>
            <input type="hidden" name="search" value="{{ Request::get('search')}}">
            <input type="hidden" name="linked_number" value="{{ Request::get('linked_number')}}">
         </form> 
      </div>
   </div>
</section>
   <div class="py-8">
        <div class="bg-white rounded-lg">
           <div class="relative overflow-x-auto sm:rounded-lg">
              <table class="w-full text-sm">
                 <thead>
                    <tr>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-center">
                          S.No
                       </th>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('manage-numbers.call-logs', [$id, 
                              'unique_id'=> request()->query('unique_id') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Unique ID
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                          </div>
                       </th>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('manage-numbers.call-logs', [$id, 
                              'facility_name'=> request()->query('facility_name') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Facility
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                          </div>
                       </th>
                       <th class="px-6 py-4 font-medium
                       tracking-wider text-sm truncate
                       text-left">
                       <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('manage-numbers.call-logs', [$id, 
                              'flow_name'=> request()->query('flow_name') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Call Flow
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                       </div>
                    </th>
                       
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('manage-numbers.call-logs', [$id, 
                              'incoming_date'=> request()->query('incoming_date') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Incoming Date
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                          </div>
                       </th>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                             <a class="flex items-center" href="#">
                             Call Recording
                             </a>
                          </div>
                       </th>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                             <a class="flex items-center" href="#">
                             Call Duration
                             </a>
                          </div>
                       </th>
                       <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                             <a class="flex items-center" href="#">
                             Call Price
                             </a>
                          </div>
                       </th>
  
                       <!-- <th class="px-6 py-4 font-medium
                          tracking-wider text-sm truncate
                          text-left">
                          <div class="flex items-center">
                             <a class="flex items-center" href="#">
                             Action
                             </a>
                          </div>
                       </th> -->
                    </tr>
                 </thead>
                 <tbody>
                    @if($call_logs->count() > 0)
                    @foreach ($call_logs as $key => $value)
                    <tr class="border-t border-b border-gray-100
                       odd:bg-violet-50/25">
                       <td class="text-sm px-6 py-3 text-center">
                       {{ $key + $call_logs->firstItem() }}
                       </td>
                       <td class="text-sm px-6 py-3 text-left">
                       <div>{{ $value->unique_id ?? '' }}</div>
                       </td>
                       <td class="text-sm px-6 py-3 text-left">
                        <div><strong>{{ $value->facility_name ?? '' }}</strong></div>
                        <div>{{ $value->facility_address ?? '' }},{{$value->facility_city ?? ''}},{{ $value->facility_state ?? ''}} {{ $value->facility_zip ?? ''}}</div>

                        </td>
                       <td class="text-sm px-6 py-3 text-left">
                        <div>{{ $value->flow_name ?? '' }}</div>
                        </td>
                       
                       <td class="text-sm px-6 py-3 text-left">
                          <div>{{ date("d M, Y" ,strtotime($value->created_at)) }}</div>
                       </td>
                       <td class="text-sm px-6 py-3 text-left">
                          <audio preload="none" controls="controls" style="vertical-align: middle" src="{{ $value->call_recording }}" type="audio/mp3" controlslist="nodownload">
                             Your browser does not support the audio element.
                          </audio>
                       </td>
                        
                       <td class="text-sm px-6 py-3 text-left">
                          <div>
                           @if(date('H:i', $value->duration) == '00:00')
                             {{ date('s', $value->duration) ?? '' }} sec
                           @else
                           {{ date('H:i:s', $value->duration) ?? '' }}
                           @endif
                          </div>
                       </td>
                       <td class="text-sm px-6 py-3 text-left">
                           <div>{{ !empty($value->price) ? number_format($value->price,2) : '0.00'}}</div>
                        </td>
                    </tr>
                    @endforeach
                    @else
                    <tr class="border-t border-b border-gray-100 odd:bg-violet-50/25">
                       <td colspan="10">
                          <div class="flex items-center justify-center w-full p-4">
                             <div
                                class="filament-tables-empty-state flex flex-1 flex-col items-center justify-center p-6 mx-auto space-y-6 text-center bg-white">
                                <div
                                   class="flex items-center justify-center w-16 h-16 text-primary-500 rounded-full bg-orange-50">
                                   <svg wire:loading.remove.delay="1"
                                      wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                      class="w-6 h-6 text-orange-500" xmlns="http://www.w3.org/2000/svg"
                                      fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                      aria-hidden="true">
                                      <path stroke-linecap="round" stroke-linejoin="round"
                                         d="M6 18L18 6M6 6l12 12"></path>
                                   </svg>
                                </div>
                                <div class="max-w-md space-y-1">
                                   <h2
                                      class="filament-tables-empty-state-heading text-xl font-bold tracking-tight">
                                      No records found
                                   </h2>
                                   <p
                                      class="filament-tables-empty-state-description whitespace-normal text-sm font-medium text-gray-500">
                                   </p>
                                </div>
                             </div>
                          </div>
                       </td>
                    </tr>
                    @endif
                 </tbody>
              </table>
              {{ $call_logs->appends(['search' => Request::get('search') ?? '',
            'data_filter' => request()->query('data_filter') ?? '',
            'perPage' => request()->query('perPage') ?? '',
            'unique_id' => request()->query('unique_id') ?? '',
            'facility_name' => request()->query('facility_name') ?? '',
            'flow_name' => request()->query('flow_name') ?? '',
            'incoming_date' => request()->query('incoming_date') ?? '',
            ])->links();
            }}
           </div>
        </div>
     </div>
</article>
@endsection
@push('modals')
<div class=" relative z-10 export-modal" x-cloak x-show="showModal">
   <div class="fixed inset-0 bg-gray-500 bg-opacity-75
      transition-opacity"></div>
   <!--Dialog-->
   <form method="post" action ="{{route('export.data')}}" id="exportForm">
      @csrf
   <div class="fixed inset-0 z-10 overflow-y-auto">
      <div class="flex min-h-full items-end justify-center p-4
         text-center sm:items-center sm:p-0">
         <div class="relative transform rounded-lg
            bg-white text-left shadow-xl transition-all sm:my-8
            sm:w-full max-w-xl">
            <div class="bg-white rounded px-6 py-6">

               <!--Title-->
               <div class="flex justify-between items-center pb-3">
                  <p class="text-2xl font-bold">Export</p>
                  <div class="cursor-pointer z-50" id="exportClose" @click="showModal= false;location.reload()
                  ">
                     <svg class="fill-current text-black"
                        xmlns="http://www.w3.org/2000/svg" width="18"
                        height="18"
                        viewBox="0 0 18 18">
                        <path
                           d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53
                           7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47
                           1.06-1.06L10.06 9z">
                        </path>
                     </svg>
                  </div>
               </div>

               <!-- content -->
               <div class="flex-row">
                  <div class="w-full mb-4">
                     <label class="font-semibold mb-1 block text-sm">Select
                        Devices</label>
                     <select name="devices[]" id="devices" multiple 
                        multiselect-search="true" multiselect-select-all="true"
                        multiselect-max-items="1" required>
                        @foreach($uniqueId as $key => $value)
                        @if($value->unique_id)
                        <option value="{{ $value->unique_id }}" selected>{{ $value->unique_id }} - {{ $value->facility_name }}</option>
                        @endif
                        @endforeach
                     </select>
                     <div class="error device_error">Please select device</div>
                  </div>
                  <input type="hidden" name="number[]" id="sel1" value="{{ $phone_number }}">
                  <div class="w-full mb-4">
                     <label class="font-semibold mb-1 block text-sm">Time Period</label>
                     <select name="data_filter" id="date_filter" class="placeholder:text-gray-400 bg-gray-50 block
                        w-full
                        border
                        border-gray-300 rounded p-2.5 shadow-sm
                        focus:outline-none
                        focus:border-blue-500 text-base focus:ring-blue-500
                        focus:ring-1
                        sm:text-sm" onchange="selectedDate(event)">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="yesterday">Yesterday</option>
                        <option value="last_7_days">Last 7 Days</option>
                        <option value="last_30_days" selected>Last 30 Days</option>
                        <option value="custom_date">Custom Date</option>
                     </select>
                  </div>
                  <div class="dateRange">
                  <div class="flex w-full gap-4">
                     <div class="w-full">
                        <label for="from" class="font-semibold mb-1 block text-sm">From
                        </label>
                        <input type="text"
                           name="from" id="from" class="bg-gray-50
                           border border-gray-300 text-gray-900 text-sm rounded
                           focus:ring-blue-500 focus:border-blue-500 block
                           w-full p-2.5 readonly" autocomplete="off">
                           <span class="error from_error">Fill the from date</span>
                     </div>
                     <div class="w-full">
                        <label for="to" class="font-semibold mb-1 block text-sm">To

                        </label>
                        <input type="text"  
                           name="to" id="to" class="bg-gray-50
                           border border-gray-300 text-gray-900 text-sm rounded
                           focus:ring-blue-500 focus:border-blue-500 block
                           w-full p-2.5 readonly" autocomplete="off">
                           <span class="error to_error">Fill the to date</span>
                     </div>
                  </div>
                   </div>
               </div>
            </div>
            <!--Footer-->
            <div class="flex justify-end px-6 pb-6">
               <button
                  class="inline-flex w-full justify-center rounded border
                  border-transparent bg-orange-500 px-4 py-2 text-base
                  font-medium shadow-sm hover:bg-orange-500 text-white
                  focus:outline-none focus:ring-2 focus:ring-primary-500
                  focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm"
                  type="button" id="submitForm" @click = "document.getElementById('exportForm').reset();document.getElementById('devices').loadOptions();">
                  Export
               </button>
            </div>

         </div>
      </div>
   </div>
   </form>
</div>
<!--/Dialog -->

@endpush
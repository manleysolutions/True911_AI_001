@extends('layouts.main')
@section('title', 'Link Device')
@section('content')
@php
   if ($number_data) {
      $redirectUrl = 'update-device';
      $linked_number = 'link';
   } else {
      $redirectUrl = 'link-device.index';
      $linked_number = 'unlink';
   }
@endphp
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
   <nav class="rounded-md w-full">
      <ol class="list-reset flex gap-1">
         <a href="{{ route('manage-numbers',['linked_number'=> $linked_number]) }}">
            <svg
               class="w-6 h-6 mr-2"
               xmlns="http://www.w3.org/2000/svg" fill="currentColor"
               stroke="none" viewBox="0 0 24 24">
               <path d="M21
                  11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707
                  1.414-1.414L6.414 13H21z"></path>
            </svg>
         </a>
         <li><a href="{{ route('manage-numbers',['linked_number'=> $linked_number]) }}"
               class="text-black font-semibold
               hover:text-black"> Link Device</a></li>
         <li><span class="text-gray-500 mx-2">/</span></li>
         <li class="text-gray-500">List</li>
      </ol>
   </nav>
   <section class="flex flex-col sm:flex-row gap-3 justify-between items-center
      pt-4">
      <div>
         <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
            Link Device List
         </h2>
         <div class="text-gray-500">
            Display all Available devices
         </div>
      </div>
   </section>
   <section class="flex flex-col sm:flex-row gap-4 justify-end pt-4 mb-2">
      <div class="flex gap-2">
         <label class="relative block w-80 ">
            <span class="sr-only">Search</span>
            <span class="absolute inset-y-7 left-0 flex items-center pl-2
               text-gray-300">
               <svg class="h-5 w-5 mb-4" xmlns="http://www.w3.org/2000/svg"
                  width="24" height="24"
                  viewBox="0 0 24 24" fill="none" stroke="currentColor"
                  stroke-width="2" stroke-linecap="round"
                  stroke-linejoin="round">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
               </svg>
            </span>
            <form method=" {{ route($redirectUrl, $id)}}?{{request()->getQueryString()
               }}" method="get" id="form_id">
               <input class="placeholder:text-gray-400 block bg-white w-full
                  border
                  border-gray-300 rounded-lg py-2 pl-9 pr-3 shadow-sm
                  focus:outline-none
                  focus:border-blue-500 focus:ring-blue-500 focus:ring-1
                  sm:text-sm"
                  placeholder="Unique ID, Device SN, Customer Detail"
                  type="text" name="search" value="{{
                  Request::get('search') }}">
               <a href="{{route($redirectUrl, ['search'=> '', $id]);}}"
                  class="absolute top-0 right-0 flex
                  items-center p-2 text-gray-300">
                  <svg class="h-5 w-5 mb-4"
                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                     fill="currentColor">
                     <g>
                        <path fill="none" d="M0 0h24v24H0z"></path>
                        <path
                           d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95
                           4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414
                           4.95-4.95-4.95-4.95L7.05 5.636z">
                        </path>
                     </g>
                  </svg>
               </a>
            </form>
         </label>
      </div>
   </section>
   <div class="py-2">
      <div class="bg-white rounded-lg">
         <div class="relative overflow-x-auto sm:rounded-lg">
            <table class="w-full text-sm">
               <thead>
                  <tr>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route($redirectUrl, ['id'=>$id,'unique_id'=>
                              request()->query('unique_id') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage')])
                              }}">
                              Unique ID
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route($redirectUrl, ['id'=>$id,'device_sn'=>
                              request()->query('device_sn') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage')])
                              }}">
                              Device SN
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route($redirectUrl, ['id'=>$id,'customer_detail'=>
                              request()->query('customer_detail') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage')])
                              }}">
                              Customer Detail
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route($redirectUrl, ['id'=>$id,'facility_address'=>
                              request()->query('facility_address') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage')])
                              }}">
                              Facility Address
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                  </tr>
               </thead>
               <tbody>
                  @if (count($devices) > 0)
                  <form action="{{route('link-device.store', $id)}}"
                     method="post">
                     @csrf
                     @if ($number_data)
                     <tr class="border-t border-b border-gray-100
                        odd:bg-violet-50/25">
                        <td class="text-sm px-6 py-3">
                           <div class="items-center">
                              <input id="default-radio-0" type="radio"
                                 value="none" name="device_id"
                                 class="w-4 h-4 text-blue-600 bg-gray-100
                                 border-gray-300 focus:ring-blue-500
                                 focus:ring-2
                                 "
                                 required>
                              <label for="default-radio-0"
                                 class="ml-2 text-sm font-medium text-gray-900
                                 "> None (This will remove
                                 Call flow as well if attached)</label>
                           </div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                        </td>
                     </tr>
                     @endif
                     @foreach($devices as $key => $device)
                     <tr class="border-t border-b border-gray-100
                        odd:bg-violet-50/25">
                        <td class="text-sm px-6 py-3">
                           <div class="items-center">
                              <input id="default-radio-{{$key + 1}}"
                                 type="radio"
                                 value="{{ $device->id }}" name="device_id"
                              class="w-4 h-4 text-blue-600 bg-gray-100
                              border-gray-300 focus:ring-blue-500
                              focus:ring-2
                              " required
                              @if($number_data && $number_data->device_id==
                              $device->id)
                              checked
                              @endif>
                              <label for="default-radio-{{$key + 1}}"
                                 class="ml-2 text-sm font-medium text-gray-900
                                 ">{{$device->unique_id ? $device->unique_id :
                                 'N/A'}}</label>
                           </div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div class="flex gap-2">
                              <div>{{ $device->device_sn ? $device->device_sn :
                                 'N/A'}}
                              </div>
                           </div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div class="flex gap-2">
                              <div>{{$device->nick_name ? $device->nick_name :
                                 'N/A'}}
                              </div>
                           </div>
                           <div class="font-semibold" title="{{$device->nick_name}}">{{
                              $device->facility_name ? $device->facility_name :
                              'N/A' }}
                           </div>
                        </td>
                        <td class="text-sm px-6 py-3 text-left">
                           <div class="flex gap-1">
                              <div @if(!empty($device->facility_address) &&
                                 $device->facility_address
                                 != 'N/A' && $device->facility_address !=
                                 'PENDING'
                                 && $device->facility_address != 'NEED INFO')
                                 style="width:220px" @endif>
                                 @if(!empty($device->facility_address) &&
                                 $device->facility_address
                                 != 'N/A' && $device->facility_address !=
                                 'PENDING'
                                 && $device->facility_address != 'NEED INFO')
                                 {{ !empty($device->facility_address) ?
                                 $device->facility_address
                                 : 'N/A'}},
                                 {{ !empty($device->facility_city) ? $device->facility_city
                                 : 'N/A'}},
                                 {{ !empty($device->facility_state) ? $device->facility_state
                                 : 'N/A'}}
                                 {{ !empty($device->facility_zip) ? $device->facility_zip
                                 : 'N/A'}}
                              </div>
                           </div>
                           @else
                           N/A
                           @endif
                        </td>
                     </tr>
                     @endforeach
                     <tr>
                        <td colspan="5">
                           <div class="md:flex gap-3 mt-9 justify-end border-t
                              px-6">
                              <a href="{{
                                 route('manage-numbers',['linked_number'=>
                                 $linked_number]) }}"
                                 class="inline-block px-7 mt-6 mb-4 py-2
                                 bg-gray-500 text-white font-medium text-base
                                 leading-snug rounded shadow-md
                                 hover:bg-gray-500 hover:shadow-lg
                                 focus:bg-gray-500 focus:shadow-lg
                                 focus:outline-none focus:ring-0
                                 active:bg-blue-800 active:shadow-lg transition
                                 duration-150 ease-in-out ripple-surface-light"
                                 name="action">Cancel</a>
                              <button type="submit"
                                 class="inline-block px-7 mt-6 mb-4 py-2
                                 bg-orange-500 text-white font-medium text-base
                                 leading-snug rounded shadow-md
                                 hover:bg-orange-500 hover:shadow-lg
                                 focus:bg-orange-500 focus:shadow-lg
                                 focus:outline-none focus:ring-0
                                 active:bg-blue-800 active:shadow-lg transition
                                 duration-150 ease-in-out ripple-surface-light"
                                 name="action">
                                 Link
                              </button>
                           </div>
                        </td>
                     </tr>
                  </form>
                  @else
                  <tr class="border-t border-b border-gray-100
                     odd:bg-violet-50/25">
                     <td colspan="10">
                        <div class="flex items-center justify-center w-full
                           p-4">
                           <div
                              class="filament-tables-empty-state flex flex-1
                              flex-col items-center justify-center p-6
                              mx-auto space-y-6 text-center bg-white">
                              <div
                                 class="flex items-center justify-center w-16
                                 h-16 text-primary-500 rounded-full
                                 bg-orange-50">
                                 <svg wire:loading.remove.delay="1"
                                    wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                    class="w-6 h-6 text-orange-500"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24"
                                    stroke-width="2"
                                    stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round"
                                       stroke-linejoin="round"
                                       d="M6 18L18 6M6 6l12 12"></path>
                                 </svg>
                              </div>
                              <div class="max-w-md space-y-1">
                                 <h2
                                    class="filament-tables-empty-state-heading
                                    text-xl font-bold tracking-tight">
                                    No records found
                                 </h2>
                                 <p
                                    class="filament-tables-empty-state-description
                                    whitespace-normal text-sm font-medium
                                    text-gray-500">
                                 </p>
                              </div>
                           </div>
                        </div>
                     </td>
                  </tr>
                  @endif
               </tbody>
            </table>
            {{ $devices->appends(['search' => Request::get('search') ?? '',
            'unique_id' => request()->query('unique_id') ?? '',
            'device_sn' => request()->query('device_sn') ?? '',
            'device_imei' => request()->query('device_imei') ?? '',
            'tmobile_sim' => request()->query('tmobile_sim') ?? '',
            'tmobile_msisdn' => request()->query('tmobile_msisdn') ?? '',
            'customer_detail' => request()->query('customer_detail') ?? '',
            'facility_address' => request()->query('facility_address') ?? '',
            'perPage' => request()->query('perPage') ?? ''
            ])->links();
            }}
         </div>
      </div>
   </div>
</article>
@endsection
@extends('layouts.main')
@section('title', 'Call Logs')
@section('content')

<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
   <section class="flex flex-col sm:flex-row gap-3 justify-between items-center
      pt-4">
      <div>
         <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
            Call Logs
         </h2>
         <div class="text-gray-500">
            Display all call logs.
         </div>
      </div>
   </section>
   <section class="flex flex-col sm:flex-row gap-4 justify-end pt-4 mb-2">
      <div class="items-center">
         <div class="gap-3 flex items-center">
            <button class="inline-block
               px-6 py-2 bg-orange-500 text-white font-medium text-base
               leading-snug rounded-lg shadow-md hover:bg-orange-500
               hover:shadow-lg
               focus:bg-orange-500 focus:shadow-lg focus:outline-none
               focus:ring-0
               active:bg-orange-500 active:shadow-lg transition duration-150
               ease-in-out w-full ripple-surface-light" @click="showModal= true" class="btn">Export</button>
            <div class="relative" x-data="{ dropdown: false }">
               <form method="get">
                  <input type="hidden" name="data_filter" value="{{
                     Request('data_filter') }}">
                  <select class="p-2 px-5 pr-5 text-sm border border-gray-300
                     cursor-pointer bg-white truncate shadow-sm rounded-lg
                     w-[300px] w-full selectNew" name="number" onchange="this.form.submit()">
                     <option value="all" @if(Request('number')=='all' )) selected @endif>All</option>
                     @foreach($numbers as $number)
                     <option value="{{ $number->id }}" @if(Request('number')==$number->id)) selected
                        @endif >{{ $number->phone_number }} - {{ $number->nick_name
                        ?? '' }}
                     </option>
                     @endforeach
                  </select>
               </form>
            </div>
         </div>
      </div>
      <div class="items-center">
         <div class="gap-3 flex items-center">
            <div class="font-semibold">Time Period</div>
            <div class="relative" x-data="{ dropdown: false }">
               <form method="get">
                  <input type="hidden" name="number" value="{{ Request('number')
                     }}">
                  <select class="p-2 px-3 pr-5 text-sm border border-gray-300
                     cursor-pointer bg-white truncate shadow-sm rounded-lg
                     w-[200px] w-full selectNew" name="data_filter" onchange="this.form.submit()">
                     <option value="all" @if(Request('data_filter')=='all' ) || Request('number')=='all' ) selected @endif>All</option>
                     <option value="today" @if(Request('data_filter')=='today' ) || Request('number')) selected @endif>
                        Today</option>
                     <option value="yesterday" @if(Request('data_filter')=='yesterday' ) || Request('number')) selected @endif>Yesterday</option>
                     <option value="last_7_days" @if(Request('data_filter')=='last_7_days' ) || Request('number')) selected @endif>Last 7 Days</option>
                     <option value="last_30_days" @if(Request('data_filter')=='last_30_days' ) || Request('number')) selected @endif>Last 30 Days</option>
                     <option value="last_year" @if(Request('data_filter')=='last_year' ) || Request('number')) selected @endif>Last Year</option>
                  </select>
               </form>
            </div>
         </div>
      </div>
   </section>
   <div class="py-2">
      <div class="bg-white rounded-lg">
         <div class="relative overflow-x-auto sm:rounded-lg">
            <table class="w-full text-sm">
               <thead>
                  <tr>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-center">
                        S.No
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('call-logs.index', ['unique_id'=>
                              request()->query('unique_id') == 'desc' ?
                              'asc' : 'desc',
                              'number' => Request::get('number'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Unique ID
                              <svg xmlns="http://www.w3.org/2000/svg" class="ml-1 w-3 h-3" aria-hidden="true" fill="#282727" viewBox="0 0 320 512">
                                 <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('call-logs.index', ['phone_number'=>
                              request()->query('phone_number') == 'desc' ?
                              'asc' : 'desc',
                              'number' => Request::get('number'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Number
                              <svg xmlns="http://www.w3.org/2000/svg" class="ml-1 w-3 h-3" aria-hidden="true" fill="#282727" viewBox="0 0 320 512">
                                 <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('call-logs.index', ['facility_name'=>
                              request()->query('facility_name') == 'desc' ?
                              'asc' : 'desc',
                              'number' => Request::get('number'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Facility
                              <svg xmlns="http://www.w3.org/2000/svg" class="ml-1 w-3 h-3" aria-hidden="true" fill="#282727" viewBox="0 0 320 512">
                                 <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('call-logs.index', ['incoming_date'=>
                              request()->query('incoming_date') == 'desc' ?
                              'asc' : 'desc',
                              'number' => Request::get('number'),
                              'perPage' => request()->query('perPage'),
                              'data_filter' => request()->query('data_filter'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Incoming Date
                              <svg xmlns="http://www.w3.org/2000/svg" class="ml-1 w-3 h-3" aria-hidden="true" fill="#282727" viewBox="0 0 320 512">
                                 <path d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="#">
                              Call Recording
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="#">
                              Call Duration
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium
                        tracking-wider text-sm truncate
                        text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="#">
                              Call Price
                           </a>
                        </div>
                     </th>
                  </tr>
               </thead>
               <tbody>
                  @if($call_logs->count() > 0)
                  @foreach ($call_logs as $key => $value)
                  <tr class="border-t border-b border-gray-100
                     odd:bg-violet-50/25">
                     <td class="text-sm px-6 py-3 text-center">
                        {{$key + $call_logs->firstItem()}}
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div>{{ $value->unique_id ? $value->unique_id : 'N/A' }}</div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div class="block" style="width:200px">
                           <div>{{ $value->phone_number ?? '' }}</div>
                           <div><span class="font-semibold">{{ $value->nick_name ??
                              '' }}</span></div>
                        </div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div><strong>{{ $value->facility_name ? $value->facility_name
                              :
                              'N/A' }}</strong></div>
                        <div>{{$value->facility_address ? $value->facility_address
                           : 'N/A'}},
                           {{$value->facility_city ? $value->facility_city :
                           'N/A'}},
                           {{$value->facility_state ? $value->facility_state :
                           'N/A'}}
                           {{$value->facility_zip ? $value->facility_zip :
                           'N/A'}}
                        </div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div>{{ date("d M, Y" ,strtotime($value->created_at)) }}</div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <audio preload="none" controls="controls" style="vertical-align:
                           middle" src="{{ $value->call_recording }}" type="audio/mp3" controlslist="nodownload">
                           Your browser does not support the audio element.
                        </audio>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div>
                           @if(date('H:i', $value->duration) == '00:00')
                           {{ date('s', $value->duration) ?? '' }} sec
                           @else
                           {{ date('H:i:s', $value->duration) ?? '' }}
                           @endif
                        </div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div>{{ !empty($value->price) ? number_format($value->price,2)
                           : '0.00'}}</div>
                     </td>
                  </tr>
                  @endforeach
                  @else
                  <tr class="border-t border-b border-gray-100
                     odd:bg-violet-50/25">
                     <td colspan="10">
                        <div class="flex items-center justify-center w-full
                           p-4">
                           <div class="filament-tables-empty-state flex flex-1
                              flex-col items-center justify-center p-6 mx-auto
                              space-y-6 text-center bg-white">
                              <div class="flex items-center justify-center w-16
                                 h-16 text-primary-500 rounded-full
                                 bg-orange-50">
                                 <svg wire:loading.remove.delay="1" wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage" class="w-6 h-6 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6
                                       6l12 12">
                                    </path>
                                 </svg>
                              </div>
                              <div class="max-w-md space-y-1">
                                 <h2 class="filament-tables-empty-state-heading
                                    text-xl font-bold tracking-tight">
                                    No records found
                                 </h2>
                                 <p class="filament-tables-empty-state-description
                                    whitespace-normal text-sm font-medium
                                    text-gray-500">
                                 </p>
                              </div>
                           </div>
                        </div>
                     </td>
                  </tr>
                  @endif
               </tbody>
            </table>
            {{ $call_logs->appends(['number' => Request::get('number') ?? '',
            'data_filter' => request()->query('data_filter') ?? '',
            'perPage' => request()->query('perPage') ?? '',
            'unique_id' => request()->query('unique_id') ?? '',
            'phone_number' => request()->query('phone_number') ?? '',
            'facility_name' => request()->query('facility_name') ?? '',
            'facility_address' => request()->query('facility_address') ?? '',
            'incoming_date' => request()->query('incoming_date') ?? '',
            ])->links();
            }}
         </div>
      </div>
   </div>
</article>
@endsection
@push('modals')
<div class=" relative z-10 export-modal" x-cloak x-show="showModal">
   <div class="fixed inset-0 bg-gray-500 bg-opacity-75
      transition-opacity"></div>
   <!--Dialog-->
   <form method="post" action="{{route('export.data')}}" id="exportForm">
      @csrf
      <div class="fixed inset-0 z-10 overflow-y-auto">
         <div class="flex min-h-full items-end justify-center p-4
         text-center sm:items-center sm:p-0">
            <div class="relative transform rounded-lg
            bg-white text-left shadow-xl transition-all sm:my-8
            sm:w-full max-w-xl">
               <div class="bg-white rounded px-6 py-6">
                  <!--Title-->
                  <div class="flex justify-between items-center pb-3">
                     <p class="text-2xl font-bold">Export</p>
                     <div class="cursor-pointer z-50" id="exportClose" @click="showModal= false;location.reload()
                  ">
                        <svg class="fill-current text-black" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
                           <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53
                           7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47
                           1.06-1.06L10.06 9z">
                           </path>
                        </svg>
                     </div>
                  </div>
                  <!-- content -->
                  <div class="flex-row">
                     <div class="w-full mb-4">
                        <label class="font-semibold mb-1 block text-sm">Select
                           Devices</label>
                        <select name="devices[]" id="devices" multiple multiselect-search="true" multiselect-select-all="true" multiselect-max-items="1" onChange="getSelectedOptions(this)" required>
                           @foreach($uniqueId as $key => $value)
                           @if(!empty($value->unique_id))
                           <option value="{{ $value->unique_id }}" selected>{{ $value->unique_id }} - {{ $value->facility_name }}</option>
                           @endif
                           @endforeach
                        </select>
                        <div class="error device_error">Please select devices</div>
                     </div>
                     <input type="hidden" id="getNumber" value="{{$numbers}}">
                     <div class="w-full mb-4" id="showBlock">
                        <label class="font-semibold mb-1 block text-sm">Select
                           Numbers</label>
                        <select name="number[]" id="sel1" multiple multiselect-search="true" multiselect-select-all="true" multiselect-max-items="1" required>
                           @foreach($numbers as $key => $value)
                           
                           @if(!empty($value->phone_number))
                           <option value="{{ $value->phone_number }}" selected>{{ $value->phone_number }} - {{ $value->nick_name }}</option>
                           @endif
                           @endforeach
                        </select>
                        <div class="error number_error">Please select number</div>
                     </div>
                     <div class="w-full mb-4">
                        <label class="font-semibold mb-1 block text-sm">Time Period</label>
                        <select name="data_filter" id="date_filter" class="placeholder:text-gray-400 bg-gray-50 block
                        w-full
                        border
                        border-gray-300 rounded p-2.5 shadow-sm
                        focus:outline-none
                        focus:border-blue-500 text-base focus:ring-blue-500
                        focus:ring-1
                        sm:text-sm" onchange="selectedDate(event)">
                           <option value="all">All</option>
                           <option value="today">Today</option>
                           <option value="yesterday">Yesterday</option>
                           <option value="last_7_days">Last 7 Days</option>
                           <option value="last_30_days" selected>Last 30 Days</option>
                           <option value="custom_date">Custom Date</option>
                        </select>
                     </div>
                     <div class="dateRange">
                        <div class="flex w-full gap-4">
                           <div class="w-full">
                              <label for="from" class="font-semibold mb-1 block text-sm">From
                              </label>
                              <input type="text" name="from" id="from" class="bg-gray-50
                           border border-gray-300 text-gray-900 text-sm rounded
                           focus:ring-blue-500 focus:border-blue-500 block
                           w-full p-2.5 readonly" autocomplete="off">
                              <span class="error from_error">Fill the from date</span>
                           </div>
                           <div class="w-full">
                              <label for="to" class="font-semibold mb-1 block text-sm">To
                              </label>
                              <input type="text" name="to" id="to" class="bg-gray-50
                           border border-gray-300 text-gray-900 text-sm rounded
                           focus:ring-blue-500 focus:border-blue-500 block
                           w-full p-2.5 readonly" autocomplete="off">
                              <span class="error to_error">Fill the to date </span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--Footer-->
               <div class="flex justify-end px-6 pb-6">
                  <button class="inline-flex w-full justify-center rounded border
                  border-transparent bg-orange-500 px-4 py-2 text-base
                  font-medium shadow-sm hover:bg-orange-500 text-white
                  focus:outline-none focus:ring-2 focus:ring-primary-500
                  focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm" type="button" id="submitForm" @click="document.getElementById('exportForm').reset();document.getElementById('devices').loadOptions();document.getElementById('sel1').loadOptions();">
                     Export
                  </button>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<!--/Dialog -->
@endpush
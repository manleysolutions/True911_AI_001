@extends('layouts.main')
@section('title', 'Call flow')
@section('content')
@php
    if (Request('linked_number')) {
        $linked_number = Request('linked_number');
    } else {
        $linked_number = '';
    }
@endphp
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">
        <ol class="list-reset flex gap-1">
            <a href="{{  route('devices.index',['linked_number' => $linked_number]) }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24"><path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path></svg></a>
            <li><a href="{{  route('devices.index',['linked_number' => $linked_number]) }}" class="text-black font-semibold hover:text-black">Attach Call Flow</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">List</li>
        </ol>
    </nav>
    <p class="pt-4 text-gray-500">Link call flow from the available list.</p>
    <div class="py-8">
        <div class="bg-white rounded-lg">
            <div class="relative overflow-x-auto sm:rounded-lg">
                <table class="w-full text-sm">
                    <thead>
                        <tr>
                            <th class="px-6 py-4 font-medium tracking-wider
                                text-sm truncate text-left">
                                Call flow
                            </th>

                            <th class="px-6 py-4 font-medium tracking-wider
                                text-sm truncate text-left">
                                Friendly Name
                            </th>

                            <th class="px-6 py-4 font-medium tracking-wider
                                text-sm truncate text-left">
                                Call Flow URL
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (count($flows) > 0)
                        <form action="{{route('attach-flow.store')}}" method="post">
                            @csrf
                            @if($device->flow_sid)
                            <tr class="border-t border-b border-gray-100 odd:bg-violet-50/25">
                                <td class="text-sm px-6 py-3">
                                <div class="items-center">
                                    <input id="default-radio-0" type="radio"  
                                        value="none" name="flow_sid" 
                                        
                                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2" required>
                                    <label for="default-radio-0"
                                        class="ml-2 text-sm font-medium text-gray-900 "> None</label>
                                </div>
                                </td>
                                <td class="text-sm px-6 py-3 text-left">
                                
                                </td>
                                <td class="text-sm px-6 py-3 text-left">
                                
                                </td>
                            </tr>
                            @endif
                            @foreach($flows as $key => $flow)
                            <tr class="border-t border-b border-gray-100
                                odd:bg-violet-50/25">
                                <td class="text-sm px-6 py-3">
                                    <div class="items-center">
                                        <input id="default-radio-{{$key + 1}}"
                                            type="radio"
                                            value="{{ $flow->sid }}"
                                        name="flow_sid"
                                        class="w-4 h-4 text-blue-600 bg-gray-100
                                        border-gray-300 focus:ring-blue-500"
                                        required  @if($device && $device->flow_sid == $flow->sid)
                                            checked
                                        @endif
                                        >
                                        <label for="default-radio-{{$key + 1}}"
                                            class="ml-2 text-sm font-medium
                                            text-gray-900">{{$flow->friendlyName
                                            ?? ''}}</label>
                                    </div>
                                </td>
                                <td class="text-sm px-6 py-3 text-left">
                                    {{$flow->friendlyName ?? ''}}
                                </td>

                                <td class="text-sm px-6 py-3 text-left">
                                    {{ $flow->url}}
                                </td>
                            </tr>
                            @endforeach
                            <input type="hidden" name="callFlowSid" value="{{ $flow->sid}}">
                            <input type="hidden" name="id" value="{{$id}}">

                            <tr>
                                <td colspan="4">
                                    <div class="md:flex gap-3 mt-9 justify-end
                                        border-t px-6">
                                        <a href="{{  route('devices.index',['linked_number' => $linked_number]) }}"
                                            class="inline-block px-7 mt-6 mb-4
                                            py-2 bg-gray-500 text-white
                                            font-medium text-base leading-snug
                                            rounded shadow-md hover:bg-gray-500
                                            hover:shadow-lg focus:bg-gray-500
                                            focus:shadow-lg focus:outline-none
                                            focus:ring-0 active:bg-blue-800
                                            active:shadow-lg transition
                                            duration-150 ease-in-out
                                            ripple-surface-light"
                                            name="action">Cancel</a>


                                        <button type="submit"
                                            class="inline-block px-7 mt-6 mb-4
                                            py-2 bg-orange-500 text-white
                                            font-medium text-base leading-snug
                                            rounded shadow-md
                                            hover:bg-orange-500 hover:shadow-lg
                                            focus:bg-orange-500 focus:shadow-lg
                                            focus:outline-none focus:ring-0
                                            active:bg-blue-800 active:shadow-lg
                                            transition duration-150 ease-in-out
                                            ripple-surface-light"
                                            name="action">
                                            Attach
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </form>
                        @else
                        <tr class="border-t border-b border-gray-100
                            odd:bg-violet-50/25">
                            <td colspan="10">
                                <div class="flex items-center justify-center
                                    w-full
                                    p-4">
                                    <div
                                        class="filament-tables-empty-state flex
                                        flex-1
                                        flex-col items-center justify-center p-6
                                        mx-auto space-y-6 text-center bg-white">
                                        <div
                                            class="flex items-center
                                            justify-center w-16
                                            h-16 text-primary-500 rounded-full
                                            bg-orange-50">
                                            <svg wire:loading.remove.delay="1"
                                                wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                                class="w-6 h-6 text-orange-500"
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none" viewBox="0 0 24 24"
                                                stroke-width="2"
                                                stroke="currentColor"
                                                aria-hidden="true">
                                                <path stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M6 18L18 6M6 6l12 12"></path>
                                            </svg>
                                        </div>
                                        <div class="max-w-md space-y-1">
                                            <h2
                                                class="filament-tables-empty-state-heading
                                                text-xl font-bold
                                                tracking-tight">
                                                No records found
                                            </h2>
                                            <p
                                                class="filament-tables-empty-state-description
                                                whitespace-normal text-sm
                                                font-medium
                                                text-gray-500">
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</article>
@endsection
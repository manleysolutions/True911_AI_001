@extends('layouts.main')
@section('title', 'Devices')
@section('content')
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
   <section class="flex flex-col sm:flex-row gap-3 justify-between items-center
      pt-4">
      <div>
         <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
            Device Listing
         </h2>
         <div class="text-gray-500">Listing of all devices</div>
      </div>
   </section>
 
   <section class="flex flex-col sm:flex-row gap-4 items-center justify-between
      pt-5 ">
      <div class="items-center flex gap-4">
         <label class="font-medium text-base text-black">Devices</label>
         <form method="get" id="linkedForm">
            <div class="flex items-center justify-center">
               <div class="inline-flex shadow-lg hover:shadow-lg focus:shadow-lg
                  rounded-lg" role="group">
                  <button type="button" class="active rounded-l inline-block
                     px-7 py-2 @if(Request('linked_number') == 'all') text-white
                     bg-orange-500 @else text-black @endif bg-white font-medium
                     text-sm leading-tight hover:bg-orange-500 hover:text-white
                     focus:bg-orange-500 focus:outline-none focus:ring-0
                     active:bg-orange-500 transition duration-150 ease-in-out"
                     onclick="linkedForm('all')">All</button>
                  <input type="hidden" name="linked_number" id="linked_number"
                     value="link">
                  <button type="button" class=" inline-block border-l border-r
                     px-7 py-2 bg-white font-medium text-sm leading-tight
                     hover:bg-orange-500 @if(Request('linked_number') == 'link')
                     bg-orange-500 text-white @else text-black @endif
                     hover:text-white focus:bg-orange-500 focus:outline-none
                     focus:ring-0 active:bg-oramge-500 transition duration-150
                     ease-in-out" onclick="linkedForm('link')">Linked</button>
                  <button type="button" class=" rounded-r inline-block px-7 py-2
                     bg-white font-medium text-sm @if(Request('linked_number')
                     == 'unlink') bg-orange-500 text-white @else text-black
                     @endif leading-tight hover:text-white hover:bg-orange-500
                     focus:bg-orange-500 focus:outline-none focus:ring-0
                     active:bg-orange-500 transition duration-150 ease-in-out"
                     onclick="linkedForm('unlink')">Unlinked</button>
               </div>
            </div>
         </form>
      </div>
      <div class="flex gap-2">
         <label class="relative block w-80 ">
            <span class="sr-only">Search</span>
            <span class="absolute inset-y-7 left-0 flex items-center pl-2
               text-gray-300">
               <svg class="h-5 w-5 mb-4" xmlns="http://www.w3.org/2000/svg"
                  width="24" height="24"
                  viewBox="0 0 24 24" fill="none" stroke="currentColor"
                  stroke-width="2" stroke-linecap="round"
                  stroke-linejoin="round">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
               </svg>
            </span>
            <form method="get" action=" {{
               route('devices.index')}}?{{request()->getQueryString()
               }}" id="form_id">
               <input class="placeholder:text-gray-400 block bg-white w-full
                  border
                  border-gray-300 rounded-md py-2 pl-9 pr-3 shadow-sm
                  focus:outline-none
                  focus:border-blue-500 focus:ring-blue-500 focus:ring-1
                  sm:text-sm"
                  placeholder="Unique ID, Device SN, Customer Detail "
                  type="text"
                  name="search" value="{{
                  Request::get('search'),
                  }}">
               <a href="{{route('devices.index', ['search'=> '',
                  'linked_number' => Request::get('linked_number')]);}}"
                  class="absolute top-0 right-0 flex
                  items-center p-2 text-gray-300">
                  <svg class="h-5 w-5 mb-4"
                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                     fill="currentColor">
                     <g>
                        <path fill="none" d="M0 0h24v24H0z"></path>
                        <path
                           d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95
                           4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414
                           4.95-4.95-4.95-4.95L7.05 5.636z">
                        </path>
                     </g>
                  </svg>
               </a>
               <input type="hidden" name="linked_number" value="{{
                  Request::get('linked_number')}}">

            </form>
         </label>
      </div>
   </section>
   <div class="py-4">
      <div class="bg-white rounded-lg">
         <div class="relative overflow-x-auto sm:rounded-lg">
            <table class="w-full text-sm">
               <thead>
                  <tr>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-center">
                        S.No
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('devices.index', ['unique_id'=>
                              request()->query('unique_id') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'linked_number' => request()->query('linked_number'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Unique ID
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('devices.index', ['device_sn'=>
                              request()->query('device_sn') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'linked_number' => request()->query('linked_number'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Device SN
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('devices.index', ['customer_detail'=>
                              request()->query('customer_detail') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'linked_number' => request()->query('linked_number'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Customer Detail
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="{{
                              route('devices.index', ['facility_address'=>
                              request()->query('facility_address') == 'desc' ?
                              'asc' : 'desc',
                              'search' => Request::get('search'),
                              'perPage' => request()->query('perPage'),
                              'linked_number' => request()->query('linked_number'),
                              'page' => request()->query('page'),
                              ])
                              }}">
                              Facility Address
                              <svg xmlns="http://www.w3.org/2000/svg"
                                 class="ml-1 w-3 h-3" aria-hidden="true"
                                 fill="#282727" viewBox="0 0 320 512">
                                 <path
                                    d="M27.66 224h264.7c24.6 0 36.89-29.78
                                    19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                    0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                    194.2 3.055 224 27.66 224zM292.3
                                    288H27.66c-24.6 0-36.89 29.77-19.54
                                    47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                    480c7.053 0 14.12-2.703
                                    19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                    288 292.3 288z">
                                 </path>
                              </svg>
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="#">
                              Linked Number
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        <div class="flex items-center">
                           <a class="flex items-center" href="#">
                              Callflow Name
                           </a>
                        </div>
                     </th>
                     <th class="px-6 py-4 font-medium tracking-wider text-sm
                        truncate text-left">
                        Actions
                     </th>
                  </tr>
               </thead>
               <tbody>
                  @if($devices->count() > 0)

                  @foreach($devices as $key=> $device)

                  <tr class="border-t border-b border-gray-100
                     odd:bg-violet-50/25">

                     <td class="text-sm px-6 py-3 text-center">
                        {{$key + $devices->firstItem()}}
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        {{ $device->unique_id}}
                     </td>

                     <td class="text-sm px-6 py-3 text-left">
                        {{ !empty($device->device_sn) ? $device->device_sn :
                        'N/A'}}
                     </td>


                     <td class="text-sm px-6 py-3 text-left">
                        <div> {{ !empty($device->nick_name) ? $device->nick_name
                           :
                           'N/A'}}</div>
                        <div>{{ !empty($device->facility_name) ? $device->facility_name
                           :
                           'N/A'}}</div>
                     </td>
                     <td class="text-sm px-6 py-3 text-left">
                        <div class="flex gap-1">
                           <div @if(!empty($device->facility_address) &&
                              $device->facility_address
                              != 'N/A' && $device->facility_address != 'PENDING'
                              && $device->facility_address != 'NEED INFO')
                              style="width:220px" @endif>
                              @if(!empty($device->facility_address) && $device->facility_address
                              != 'N/A' && $device->facility_address != 'PENDING'
                              && $device->facility_address != 'NEED INFO')
                              {{ !empty($device->facility_address) ? $device->facility_address
                              : 'N/A'}},
                              {{ !empty($device->facility_city) ? $device->facility_city
                              : 'N/A'}},
                              {{ !empty($device->facility_state) ? $device->facility_state
                              : 'N/A'}}
                              {{ !empty($device->facility_zip) ? $device->facility_zip
                              : 'N/A'}}</div>

                           <button type="button" @if(($device->manageNumber) &&
                              ($device->manageNumber->status != 'registered' &&
                              $device->manageNumber->status !=
                              'registration-failure')) disabled class="
                              text-grey-300" title="Your request is under progress" @endif
                              @click="modal= !modal,getFacilityAddress=`{{
                              $device['facility_address']
                              }}`,getFacilityCity=`{{ $device['facility_city']
                              }}`,getFacilityState=`{{ $device['facility_state']
                              }}`,getFacilityZip=`{{ $device['facility_zip']
                              }}`,getId=`{{ $device['id'] }}`"/" class="
                              text-orange-500
                              text-sm font-medium">
                              <svg class="w-4 h-4"
                                 xmlns="http://www.w3.org/2000/svg"
                                 fill="currentColor" viewBox="0 0 24 24"><path
                                    fill-rule="evenodd" d="M17.263 2.177a1.75
                                    1.75 0 012.474 0l2.586 2.586a1.75 1.75 0 010
                                    2.474L19.53 10.03l-.012.013L8.69 20.378a1.75
                                    1.75 0 01-.699.409l-5.523 1.68a.75.75 0
                                    01-.935-.935l1.673-5.5a1.75 1.75 0
                                    01.466-.756L14.476 4.963l2.787-2.786zm-2.275
                                    4.371l-10.28 9.813a.25.25 0
                                    00-.067.108l-1.264 4.154 4.177-1.271a.25.25
                                    0 00.1-.059l10.273-9.806-2.94-2.939zM19
                                    8.44l2.263-2.262a.25.25 0
                                    000-.354l-2.586-2.586a.25.25 0 00-.354
                                    0L16.061 5.5 19 8.44z"></path></svg>
                           </button>
                        </div>
                        @else
                        <button type="button"
                           @click="modal= !modal, getId=`{{ $device['id'] }}`"/"
                           class="font-semibold text-orange-500 flex
                           items-center gap-1
                           text-sm font-medium "><svg class="w-5 h-5"
                              xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24
                              24" fill="currentColor" aria-hidden="true">
                              <path fill-rule="evenodd" d="M12 2.25c-5.385
                                 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75
                                 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12.75
                                 9a.75.75 0 00-1.5 0v2.25H9a.75.75 0 000
                                 1.5h2.25V15a.75.75 0 001.5 0v-2.25H15a.75.75 0
                                 000-1.5h-2.25V9z" clip-rule="evenodd"></path>
                           </svg> Address</button>
                        @endif
                     </td>

                     <td class="text-sm px-6 py-3 text-left"
                        @if(Request('linked_number')=='link') @endif>
                        <div style="width:140px">
                           @if ($device->manageNumber)
                           <div class="flex gap-2 items-center">
                              <div>
                                 <div>{{$device->manageNumber->manage_number}}
                                 </div>
                                 <div class="font-semibold" title="{{$device->manageNumber->nick_name}}">{{
                                    $device->manageNumber->nick_name }}</div>
                              </div>
                              <a @if(($device->manageNumber) &&
                                 ($device->manageNumber->status != 'registered'
                                 && $device->manageNumber->status !=
                                 'registration-failure')) href="#"
                                 class="text-grey-300" title="Your request is under progress" @endif
                                 class=" text-orange-500
                                 text-sm font-medium"
                                 href="{{route('update-number',[
                                 encrypt($device->id),
                                 'linked_number' => request()->query('linked_number') ?? ''
                                 ])}}">
                                 <svg class="w-4 h-4"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="currentColor" viewBox="0 0 24 24"><path
                                       fill-rule="evenodd" d="M17.263 2.177a1.75
                                       1.75 0 012.474 0l2.586 2.586a1.75 1.75 0
                                       010 2.474L19.53 10.03l-.012.013L8.69
                                       20.378a1.75 1.75 0 01-.699.409l-5.523
                                       1.68a.75.75 0 01-.935-.935l1.673-5.5a1.75
                                       1.75 0 01.466-.756L14.476
                                       4.963l2.787-2.786zm-2.275 4.371l-10.28
                                       9.813a.25.25 0 00-.067.108l-1.264 4.154
                                       4.177-1.271a.25.25 0
                                       00.1-.059l10.273-9.806-2.94-2.939zM19
                                       8.44l2.263-2.262a.25.25 0
                                       000-.354l-2.586-2.586a.25.25 0 00-.354
                                       0L16.061 5.5 19 8.44z"></path></svg>
                              </a>

                           </div>


                           @else
                           <a @if(($device->manageNumber) &&
                              ($device->manageNumber->status != 'registered' &&
                              $device->manageNumber->status !=
                              'registration-failure')) href="#"
                              class="text-grey-300" title="Your request is under progress" @endif
                              style="width: 140px"
                              href="{{ route('attach-number.index', [
                              encrypt($device->id),
                              'linked_number' => request()->query('linked_number') ?? ''
                                 ]) }}" 
                              class="font-semibold block text-orange-500 text-sm
                              font-medium">Attach Number</a>
                           @endif
                        </div>
                     </td>

                     <td class="text-sm px-6 py-3 text-left">
                        @if ($device->flow_sid)
                        <div class="flex gap-1">
                           <div>{{ $device->flow_name ?? '' }}</div>
                           <a  @if(($device->manageNumber) &&
                              ($device->manageNumber->status != 'registered' &&
                              $device->manageNumber->status !=
                              'registration-failure')) href="#"
                              class="text-grey-300" title="Your request is under progress" @endif
                              class=" text-orange-500
                              text-sm font-medium"
                              href="{{route('call-flow.listing', [
                              encrypt($device->id),
                              'linked_number' => request()->query('linked_number') ?? ''
                              ])}}">
                              <svg class="w-4 h-4"
                                 xmlns="http://www.w3.org/2000/svg"
                                 fill="currentColor" viewBox="0 0 24 24"><path
                                    fill-rule="evenodd" d="M17.263 2.177a1.75
                                    1.75 0 012.474 0l2.586 2.586a1.75 1.75 0 010
                                    2.474L19.53 10.03l-.012.013L8.69 20.378a1.75
                                    1.75 0 01-.699.409l-5.523 1.68a.75.75 0
                                    01-.935-.935l1.673-5.5a1.75 1.75 0
                                    01.466-.756L14.476 4.963l2.787-2.786zm-2.275
                                    4.371l-10.28 9.813a.25.25 0
                                    00-.067.108l-1.264 4.154 4.177-1.271a.25.25
                                    0 00.1-.059l10.273-9.806-2.94-2.939zM19
                                    8.44l2.263-2.262a.25.25 0
                                    000-.354l-2.586-2.586a.25.25 0 00-.354
                                    0L16.061 5.5 19 8.44z"></path></svg>
                           </a>

                        </div>
                        @else
                        <a  @if(($device->manageNumber) &&
                           ($device->manageNumber->status != 'registered' &&
                           $device->manageNumber->status != 'unregistered' &&
                           $device->manageNumber->status !=
                           'registration-failure')) href="#"
                           class="text-grey-300" title="Your request is under progress" @endif
                           style="width: 140px"
                           href="{{route('call-flow.listing', [
                              encrypt($device->id),
                              'linked_number' => request()->query('linked_number') ?? ''
                              ])}}"
                           type="submit"
                           class="text-orange-500 block text-sm
                           font-medium">Attach Call Flow</a>
                        @endif
                     </td>
                     <td class="text-sm px-6 py-6 text-left
                        items-center gap-4">
                        <div class="flex gap-4 w-[130px]">
                           <a href="{{route('devices.view', [
                              encrypt($device->id),
                              'linked_number' => request()->query('linked_number') ?? ''
                              ])}}"
                              class=" text-orange-500 text-sm
                              font-medium">View</a>
                           <a class=" text-orange-500 text-sm
                              font-medium" href="{{route('devices.call-logs',[
                              encrypt($device->id),
                              'linked_number' => request()->query('linked_number') ?? ''
                              ])}}">Call Logs</a>
                        </div>
                     </td>
                  </tr>

                  @endforeach
                  @else
                  <tr class="border-t border-b border-gray-100
                     odd:bg-violet-50/25">
                     <td colspan="10">
                        <div class="flex items-center justify-center w-full
                           p-4">
                           <div
                              class="filament-tables-empty-state flex flex-1
                              flex-col items-center justify-center p-6 mx-auto
                              space-y-6 text-center bg-white">
                              <div
                                 class="flex items-center justify-center w-16
                                 h-16 text-primary-500 rounded-full
                                 bg-orange-50">
                                 <svg wire:loading.remove.delay="1"
                                    wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage"
                                    class="w-6 h-6 text-orange-500"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24"
                                    stroke-width="2" stroke="currentColor"
                                    aria-hidden="true">
                                    <path stroke-linecap="round"
                                       stroke-linejoin="round"
                                       d="M6 18L18 6M6 6l12 12"></path>
                                 </svg>
                              </div>
                              <div class="max-w-md space-y-1">
                                 <h2
                                    class="filament-tables-empty-state-heading
                                    text-xl font-bold tracking-tight">
                                    No records found
                                 </h2>
                                 <p
                                    class="filament-tables-empty-state-description
                                    whitespace-normal text-sm font-medium
                                    text-gray-500">
                                 </p>
                              </div>
                           </div>
                        </div>
                     </td>
                  </tr>
                  @endif
               </tbody>
            </table>
            <div class="flex items-center gap-2 p-2">
               <form method="get">
                  <select
                     class="bg-gray-50 w-20 border border-gray-300
                     text-gray-900 text-sm rounded focus:ring-blue-500
                     focus:border-blue-500 block w-full p-2"
                     name="perPage" onchange="this.form.submit()">
                     <option value="10" @if(Request('perPage')==10) selected
                        @endif>10</option>
                     <option value="25" @if(Request('perPage')==25) selected
                        @endif>25</option>
                     <option value="50" @if(Request('perPage')==50) selected
                        @endif>50</option>
                     <option value="100" @if(Request('perPage')==100) selected
                        @endif>100</option>
                     <option value="200" @if(Request('perPage')==200) selected
                        @endif>200</option>
                     <option value="{{ $devices->total() }}"
                        @if(Request('perPage')== $devices->total())
                        selected @endif>All</option>
                  </select>
                  <input type="hidden" name="search" value="{{
                     Request::get('search')}}">
                  <input type="hidden" name="unique_id" value="{{
                     Request::get('unique_id')}}">
                  <input type="hidden" name="device_sn" value="{{
                     Request::get('device_sn')}}">
                  <input type="hidden" name="device_imei" value="{{
                     Request::get('device_imei')}}">
                  <input type="hidden" name="customer_detail" value="{{
                     Request::get('customer_detail')}}">
                  <input type="hidden" name="tmobile_msisdn" value="{{
                     Request::get('tmobile_msisdn')}}">
                  <input type="hidden" name="facility_address" value="{{
                     Request::get('facility_address')}}">
                  <input type="hidden" name="linked_number" value="{{
                     Request::get('linked_number')}}">


               </form>
               <label for="title" class="block text-sm font-semibold
                  text-gray-900">
                  Per Page
               </label>
            </div>
            {{ $devices->appends(['search' => Request::get('search') ?? '',
            'unique_id' => request()->query('unique_id') ?? '',
            'device_sn' => request()->query('device_sn') ?? '',
            'device_imei' => request()->query('device_imei') ?? '',
            'customer_detail' => request()->query('customer_detail') ?? '',
            'tmobile_msisdn' => request()->query('tmobile_msisdn') ?? '',
            'facility_address' => request()->query('facility_address') ?? '',
            'perPage' => request()->query('perPage') ?? '',
            'linked_number' => request()->query('linked_number') ?? ''
            ])->links();
            }}
         </div>
      </div>
   </div>
   <!-- Form -->
   <template x-teleport="body">
      <div class="relative z-10" x-show="modal" aria-labelledby="modal-title"
         role="dialog" aria-modal="true">
         <div class="pageLoader" id="pageLoaderss"></div>
         <div class="fixed inset-0 bg-gray-500 bg-opacity-75
            transition-opacity"></div>
         <div class="fixed inset-0 z-10 overflow-y-auto">
            <div class="flex min-h-full items-end justify-center p-4 text-center
               sm:items-center sm:p-0">
               <div class="relative transform overflow-hidden rounded-lg
                  bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full
                  max-w-3xl">
                  <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                     <div class="sm:flex sm:items-start">
                        <div class="sm:mt-0 text-left">
                           <div class="flex justify-between gap-2 pb-4
                              border-b-2 border-gray-500">
                              <h3 class="text-xl font-medium leading-6
                                 text-gray-900" id="modal-title">Facility
                                 Address</h3>
                              <a href="javascript:void(0);" class="text-xl"
                              @click="modal = false;location.reload()"
                              >&times;</a>
                           </div>
                           <div class="pt-6 divide-y devide-gray-200">
                              <div>
                                 <h3 class="py-4 font-semibold">Add Address</h3>
                                 <p class="text-sm text-gray-500">This address
                                    represents the physical address to be used
                                    for emergency calling, emergency medical and
                                    other response resources.</p>
                                 <form
                                    action="{{route('devices.address.update')}}"
                                    method="POST"
                                    id="form"
                                    class="w-full pt-4 flex flex-col gap-4
                                    loaderForm">
                                    @csrf
                                    <div>
                                       <label for="address" class="">Address
                                          <span class="text-red-700">*</span>
                                       </label>
                                       <input
                                          type="text"
                                          wire:model="address"
                                          name="address"
                                          id="address"
                                          class="bg-gray-50 border
                                          border-gray-300 text-gray-900 text-sm
                                          rounded
                                          focus:ring-blue-500
                                          focus:border-blue-500 block w-full
                                          p-2.5"
                                          pattern="[a-zA-Z0-9 ]{1,48}"
                                          x-model="getFacilityAddress"
                                          value="{{old('address')}}"
                                          required
                                          />
                                       <span class="text-red"> {{ $errors->first('address1')
                                          }}</span>
                                    </div>
                                    <div class="flex flex-col md:flex-row
                                       gap-4">
                                       <div class="flex-1">
                                          <label for="city" class="">City
                                             <span class="text-red-700">*</span>
                                          </label>
                                          <input
                                             type="text"
                                             wire:model="city"
                                             name="city"
                                             id="city"
                                             class="bg-gray-50 border
                                             border-gray-300 text-gray-900
                                             text-sm rounded
                                             focus:ring-blue-500
                                             focus:border-blue-500 block w-full
                                             p-2.5"
                                             pattern="^([a-zA-Z]+\s)*[a-zA-Z]+$"
                                             value="{{old('city')}}"
                                             x-model="getFacilityCity"
                                             required
                                             />
                                          <span class="text-red"> {{ $errors->first('city')
                                             }}</span>
                                       </div>
                                       <div class="flex-1">
                                          <label for="stateProvision" class="">State
                                             / Province / Region
                                             <span class="text-red-700">*</span>
                                          </label>
                                          <input
                                             type="text"
                                             wire:model="stateProvision"
                                             name="stateProvision"
                                             id="stateProvision"
                                             class="bg-gray-50 border
                                             border-gray-300 text-gray-900
                                             text-sm rounded
                                             focus:ring-blue-500
                                             focus:border-blue-500 block w-full
                                             p-2.5"
                                             pattern="[a-zA-Z]{2,48}"
                                             x-model="getFacilityState"
                                             value="{{old('stateProvision')}}"
                                             required
                                             />
                                          <span class="text-red"> {{ $errors->first('stateProvision')
                                             }}</span>
                                       </div>
                                       <input type="hidden" name="deviceId"
                                          x-model="getId" />
                                       <div class="flex-1">
                                          <label for="postalCode" class="">Postal
                                             Code
                                             <span class="text-red-700">*</span>
                                          </label>
                                          <input
                                             type="text"
                                             wire:model="postalCode"
                                             name="postalCode"
                                             id="postalCode"
                                             class="bg-gray-50 border
                                             border-gray-300 text-gray-900
                                             text-sm rounded
                                             focus:ring-blue-500
                                             focus:border-blue-500 block w-full
                                             p-2.5"
                                             pattern="^([a-zA-Z0-9]+\s)*[a-zA-Z0-9]+$"
                                             value="{{old('postalCode')}}"
                                             x-model="getFacilityZip"
                                             required
                                             />
                                          <span class="text-red"> {{ $errors->first('postalCode')
                                             }}</span>
                                       </div>
                                    </div>
                                    <div>
                                       <label for="country">Country</label>
                                       <input
                                          type="text"
                                          wire:model="country"
                                          name="country"
                                          id="country" disabled
                                          class="mt-2 text-gray-900 block w-full
                                          transition duration-75 rounded-lg
                                          shadow-sm disabled:opacity-70
                                          border-gray-300 bg-gray-50"
                                          value="US"
                                          />
                                    </div>
                                    <div class="py-3 sm:flex
                                       sm:flex-row-reverse">

                                       <button
                                          class="inline-flex w-full
                                          justify-center rounded border
                                          border-transparent bg-orange-500 px-4
                                          py-2 text-base font-medium shadow-sm
                                          hover:bg-orange-500 text-white
                                          focus:outline-none focus:ring-2
                                          focus:ring-primary-500
                                          focus:ring-offset-2 sm:ml-3 sm:w-auto
                                          sm:text-sm"
                                          type="submit"
                                          id="submitForm">
                                          Save
                                       </button>

                                       <button
                                          type="button"
                                          @click="modal = false;"
                                          class="mt-3 inline-flex w-full
                                          justify-center rounded-md border
                                          border-gray-300 bg-white px-4 py-2
                                          text-base font-medium text-gray-700
                                          shadow-sm hover:bg-gray-50
                                          focus:outline-none focus:ring-2
                                          focus:ring-indigo-500
                                          focus:ring-offset-2 sm:mt-0 sm:ml-3
                                          sm:w-auto sm:text-sm">
                                          Cancel
                                       </button>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </template>

</article>
@endsection
@extends('layouts.main')
@section('title', 'Devices')
@section('content')
@php
    if (Request('linked_number')) {
        $linked_number = Request('linked_number');
    } else {
        $linked_number = '';
    }
@endphp
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">
        <ol class="list-reset flex gap-1">
            <a href="{{  route('devices.index',['linked_number' => $linked_number]) }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24"><path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path></svg></a>
             <li><a href="{{  route('devices.index',['linked_number' => $linked_number]) }}" class="text-black font-semibold hover:text-black">Device</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">View Device</li>
        </ol>
    </nav>
    <section class="flex flex-col sm:flex-row gap-3 justify-between items-center
      pt-4">
      <div>
         <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
            View Device
         </h2>
         <div class="text-gray-500">Full information about the device</div>
      </div>
   </section>

    <div class="bg-white rounded-lg p-6 mt-6">
        <div class="md:flex gap-8">
            <div class="md:w-1/3 w-full justify-center">
                <div class="shadow border p-4 rounded">
                    <div class="text-xl font-semibold mb-3">{{ isset($device->nick_name) && !empty($device->nick_name) ? $device->nick_name :  'N/A'}}</div>
                    <ul>
                        <li class="flex gap-1 items-center mb-2 font-medium text-gray-600">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"></path>
                            </svg>{{$device->email ? $device->email:'N/A'}}
                        </li>
                        <li class="flex gap-1 items-center mb-2 font-medium text-gray-600"><svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path fill-rule="evenodd" d="M1.5 4.5a3 3 0 013-3h1.372c.86 0 1.61.586 1.819 1.42l1.105 4.423a1.875 1.875 0 01-.694 1.955l-1.293.97c-.135.101-.164.249-.126.352a11.285 11.285 0 006.697 6.697c.103.038.25.009.352-.126l.97-1.293a1.875 1.875 0 011.955-.694l4.423 1.105c.834.209 1.42.959 1.42 1.82V19.5a3 3 0 01-3 3h-2.25C8.552 22.5 1.5 15.448 1.5 6.75V4.5z" clip-rule="evenodd"></path>
                            </svg>{{$device->phone ? $device->phone :'N/A'}}</li>
                        <li class="flex gap-1 items-center mb-2 font-medium text-gray-600"><svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M11.47 3.84a.75.75 0 011.06 0l8.69 8.69a.75.75 0 101.06-1.06l-8.689-8.69a2.25 2.25 0 00-3.182 0l-8.69 8.69a.75.75 0 001.061 1.06l8.69-8.69z"></path>
                                <path d="M12 5.432l8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 01-.75-.75v-4.5a.75.75 0 00-.75-.75h-3a.75.75 0 00-.75.75V21a.75.75 0 01-.75.75H5.625a1.875 1.875 0 01-1.875-1.875v-6.198a2.29 2.29 0 00.091-.086L12 5.43z"></path>
                            </svg>{{ $device->billing_address ? $device->billing_address : 'N/A'}},{{ $device->billing_city ? $device->billing_city:'N/A'}},{{$device->billing_state ? $device->billing_state: 'N/A'}} {{$device->billing_zip ? $device->billing_zip : 'N/A'}}</li>
                    </ul>
                </div>
            </div>
            <div class="gap-4 md:w-2/3">
                <div class="shadow border p-4 rounded">
                    <div class="text-xl font-semibold mb-3">Device Info</div>
                    <div class="flow-root">
                        <ul role="list" class="divide-y divide-gray-200 d">
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate">
                                            Unique Id:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        {{ !empty($device->unique_id) ? $device->unique_id: 'N/A'}}
                                    </div>
                                </div>
                            </li>
                           
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate">
                                            Device SN:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        {{ !empty($device->device_sn) ? $device->device_sn : 'N/A'}}
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate">
                                            Device IMEI or MEID:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        {{ !empty($device->device_imei) ? $device->device_imei : 'N/A'}}
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate ">
                                             SIM:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600 ">
                                        {{!empty($device->tmobile_sim) ? $device->tmobile_sim : 'N/A'}}
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate ">
                                            MSISDN:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600 ">
                                        {{ !empty($device->tmobile_msisdn) ? $device->tmobile_msisdn : 'N/A'}}
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate ">
                                            Linked Number:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600 ">
                                        {{ !empty($device->manageNumber) ? $device->manageNumber->manage_number : 'N/A'}} {{ isset($device->manageNumber) ? '- '.$device->manageNumber->nick_name : 'N/A'}}
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate ">
                                            Call Flow Name:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600 ">
                                        
                                       {{$device->flow_name ? $device->flow_name : 'N/A' }}
                                        
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate">
                                            Facility Address:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        
                                       {{$device->facility_address ? $device->facility_address: 'N/A' }},{{ !empty($device->facility_city) ? $device->facility_city : 'N/A' }},{{$device->facility_state ? $device->facility_state: 'N/A' }} {{$device->facility_zip ? $device->facility_zip :'N/A' }}
                                        
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate ">
                                            Facility Name:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        
                                       {{$device->facility_name ? $device->facility_name:'N/A' }} 
                                        
                                    </div>
                                </div>
                            </li>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">

                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-600 truncate">
                                            Account Name:
                                        </p>

                                    </div>
                                    <div class="inline-flex items-center text-base font-semibold text-gray-600">
                                        
                                       {{$device->account_name ? $device->account_name :'N/A' }} 
                                        
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</article>
@endsection
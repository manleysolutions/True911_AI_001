@extends('layouts.main')
@section('title', 'Ported Number')
@section('content')

<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">

        <ol class="list-reset flex gap-1">
            <a href="{{ route('ported-number-listing') }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24">
                    <path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path>
                </svg></a>
            <li><a href="{{ route('ported-number-listing') }}" class="text-black font-semibold hover:text-black">Ported Numbers</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">New port request</li>
        </ol>
    </nav>
    <section class="gap-3 justify-between  pt-4  w-full">
        <h2 class="font-semibold text-lg text-gray-800 leading-tight">
            New Port Request
        </h2>
        <div class="mb-4">Create new port request.</div>
    </section>
    <form method="post" action="{{ route('ported-number.store') }}" enctype="multipart/form-data" id="port">
        @csrf
        <div class="bg-white rounded-lg p-8 w-full">
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        First Name<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="First Name" id="title" value="{{old('first_name')}}" name="first_name" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required pattern="^([a-zA-Z]+\s)*[a-zA-Z]+$" maxlength="40" onkeypress="return validate(event)">
                    <span class="text-red-700"> {{ $errors->first('first_name') }}</span>

                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Last Name<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Last Name" id="title" name="last_name" value="{{old('last_name')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required pattern="^([a-zA-Z]+\s)*[a-zA-Z]+$" maxlength="40" onkeypress="return validate(event)">
                    <span class="text-red-700"> {{ $errors->first('last_name') }}</span>

                </div>
            </div>
            <div class="gap-6 mb-4 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Address 1<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Address 1" id="title" name="address" value="{{old('address')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" maxlength="255">
                </div>
                <span class="text-red-700"> {{ $errors->first('address') }}</span>

            </div>
            <div class="gap-6 mb-4 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Address 2
                    </label>
                    <input type="text" placeholder="Address 2" id="title" name="address_2" value="{{old('address_2')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" maxlength="255">
                </div>

            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-3 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        City<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="City" id="title" value="{{old('city')}}" name="city" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required maxlength="40" onkeypress="return validate(event)">
                    <span class="text-red-700"> {{ $errors->first('city') }}</span>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        State/Province/Region<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="State/Province/Region" id="title" value="{{old('state')}}" name="state" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required maxlength="40" onkeypress="return validate(event)">
                    <span class="text-red-700"> {{ $errors->first('state') }}</span>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Postal Code<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Postal Code" id="title" name="postal_code" value="{{old('postal_code')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required maxlength="40" onkeypress="return validate(event)">
                    <span class="text-red-700"> {{ $errors->first('postal_code') }}</span>
                </div>
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Wireless Number<span class="text-red-700">*</span>
                    </label>
                    <input type="text" id="cell_phone" placeholder="Wireless Number" id="title" name="" value="{{old('number')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                    <input id="phone" type="hidden" name="number" required />
                    <span class="text-red-700"> {{ $errors->first('number') }}</span>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Wireless Account Number<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Wireless Account Number" id="title" name="account_number" value="{{old('account_number')}}" class="border border-gray-300 text-gray-900 text-sm rounded
                            focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" maxlength="16" pattern="[0-9.]+">
                    <span class="text-red-700"> {{ $errors->first('account_number') }}</span>
                </div>
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-3 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Choose Option<span class="text-red-700">*</span>
                    </label>
                    <select class="border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="option" required>
                        <option value="residence">Residential</option>
                        <option value="business">Business</option>
                    </select>
                    <span class="text-red-700"> {{ $errors->first('option') }}</span>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        PIN/Last 4 of SSN<span class="text-red-700">*</span>
                    </label>
                    <input type="number" id="title" name="pin" class="orderUnits border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{old('pin')}}" value="" required oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="4">
                    <span class="text-red-700"> {{ $errors->first('pin') }}</span>
                </div>
            </div>
            <input type="hidden" name="status" value="0">
            <div class="font-semibold">Documents<span class="text-red-700">*</span></div>
            <p>Your letter of authorization and Billing statement must be PDF fies and can not exceed combined of <b>4MB</b></p>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4 group" id="exceed_id">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Letter of Authorization
                    </label>
                    <input type="file" accept="application/pdf" id="file-letter" name="letter_authorization" class="border border-gray-300 text-gray-900 text-sm rounded
                focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required onchange="Upload()">
                    <span class="text-red-700"> {{ $errors->first('letter_authorization') }}</span>
                    <small class="error hidden group-[.is-exceed]:block">Your file size exceed to 4MB </small>
                </div>
                <div class="w-full mt-4 group" id="exceed_id2">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Billing Statement
                    </label>
                    <input type="file" id="billing-letter" accept="application/pdf" name="billing_statement" class="border border-gray-300 text-gray-900 text-sm rounded
                focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="" required onchange="Upload()">
                    <span class="text-red-700"> {{ $errors->first('billing_statement') }}</span>
                    <small class="error hidden group-[.is-exceed]:block">Your file size exceed to 4MB </small>
                </div>
            </div>
            <div class="md:flex gap-3 mt-9 border-t">

                <button type="submit" id="sbmt-btn" class="inline-block px-7 mt-6 mb-4 py-3 bg-orange-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-orange-500 hover:shadow-lg focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light" name="action">
                    Submit
                </button>
                <a href="{{ route('ported-number.create') }}" class="inline-block px-7 mt-6 mb-4 py-3 bg-gray-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-gray-500 hover:shadow-lg focus:bg-gray-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light">
                    Reset
                </a>

            </div>
            <div class="font-semibold">Note:- Porting may take one month time.</div>
        </div>

    </form>
</article>
    <script type="text/javascript">
        function preventBack() {
            window.history.forward();
        }
        setTimeout("preventBack()", 0);
        window.onunload = function() {
            null
        };
    </script>
    <script>
        let phone = document.querySelectorAll('.phone');
        phone.forEach(element => {
            let maskedNumber = `(${element.innerText.slice(0, 3)}) ${element.innerText.slice(3, 6)}-${element.innerText.slice(6, 10)}`;
            element.innerText = maskedNumber;
        });

        let number = document.getElementById('cell_phone');
        if (number) {
            document.getElementById('phone').value = number.value;
            if (document.getElementById('phone').value) {
                let maskedNumber = `(${number.value.slice(0, 3)}) ${number.value.slice(3, 6)}-${number.value.slice(6, 10)}`;
                document.getElementById('cell_phone').value = maskedNumber;
            }

            document.getElementById('cell_phone').addEventListener('input', function() {
                let number = this.value;
                let x = number.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
                document.getElementById('phone').value = x[0];
                document.getElementById('cell_phone').value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
            });
        }
    </script>
    <script>
        document.getElementsByClassName("orderUnits")[0].addEventListener("input", amountofUnits);

        function amountofUnits() {
            this.value = this.value.replace(/[^\d]/, '')
        }

        function validate(e) {
            var k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        function newFunction() {
            document.getElementById("port").reset();
        }

        function Upload() {
            var size = 0;
            var sizeb = 0;
            var fileUpload = document.getElementById("file-letter");
            document.getElementById('exceed_id').classList.remove("is-exceed");
            document.getElementById('exceed_id2').classList.remove("is-exceed");
            if (fileUpload.files.length != 0) {
                var sizeBytes = fileUpload.files[0].size;
                var size = sizeBytes / 1024 ** 2;
                
            }
            var fileBilling = document.getElementById("billing-letter");
            if (fileBilling.files.length != 0) {
                var sizeBytes = fileBilling.files[0].size;
                var sizeb = sizeBytes / 1024 ** 2;   
            }
            var sum = parseFloat(size) + parseFloat(sizeb);
            
            if (sum < 4) {
                document.getElementById('sbmt-btn').removeAttribute("disabled", 'true');
                document.getElementById('sbmt-btn').classList.remove("bg-gray-100", "cursor-not-allowed")
            } else {
                if (parseFloat(size) > 4) {
                    document.getElementById("file-letter").value = '';
                    handleFileUploader();
                } else if (parseFloat(sizeb) > 4) {
                    document.getElementById("billing-letter").value = '';
                    handleFileUploader();
                } else {
                    document.getElementById("billing-letter").value = '';
                    document.getElementById("file-letter").value = '';
                    handleFileUploader();
                }
            }
        }
        function handleFileUploader() {
            document.getElementById('exceed_id').classList.add("is-exceed");
            document.getElementById('exceed_id2').classList.add("is-exceed");
            document.getElementById('sbmt-btn').setAttribute("disabled", 'true');
            document.getElementById('sbmt-btn').classList.add("bg-gray-100", "cursor-not-allowed")
        }
    </script>
    @endsection
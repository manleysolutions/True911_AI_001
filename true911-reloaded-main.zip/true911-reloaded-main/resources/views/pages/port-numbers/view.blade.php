@extends('layouts.main')
@section('title', 'Ported Number')
@section('content')
<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <nav class="rounded-md w-full">
        <ol class="list-reset flex gap-1">
            <a href="{{ route('ported-number-listing') }}"><svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="none" viewBox="0 0 24 24">
                    <path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"></path>
                </svg></a>
            <li><a href="{{ route('ported-number-listing') }}" class="text-black-600 font-semibold hover:text-blue-800">Ported Numbers</a></li>
            <li><span class="text-gray-500 mx-2">/</span></li>
            <li class="text-gray-500">View</li>
        </ol>
    </nav>
    <section class="gap-3 justify-between  pt-4  w-full">
        <h2 class="font-semibold text-lg text-gray-800 leading-tight">
            View Details
        </h2>
        <div class="mb-4">View all information about ported number</div>
    </section>
    <form method="post" action="{{ route('ported-number.update',$portNumber['id']) }}" enctype="multipart/form-data" id="port">
        @csrf
        <div class="bg-white rounded-lg p-8 w-full">
            <div class="grid gap-6 mb-4 md:grid-cols-3 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Status<span class="text-red-700">*</span>
                    </label>
                    <select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="status" id="status-check" required>
                        @foreach($types as $type)
                        @if ($type == $portNumber['status'])
                        <option value="{{ $type }}" selected="selected">{{ $type }}</option>
                        @else
                        <option value="{{ $type }}">{{ $type }}</option>
                        @endif
                        @endforeach
                    </select>
                </div>
                <div class="w-full mt-4  hidden" id="request">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900 ">
                        Request Date<span class="text-red-700">*</span>
                    </label>
                    <input type="date" id="request-input" name="request_date" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="">
                </div>
                <div class="w-full mt-4  hidden" id="reason">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900 ">
                        Comment<span class="text-red-700">*</span>
                    </label>
                    <textarea class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded  focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows='3' id="comment-txt" name="comment" maxlength="150">{{$portNumber['comment']}}</textarea>
                </div>
                <div class="w-full mt-4  hidden" id="reason_cancellation">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Reason for Cancellation<span class="text-red-700">*</span>
                    </label>
                    <textarea class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows='3' id="comment-cancel" name="cancel_comment" maxlength="150">{{$portNumber['comment']}}</textarea>
                </div>
                @if($portNumber['status'] == "REQUESTED")
                <div class="w-full mt-4" id='request-selected'>
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">Request Date<span class="text-red-700">*
                        </span>
                    </label>
                    <input type="text" id="" name="request_date" class=" bg-gray-100 cursor-not-allowed border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['request_date']}}" readonly>
                </div>
                @endif
                @if($portNumber['status'] == "REJECTED")
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Comment<span class="text-red-700">*</span>
                    </label>
                    <textarea class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows='3' name="" readonly>{{$portNumber['comment']}}</textarea>
                </div>
                @endif
                @if($portNumber['status'] == "CANCELLED")
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Reason for Cancellation<span class="text-red-700">*</span>
                    </label>
                    <textarea class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows='3' name="" readonly>{{$portNumber['cancel_comment']}}</textarea>
                </div>
                @endif
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        First Name<span class="text-red-700">*</span>
                    </label>
                    <?php $status = $portNumber['status'] == 'PENDING' ? '' : 'readonly' ?>
                    <?php $sllect = $portNumber['status'] == 'PENDING' ? '' : 'disabled' ?>
                    <input type="text" placeholder="First Name" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['first_name']}}" name="first_name" {{$status}} onkeypress="return validate(event)">
                    <div class="error">{{ $errors->first('first_name') }}</div>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Last Name<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Last Name" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['last_name']}}" name="last_name" {{$status}} onkeypress="return validate(event)">
                    <div class="error">{{ $errors->first('last_name') }}</div>
                </div>
            </div>
            <div class="gap-6 mb-4 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Address 1<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Address 1" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['address']}}" name="address" {{$status}}>
                    <div class="error">{{ $errors->first('address') }}</div>
                </div>
            </div>
            <div class="gap-6 mb-4 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Address 2
                    </label>
                    <input type="text" placeholder="Address 2" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['address_2']}}" name="address_2" {{$status}}>
                    <div class="error">{{ $errors->first('address_2') }}</div>
                </div>
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-3 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        City<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="City" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['city']}}" name="city" {{$status}} onkeypress="return validate(event)">
                    <div class="error">{{ $errors->first('city') }}</div>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        State/Province/Region<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="State/Province/Region" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['state']}}" name="state" {{$status}} onkeypress="return validate(event)">
                    <div class="error">{{ $errors->first('state') }}</div>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Postal Code<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Postal Code" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['postal_code']}}" name="postal_code" {{$status}} onkeypress="return validate(event)">
                    <div class="error">{{ $errors->first('postal_code') }}</div>
                </div>
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Wireless Number<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Wireless Number" id="cell_phone" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['number']}}" name="number" {{$status}}>
                    <input id="phone" type="hidden" name="number" value="" required />
                    <div class="error">{{ $errors->first('number') }}</div>
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Wireless Account Number<span class="text-red-700">*</span>
                    </label>
                    <input type="text" placeholder="Wireless Account Number" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" name="account_number" value="{{$portNumber['account_number']}}" {{$status}} oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" maxlength="16" pattern="[0-9.]+">
                    <div class="error">{{ $errors->first('account_number') }}</div>
                </div>
            </div>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Choose Option<span class="text-red-700">*</span>
                    </label>
                    <select id="option-select" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{ucfirst($portNumber['option'])}}" {{$sllect}} name="option" required>
                        @if($portNumber['option'] == "residence")
                        <option value="residence" selected="selected">Residential</option>
                        <option value="business">Business</option>
                        @else
                        <option value="residence">Residence</option>
                        <option value="business" selected="selected">Business</option>
                        @endif
                    </select>
                    <div class="error">{{ $errors->first('option') }}</div>
                    <!--  -->
                </div>
                <div class="w-full mt-4">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        PIN/Last 4 of SSN<span class="text-red-700">*</span>
                    </label>
                    <input type="text" id="title" class="{{ $portNumber['status'] == 'PENDING' ? 'bg-white' : 'bg-gray-100 cursor-not-allowed'}} border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" value="{{$portNumber['pin']}}" name="pin" {{$status}} value="{{old('pin')}}" value="" required maxlength="4" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                    <div class="error">{{ $errors->first('pin') }}</div>
                </div>
            </div>
            @if($portNumber['status'] == 'PENDING')
            <div class="font-semibold">Documents<span class="text-red-700">*</span></div>
            <p>Your letter of authorization and Billing statement must be PDF fies and can not exceed combined of <b>4MB</b></p>
            <div class="grid gap-6 mb-4 md:grid-cols-2 w-full">
                <div class="w-full mt-4 group" id="exceed_id">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Letter of Authorization
                    </label>
                    <input type="file" accept="application/pdf" id="p-document" name="letter_authorization" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" onchange="Upload()" value="/tmp/phpUsvLiz">
                    @if($portNumber['document'][0]['document_type']=="Authorization")
                    <span id="p-document-name">{{$portNumber['document'][0]['display_name']}} </span>
                    <input type="hidden" id="p-document-size" value="{{$portNumber['document'][0]['size']}}">
                    @endif
                    @if($portNumber['document'][1]['document_type']=="Authorization")
                    <span id="p-document-name">{{$portNumber['document'][1]['display_name']}} </span>
                    <input type="hidden" id="p-document-size" value="{{$portNumber['document'][1]['size']}}">
                    @endif
                    <small class="error hidden group-[.is-exceed]:block">Your file size exceed to 4MB </small>
                </div>
                <div class="w-full mt-4 group" id="exceed_id2">
                    <label for="title" class="block mb-2 text-sm font-semibold text-gray-900">
                        Billing Statement
                    </label>
                    <input type="file" id="b-document" accept="application/pdf" name="billing_statement" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded
                focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" onchange="Upload()">
                    @if($portNumber['document'][0]['document_type']=="Billing")
                    <span id="b-document-name">{{$portNumber['document'][0]['display_name']}} </span>
                    <input type="hidden" id="b-document-size" value="{{$portNumber['document'][0]['size']}}">
                    @endif
                    @if($portNumber['document'][1]['document_type']=="Billing")
                    <span id="b-document-name">{{$portNumber['document'][1]['display_name']}} </span>
                    <input type="hidden" id="b-document-size" value="{{$portNumber['document'][1]['size']}}">
                    @endif
                    <small class="error hidden group-[.is-exceed]:block">Your file size exceed to 4MB </small>
                </div>
            </div>
            @else
            <div class="font-semibold mb-6 mt-6">Documents</div>
            <ul>
                @foreach($portNumber['document'] as $document)
                <li class=" gap-2 items-center mb-3">
                    @if($document['document_type']== "Authorization")
                    <div class="font-semibold">Letter of Authorization</div>
                    <a class="flex gap-2 items-center" href="{{ route('ported-number.download',$document['id']) }}">
                        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" fill="currentColor">
                            <path d="M3.5 8H3V7h.5a.5.5 0 010 1zM7 10V7h.5a.5.5 0 01.5.5v2a.5.5 0 01-.5.5H7z" fill="currentColor"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M1 1.5A1.5 1.5 0 012.5 0h8.207L14 3.293V13.5a1.5 1.5 0 01-1.5 1.5h-10A1.5 1.5 0 011 13.5v-12zM3.5 6H2v5h1V9h.5a1.5 1.5 0 100-3zm4 0H6v5h1.5A1.5 1.5 0 009 9.5v-2A1.5 1.5 0 007.5 6zm2.5 5V6h3v1h-2v1h1v1h-1v2h-1z" fill="currentColor"></path>
                        </svg>{{$document['display_name']}}
                        <svg class="w-4 h-4 text-green-600" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"></path>
                            <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                        </svg>
                    </a>
                    @else
                    <span class="font-semibold">Billing Statement</span>
                    <a class="flex gap-2 items-center" href="{{ route('ported-number.download',$document['id']) }}">
                        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" fill="currentColor">
                            <path d="M3.5 8H3V7h.5a.5.5 0 010 1zM7 10V7h.5a.5.5 0 01.5.5v2a.5.5 0 01-.5.5H7z" fill="currentColor"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M1 1.5A1.5 1.5 0 012.5 0h8.207L14 3.293V13.5a1.5 1.5 0 01-1.5 1.5h-10A1.5 1.5 0 011 13.5v-12zM3.5 6H2v5h1V9h.5a1.5 1.5 0 100-3zm4 0H6v5h1.5A1.5 1.5 0 009 9.5v-2A1.5 1.5 0 007.5 6zm2.5 5V6h3v1h-2v1h1v1h-1v2h-1z" fill="currentColor"></path>
                        </svg>{{$document['display_name']}}
                        <svg class="w-4 h-4 text-green-600" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"></path>
                            <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                        </svg>
                    </a>
                    @endif
                </li>
                @endforeach
            </ul>
            @endif
            @if($portNumber['status'] == "SUCCESSFULLY" || $portNumber['status'] == "REJECTED" || $portNumber['status'] == "CANCELLED")
            <a href="{{ route('ported-number-listing') }}" class="inline-block px-7 mt-6 mb-4 py-3 bg-orange-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-orange-500 hover:shadow-lg focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light">
                Back </a>
            @else
            <button type="submit" id="sbmt-btn" class="inline-block px-7 mt-6 mb-4 py-3 bg-orange-500 text-white font-medium text-base leading-snug  rounded shadow-md hover:bg-orange-500 hover:shadow-lg focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out  ripple-surface-light" name="action">
                Submit
            </button>
            @endif
        </div>
    </form>
</article>
<script>
    let phone = document.querySelectorAll('.phone');
    phone.forEach(element => {
        let maskedNumber = `(${element.innerText.slice(0, 3)}) ${element.innerText.slice(3, 6)}-${element.innerText.slice(6, 10)}`;
        element.innerText = maskedNumber;
    });

    let number = document.getElementById('cell_phone');
    if (number) {
        document.getElementById('phone').value = number.value;
        if (document.getElementById('phone').value) {
            let maskedNumber = `(${number.value.slice(0, 3)}) ${number.value.slice(3, 6)}-${number.value.slice(6, 10)}`;
            document.getElementById('cell_phone').value = maskedNumber;
        }
        document.getElementById('cell_phone').addEventListener('input', function() {
            let number = this.value;
            let x = number.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
            document.getElementById('phone').value = x[0];
            document.getElementById('cell_phone').value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        });
    }
</script>
<script type="text/javascript">
    function Upload() {
        var size = 0;
        var sizeb = 0;
        document.getElementById('exceed_id').classList.remove("is-exceed");
        document.getElementById('exceed_id2').classList.remove("is-exceed");
        var fileUpload = document.getElementById("p-document");
        if (fileUpload.files.length != 0) {
            document.getElementById('p-document-name').classList.add('hidden')
            var sizeBytes = fileUpload.files[0].size;
            var size = sizeBytes / 1024 ** 2;
        } else {
            var sizeBytes = document.getElementById('p-document-size').value;
            var size = sizeBytes / 1024 ** 2;

        }
        var fileBilling = document.getElementById("b-document");
        if (fileBilling.files.length != 0) {
            document.getElementById('b-document-name').classList.add('hidden')
            var sizeBytes = fileBilling.files[0].size;
            var sizeb = sizeBytes / 1024 ** 2;
        } else {
            var sizeBytes = document.getElementById('b-document-size').value;
            var sizeb = sizeBytes / 1024 ** 2;
        }
        var sum = parseFloat(size) + parseFloat(sizeb);

        if (sum < 4) {
            document.getElementById('sbmt-btn').removeAttribute("disabled", 'true');
            document.getElementById('sbmt-btn').classList.remove("bg-gray-100", "cursor-not-allowed")
        } else {
            if (parseFloat(size) > 4) {
                document.getElementById("p-document").value = '';
                document.getElementById('p-document-name').classList.remove('hidden')
                handleFileUploader();

            } else if (parseFloat(sizeb) > 4) {
                document.getElementById("b-document").value = '';
                document.getElementById('b-document-name').classList.remove('hidden')
                handleFileUploader();
            } else {
                document.getElementById('p-document-name').classList.remove('hidden')
                document.getElementById('b-document-name').classList.remove('hidden')
                handleFileUploader();
            }
        }

    }

    function handleFileUploader() {
        document.getElementById('exceed_id').classList.add("is-exceed");
        document.getElementById('exceed_id2').classList.add("is-exceed");
        document.getElementById('sbmt-btn').setAttribute("disabled", 'true');
        document.getElementById('sbmt-btn').classList.add("bg-gray-100", "cursor-not-allowed");
        document.getElementById("p-document").value = '';
        document.getElementById("b-document").value = '';
    }
    var all = document.querySelectorAll('input');
    document.getElementById('status-check').addEventListener('change', function() {
        var status = document.getElementById('status-check').value;
        if (status != 'Pending') {
            all.forEach(function(e) {
                e.classList.add("bg-gray-100", "cursor-not-allowed")
                e.setAttribute("readonly", '')
            });
            document.getElementById('option-select').classList.add("bg-gray-100", "cursor-not-allowed")
            document.getElementById('option-select').setAttribute("disabled", 'true')
            var element = document.getElementById('p-document');
             
            if (element != null) {
                document.getElementById('p-document').setAttribute("disabled", 'true')
                document.getElementById('b-document').setAttribute("disabled", 'true')
            }
        } else {
            all.forEach(function(e) {
                e.classList.remove("bg-gray-100", "cursor-not-allowed")
                e.removeAttribute("readonly", '')
                document.getElementById('option-select').classList.remove("bg-gray-100", "cursor-not-allowed")
                document.getElementById('option-select').removeAttribute("disabled", 'false')
            });
            document.getElementById('p-document').removeAttribute("disabled", 'false')
            document.getElementById('b-document').removeAttribute("disabled", 'false')
        }
        
        document.getElementById('reason').classList.add('hidden', 'bg-gray-50')
        handleRemoveComment();
        handleRequestHidden();
        
        if (status == 'Port Rejected') {
            document.getElementById('comment-txt').value = ""
            document.getElementById('reason').classList.remove('hidden')
            document.getElementById('comment-txt').classList.remove('bg-gray-50')
            document.getElementById('comment-txt').setAttribute("required", '')
            handleRequestSelected();
            handleRequestHidden();
            handleStatus();
        }
        if (status == 'Pending') {
            document.getElementById('request-input').value = "";
            document.getElementById('reason_cancellation').value = "";
            document.getElementById('comment-cancel').value=""
            document.getElementById('reason').value = "";
            document.getElementById('reason').classList.add('hidden')
            document.getElementById('request-input').classList.add('hidden')
            document.getElementById('reason_cancellation').classList.add('hidden');
            handleRemoveComment();
        }
        if (status == 'Port Requested') {
            document.getElementById('request-input').classList.remove('hidden')
            document.getElementById('request-input').value = ""
            document.getElementById('comment-cancel').value=""
            document.getElementById('request-input').removeAttribute("readonly", '')
             document.getElementById('request-input').setAttribute("required", '')
            document.getElementById('request-input').classList.remove("bg-gray-100", "cursor-not-allowed")
            document.getElementById('reason_cancellation').classList.add('hidden');
            document.getElementById('comment-cancel').removeAttribute("required", '')
            handleReason();
            handleRemoveComment();
            handleStatus();
            var req_data = @json($portNumber);
            console.log(req_data);
            if (req_data['status'] != "REQUESTED") {
                document.getElementById('request').classList.remove('hidden')
            }else{
                document.getElementById('request-input').removeAttribute("required", '')
                document.getElementById('request-selected').classList.remove('hidden')
            }
        }
        if (status == 'Port Successful') {
            handleReason();
            handleRequestSelected();
            handleRemoveComment();
            handleRequestHidden();
            handleStatus();
            // document.getElementById('request').classList.add('hidden')
        }
        if (status == 'Port Cancelled') {
            document.getElementById('request-input').classList.add('hidden');
            document.getElementById('reason_cancellation').classList.remove('hidden');
            document.getElementById('comment-cancel').setAttribute("required", '')
        }
    });
    function handleStatus() {
        document.getElementById('sbmt-btn').removeAttribute("disabled", 'true');
        document.getElementById('sbmt-btn').classList.remove("bg-gray-100", "cursor-not-allowed");
    }
    function handleRequestHidden() {
        document.getElementById('request').classList.add('hidden');
        document.getElementById('request-input').removeAttribute("required", '');
    }
    function handleRemoveComment() {
        document.getElementById('comment-txt').removeAttribute("required", '');
    }
    function handleRequestSelected() {
        document.getElementById('request-selected').classList.add('hidden');
    }
    function handleReason() {
        document.getElementById('reason').classList.add('hidden');
        document.getElementById('comment-txt').classList.add('bg-gray-50');
    }
    function validate(e) {
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
    }
</script>
@endsection
@extends('layouts.main')
@section('title', 'Ported Number')
@section('content')

<article id="getHeight" class="px-4 sm:px-8 pt-4 pb-10">
    <section class="flex flex-col sm:flex-row gap-3 justify-between items-center pt-4">
        <div>
            <h2 class="font-bold text-xl text-gray-800 leading-tight mb-2">
                Ported Numbers Listing
            </h2>
            <div class="text-gray-500">Display list of all Ported Numbers</div>
        </div>
        <div class="flex">
            <a href="/ported-number/create" class="inline-block px-6 py-2 bg-orange-500 text-white font-medium text-base
                leading-snug  rounded-lg shadow-md hover:bg-orange-500 hover:shadow-lg
                focus:bg-orange-500 focus:shadow-lg focus:outline-none focus:ring-0
                active:bg-orange-500 active:shadow-lg transition duration-150
                ease-in-out w-full ripple-surface-light">
                New Port Request
            </a>
        </div>
    </section>

    <section class="flex flex-col sm:flex-row gap-4 justify-end pt-4 mb-2">
        <div class="flex gap-2">
            <label class="relative block w-80 ">
                <span class="sr-only">Search</span>
                <span class="absolute inset-y-7 left-0 flex items-center pl-2 text-gray-300">
                    <svg class="h-5 w-5 mb-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg> </span>
                <form method=" {{ route('ported-number-listing')}}?{{request()->getQueryString()
                  }}" method="get" id="form_id">
                        <input class="placeholder:text-gray-400 block bg-white
                     w-full border
                     border-gray-300 rounded-lg py-2 pl-9 pr-3 shadow-sm
                     focus:outline-none
                     focus:border-blue-500 focus:ring-blue-500 focus:ring-1
                     sm:text-sm" placeholder="Porting Number, Address" type="text" name="search" value="{{
                     Request::get('search') }}">
                      <a href="{{route('ported-number-listing', ['search' => '']);}}" class="absolute top-0 right-0 flex
                     items-center p-2 text-gray-300">
                     <svg class="h-5 w-5 mb-4"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                        fill="currentColor">
                        <g>
                           <path fill="none" d="M0 0h24v24H0z"></path>
                           <path
                              d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95
                              4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414
                              4.95-4.95-4.95-4.95L7.05 5.636z">
                           </path>
                        </g>
                     </svg> </a>
                     <input type="hidden" name="status" value="{{
                    Request::get('status')}}">
                    </form>
            </label>
        </div>
         <div class="items-center">
                <div class="gap-3 flex items-center">
                    <div class="font-semibold">Status</div>
                    <div class="relative" x-data="{ dropdown: false }">  
                        <form method="get">
                            <select class="p-2 px-3 pr-5 text-sm border border-gray-300
                            cursor-pointer bg-white truncate shadow-sm rounded-lg
                            w-[200px] w-full selectNew" name="status"
                            onchange="this.form.submit()">
                                <option value="all" @if(Request('status')=='all' ) selected
                                    @endif>All</option>
                                <option value="pending" @if(Request('status')=='pending') selected @endif>
                                Pending</option>
                                <option value="rejected"
                                    @if(Request('status')=='rejected') selected
                                    @endif>Port Rejected</option>
                                <option value="successful"
                                    @if(Request('status')=='successful' )
                                    selected @endif>Port Successful</option>
                                <option value="requested"
                                    @if(Request('status')=='requested')
                                    selected @endif>Port Requested</option>
                                    <option value="cancelled"
                                    @if(Request('status')=='cancelled')
                                    selected @endif>Port Cancelled</option>
                            </select>
                            <input type="hidden" name="search" value="{{
                                Request::get('search')}}">
                        </form>     
                    </div>
                </div>
            </div>
    </section>
    <div class="py-2">
        <div class="bg-white rounded-lg">
            <div class="relative  sm:rounded-lg">
                <table class="w-full text-sm ">
                    <thead>
                        <tr>
                            <th class="px-6 py-4 font-medium tracking-wider  text-sm truncate text-center">
                                S.No
                            </th>
                            <th class="px-6 py-4 font-medium tracking-wider text-sm
                                truncate text-left">
                                <div class="flex items-center">
                                <a class="flex items-center" href="{{
                                    route('ported-number-listing', ['number'=>
                                    request()->query('number') == 'desc' ?
                                    'asc' : 'desc',
                                    'search' => Request::get('search'),
                                    'status' => request()->query('status'),
                                    'perPage' => request()->query('perPage'),
                                    'page' => request()->query('page'),
                                    ])
                                    }}">
                                    Porting Number
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        class="ml-1 w-3 h-3" aria-hidden="true"
                                        fill="#282727" viewBox="0 0 320 512">
                                        <path
                                            d="M27.66 224h264.7c24.6 0 36.89-29.78
                                            19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                            0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                            194.2 3.055 224 27.66 224zM292.3
                                            288H27.66c-24.6 0-36.89 29.77-19.54
                                            47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                            480c7.053 0 14.12-2.703
                                            19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                            288 292.3 288z">
                                        </path>
                                    </svg>
                                </a>
                                </div>
                            </th>
                            <th class="px-6 py-4 font-medium tracking-wider text-sm
                                truncate text-left">
                                <div class="flex items-center">
                                <a class="flex items-center" href="{{
                                    route('ported-number-listing', ['address'=>
                                    request()->query('address') == 'desc' ?
                                    'asc' : 'desc',
                                    'search' => Request::get('search'),
                                    'status' => request()->query('status'),
                                    'perPage' => request()->query('perPage'),
                                    'page' => request()->query('page'),
                                    ])
                                    }}">
                                    Porting Address
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        class="ml-1 w-3 h-3" aria-hidden="true"
                                        fill="#282727" viewBox="0 0 320 512">
                                        <path
                                            d="M27.66 224h264.7c24.6 0 36.89-29.78
                                            19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                            0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                            194.2 3.055 224 27.66 224zM292.3
                                            288H27.66c-24.6 0-36.89 29.77-19.54
                                            47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                            480c7.053 0 14.12-2.703
                                            19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                            288 292.3 288z">
                                        </path>
                                    </svg>
                                </a>
                                </div>
                            </th>
                            <th class="px-6 py-4 font-medium tracking-wider text-sm
                                truncate text-left">
                                <div class="flex items-center">
                                <a class="flex items-center" href="{{
                                    route('ported-number-listing', ['request_date'=>
                                    request()->query('request_date') == 'desc' ?
                                    'asc' : 'desc',
                                    'search' => Request::get('search'),
                                    'status' => request()->query('status'),
                                    'perPage' => request()->query('perPage'),
                                    'page' => request()->query('page'),
                                    ])
                                    }}">
                                    Porting Request Date
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        class="ml-1 w-3 h-3" aria-hidden="true"
                                        fill="#282727" viewBox="0 0 320 512">
                                        <path
                                            d="M27.66 224h264.7c24.6 0 36.89-29.78
                                            19.54-47.12l-132.3-136.8c-5.406-5.406-12.47-8.107-19.53-8.107c-7.055
                                            0-14.09 2.701-19.45 8.107L8.119 176.9C-9.229
                                            194.2 3.055 224 27.66 224zM292.3
                                            288H27.66c-24.6 0-36.89 29.77-19.54
                                            47.12l132.5 136.8C145.9 477.3 152.1 480 160
                                            480c7.053 0 14.12-2.703
                                            19.53-8.109l132.3-136.8C329.2 317.8 316.9
                                            288 292.3 288z">
                                        </path>
                                    </svg>
                                </a>
                                </div>
                            </th>
                            <th class="px-6 py-4 font-medium tracking-wider  text-sm truncate text-left">
                                Porting Status
                            </th>
                            <th class="px-6 py-4 font-medium tracking-wider  text-sm truncate text-left">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    @if($portLists->count() >0)
                    @foreach ($portLists as $key => $portList)
                 
                        <tr class="border-t border-b border-gray-100 odd:bg-violet-50/25">
                            <td class="text-sm px-6 py-3 text-center">
                               {{$key+ $portLists->firstItem()}}
                            </td>
                            <td class="text-sm px-6 py-3 text-left">
                                {{$portList['number']}}
                            </td>
                            <td class="text-sm px-6 py-3 text-left">
                                {{Str::limit($portList['address'], 40)}}
                            </td>
                            <td class="text-sm px-6 py-3 text-left">
                                @if($portList['request_date'])
                                <div>{{ date("d M, Y" ,strtotime($portList->request_date))}}</div>
                                @else
                                <div></div>
                                @endif
                            </td>
                           
                            <td class="text-sm px-6 py-3 text-left relative">
                                @if($portList['status'] == 'SUCCESSFULLY')
                                <div class="text-green-600 flex items-center gap-1">Port Successful</div>
                                @elseif($portList['status'] == 'REJECTED')
                                <div class="text-rose-600 flex items-center gap-1" style="width:128px;">Port Rejected  <span class="mr-4" x-data="{ isOpen: false, timeout: null }"
                                            x-on:mouseenter="isOpen = true; clearTimeout(timeout)"
                                            x-on:mouseleave="timeout = setTimeout(() => { isOpen = false }, 300)">
                                            <a href="#"> <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M0 0h24v24H0z" fill="none"></path>
                                                    <path
                                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z">
                                                    </path>
                                                </svg></a>
                                            <div style="z-index: 999;
                                                height: 100px;
                                                overflow: auto;
                                                background: rgb(255, 255, 255); left:0;" class="bg-white shadow-md rounded w-[200px] absolute p-4  text-gray-700
                                                text-sm border" x-show="isOpen" class="absolute">
                                                {{$portList['comment']}}
                                            </div>
                                        </span></div>
                                @elseif($portList['status'] == 'PENDING')
                                <div class="text-amber-400 flex items-center gap-1">Pending</div>
                              
                                  @elseif($portList['status'] == 'CANCELLED')
                                  <div class="text-amber-400 flex items-center gap-1">Port Cancelled  <span class="mr-4" x-data="{ isOpen: false, timeout: null }"
                                            x-on:mouseenter="isOpen = true; clearTimeout(timeout)"
                                            x-on:mouseleave="timeout = setTimeout(() => { isOpen = false }, 300)">
                                            <a href="#"> <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M0 0h24v24H0z" fill="none"></path>
                                                    <path
                                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z">
                                                    </path>
                                                </svg></a>
                                            <div style="z-index: 999;
                                                height: 100px;
                                                overflow: auto;
                                                background: rgb(255, 255, 255); left:0;" class="bg-white shadow-md rounded w-[200px] absolute p-4  text-gray-700
                                                text-sm border" x-show="isOpen" class="absolute">
                                                {{$portList['cancel_comment']}}
                                            </div>
                                        </span></div>
                                @else
                                <div class="text-amber-400 flex items-center gap-1">Port Requested</div>
                                @endif   
                            </td>
                            <td class="text-sm px-6 py-3 text-left">
                                <a href="ported-number/{{$portList['id']}}/edit"  class="font-semibold text-orange-500 text-sm font-medium" title="View" href="#">
                                    View
                                </a>
                            </td>
                        </tr>

                        @endforeach
                        @else
                        <tr class="border-t border-b border-gray-100 odd:bg-violet-50/25">
                            <td colspan="10">
                                <div class="flex items-center justify-center w-full p-4">
                                    <div class="filament-tables-empty-state flex flex-1 flex-col items-center justify-center p-6 mx-auto space-y-6 text-center bg-white">
                                        <div class="flex items-center justify-center w-16 h-16 text-primary-500 rounded-full bg-orange-50">
                                            <svg wire:loading.remove.delay="1" wire:target="previousPage,nextPage,gotoPage,sortTable,tableFilters,resetTableFiltersForm,tableSearchQuery,tableColumnSearchQueries,tableRecordsPerPage" class="w-6 h-6 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                                            </svg>

                                        </div>

                                        <div class="max-w-md space-y-1">
                                            <h2 class="filament-tables-empty-state-heading text-xl font-bold tracking-tight">
                                                No records found
                                            </h2>

                                            <p class="filament-tables-empty-state-description whitespace-normal text-sm font-medium text-gray-500">

                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </td>
                        </tr>
                            @endif
                    </tbody>
                </table>
                <div class="flex items-center gap-2 p-2">
                    <form method="get">
                        <select
                            class="bg-gray-50 w-20 border border-gray-300
                            text-gray-900 text-sm rounded focus:ring-blue-500
                            focus:border-blue-500 block w-full p-2"
                            name="perPage" onchange="this.form.submit()">
                            <option value="10" @if(Request('perPage')==10) selected
                                @endif>10</option>
                            <option value="25" @if(Request('perPage')==25) selected
                                @endif>25</option>
                            <option value="50" @if(Request('perPage')==50) selected
                                @endif>50</option>
                            <option value="100" @if(Request('perPage')==100) selected
                                @endif>100</option>
                            <option value="200" @if(Request('perPage')==200) selected
                                @endif>200</option>
                            <option value="{{ $portLists->total() }}"
                                @if(Request('perPage')== $portLists->total())
                                selected @endif>All</option>
                        </select>
                        <input type="hidden" name="search" value="{{
                            Request::get('search')}}">
                        <input type="hidden" name="number" value="{{
                            Request::get('number')}}">
                        <input type="hidden" name="address" value="{{
                            Request::get('address')}}">
                        <input type="hidden" name="request_date" value="{{
                            Request::get('request_date')}}">
                        <input type="hidden" name="status" value="{{
                            Request::get('status')}}">
                    </form>
                    <label for="title" class="block text-sm font-semibold
                        text-gray-900">
                        Per Page
                    </label>
                </div>
            </div>
        </div>
    </div>
    {{ $portLists->appends(['search' => Request::get('search') ?? '',
            'status' => request()->query('status') ?? '',
            'perPage' => request()->query('perPage') ?? '',
            ])->links();
            }}
</article>
@endsection
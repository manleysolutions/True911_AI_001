<?php

use App\Http\Controllers\AttachNumberController;
use App\Http\Controllers\CallFlowController;
use App\Http\Controllers\CallLogController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeviceController;
use App\Http\Controllers\DeviceLinkController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\ManageNumberController;
use App\Http\Controllers\ModifyCallFlowController;
use App\Http\Controllers\ModifyDeviceController;
use App\Http\Controllers\ModifyNumberController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PortNumberController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
require __DIR__ . '/auth.php';

Route::get('/', function () {
  
    return to_route('dashboard');
});

Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::controller(ProfileController::class)->group(function () {
        Route::get('/profile', 'edit')->name('profile.edit');
        Route::patch('/profile', 'update')->name('profile.update');
        Route::delete('/profile', 'destroy')->name('profile.destroy');
    });
    Route::controller(ManageNumberController::class)->group(function () {
        Route::get('/manage-numbers', 'index')->name('manage-numbers');
        Route::match(array('GET', 'POST'), '/manage-numbers/create', 'create')->name('manage-numbers.create');
        Route::post('/manage-numbers/search', 'search')->name('manage-numbers.search');
        Route::post('/manage-numbers/puchase-number', 'store')->name('manage-numbers.purchase');
        Route::get('/manage-numbers/{id}/edit', 'edit')->name('manage-numbers.edit');
        Route::post ('/manage-numbers/edit-number','update')->name ('edit.phone_number');
        Route::post('/manage-numbers/release', 'destroy')->name('manage-numbers.release');     
        Route::get('/manage-numbers/call-logs/{id}/calls', 'view_call_logs')->name('manage-numbers.call-logs');
    }); 
    Route::controller(PortNumberController::class)->group(function () {
        Route::get('/ported-number', 'index')->name('ported-number-listing');
        Route::get('/ported-number/create', 'create')->name('ported-number.create');
        Route::post('/ported-number/store', 'store')->name('ported-number.store');
        Route::get('/ported-number/{id}/edit', 'edit')->name('ported-number.edit');
        Route::post('/ported-number/{port_number}/update', 'update')->name('ported-number.update');
        Route::get('/ported-number/{id}/download', 'download')->name('ported-number.download');
    });  
    Route::controller(DeviceLinkController::class)->group(function () {
        Route::get('/link-device/{id}', 'index')->name('link-device.index');
        Route::post('/link-device/{id}/store', 'store')->name('link-device.store');       
    }); 
    Route::controller(AttachNumberController::class)->group(function () {
        Route::get('/attach-number/{id}', 'index')->name('attach-number.index');
        Route::post('/attach-number/{id}/store', 'store')->name('attach-number.store');  
    });
    Route::controller(CallFlowController::class)->group(function () {
        Route::get('/call-flow/{id}', 'index')->name('call-flow.listing');
        Route::post('/call-flow/attach', 'store')->name('attach-flow.store');
    });
    Route::controller(DeviceController::class)->group(function () {
        Route::get('/devices', 'index')->name('devices.index');
        Route::get('/devices/search/', 'search')->name('devices.search');
        Route::get('/devices/{id}/view', 'view')->name('devices.view');
        Route::get('/devices/call-logs/{id}/calls', 'view_call_logs')->name('devices.call-logs');
        Route::post('/devices/address-update', 'facility_address_update')->name('devices.address.update');
    });
    Route::controller(CallLogController::class)->group(function () {
        Route::get('/call-logs', 'index')->name('call-logs.index');
    });
    Route::controller(ExportController::class)->group(function(){
        Route::post('/export-data','export')->name('export.data');
        Route::post('/get-number','get_number')->name('getnumber.data');

    });
    Route::controller(ModifyNumberController::class)->group(function(){
        Route::get('/modify-number/{id}','update')->name('update-number');
    });
    Route::controller(ModifyDeviceController::class)->group(function(){
        Route::get('/modify-device/{id}','update')->name('update-device');
    });
    Route::controller(ModifyCallFlowController::class)->group(function(){
        Route::get('/modify-call-flow/{id}','update')->name('update-call-flow');
    });
});
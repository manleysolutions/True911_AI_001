$('.loaderForm').submit(function () {
    $('#pageLoader').show();
})

$(document).ready(function () {
    $('.dateRange').css('display', 'none');
    $('.device_error').css('display', 'none');
    $('.number_error').css('display', 'none');
    $('.from_error').css('display', 'none');
    $('.to_error').css('display', 'none');

});

function selectedDate(event) {
    if (event.target.value == 'custom_date') {
        $('.dateRange').css('display', 'block');
        $('#from').prop('required', true);
    } else {
        $('#from').prop('required', false);
        $('.dateRange').css('display', 'none');
    }
}

$('#submitForm').click(function () {
    var devices = $('#devices').val();
    var number = $('#sel1').val();
    $('.number_error').css('display', 'none');
    $('.device_error').css('display', 'none');
    if (typeof devices === "undefined") {
        $('.number_error').css('display', 'block');
        return;
    }
    if (devices.length == 0) {
        $('.device_error').css('display', 'block');
        return;
    }
    if (number.length == 0) {
        $('.number_error').css('display', 'block');
        return;
    }
    if ($('#date_filter').val() == 'custom_date') {
        var fromDate = $('#from').val();
        var toDate = $('#to').val();
        if (fromDate == '') {
            $('.from_error').css('display', 'block');
            return;
        }
        if (toDate == '') {
            $('.to_error').css('display', 'block');
            return;
        }
    }
    $('.dateRange').css('display','none');
    $("#exportClose").trigger("click");
    $('#exportForm').submit();
    if ($('#getNumber').length != 0) {
        var resultData = $('#getNumber').val();
        var results = JSON.parse(resultData);
        sel1.innerHTML =
            results.map(t => '<option value="' + t.phone_number + '" selected>' + t.phone_number + '-' + t.nick_name + '</option>');
        sel1.loadOptions();
    }
    return;
});

function getSelectedOptions(sel) {
    var opts = [],
        opt;
    var len = sel.options.length;
    if (len > 0) {
        $('.device_error').css('display', 'none');
    }
    for (var i = 0; i < len; i++) {
        opt = sel.options[i];
        if (opt.selected) {
            opts.push(opt.value);
        }
    }
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: 'POST',
        url: "/get-number",
        data: {
            'devices': opts
        },
        success: function (resultData) {
            console.log(resultData);
            console.log($("#sel1").length);
            $('#numberr').val();
            $('#numberss').empty();
            if (resultData.length != 0 && ($("#sel1").length != 0)) {
                sel1.innerHTML =
                    resultData.map(t => '<option value="' + t.phone_number + '" selected>' + t.phone_number + '-' + t.nick_name + '</option>');
                sel1.loadOptions();
            }
        }
    });
};

$(function () {
    $("#from").datepicker({
        dateFormat: "yy-mm-dd",
        minDate: "-100y",
        maxDate: 0,
        changeMonth: true,
        changeYear: true
    });
});

$(function () {
    $("#to").datepicker({
        dateFormat: "yy-mm-dd",
        minDate: 0,
        maxDate: 0,
        changeMonth: true,
        changeYear: true
    });
});

$('#from').change(function () {
    startDate = $(this).datepicker('getDate');
    $("#to").datepicker('setDate', startDate + 1);
    $("#to").datepicker("option", "minDate", startDate);
})

$('#to').change(function () {
    endDate = $(this).datepicker('getDate');
    $("#from").datepicker("option", "maxDate", endDate);
})